
  # Counseling Booking Interface

  This is a code bundle for Counseling Booking Interface. The original project is available at https://www.figma.com/design/z9GNT7iParQLcXBRzC4nji/Counseling-Booking-Interface.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  