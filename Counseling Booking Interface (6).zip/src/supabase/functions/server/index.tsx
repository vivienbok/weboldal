import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import * as kv from "./kv_store.tsx";

const app = new Hono();

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// Health check endpoint
app.get("/make-server-aea76cd4/health", (c) => {
  return c.json({ status: "ok" });
});

// ==================== COUNSELORS ====================

// Get all counselors
app.get("/make-server-aea76cd4/counselors", async (c) => {
  try {
    const counselors = await kv.getByPrefix("counselor:");
    return c.json({ success: true, data: counselors });
  } catch (error) {
    console.log("Error fetching counselors:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// Get a single counselor by ID
app.get("/make-server-aea76cd4/counselors/:id", async (c) => {
  try {
    const id = c.req.param("id");
    const counselor = await kv.get(`counselor:${id}`);
    if (!counselor) {
      return c.json({ success: false, error: "Counselor not found" }, 404);
    }
    return c.json({ success: true, data: counselor });
  } catch (error) {
    console.log("Error fetching counselor:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// Create or update a counselor
app.post("/make-server-aea76cd4/counselors", async (c) => {
  try {
    const counselor = await c.req.json();
    await kv.set(`counselor:${counselor.id}`, counselor);
    return c.json({ success: true, data: counselor });
  } catch (error) {
    console.log("Error saving counselor:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// Update counselor avatar
app.put("/make-server-aea76cd4/counselors/:id/avatar", async (c) => {
  try {
    const id = c.req.param("id");
    const { avatar } = await c.req.json();
    
    const counselor = await kv.get(`counselor:${id}`);
    if (!counselor) {
      return c.json({ success: false, error: "Counselor not found" }, 404);
    }
    
    counselor.photo = avatar;
    await kv.set(`counselor:${id}`, counselor);
    
    return c.json({ success: true, data: counselor });
  } catch (error) {
    console.log("Error updating counselor avatar:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// ==================== USERS ====================

// User login
app.post("/make-server-aea76cd4/auth/login", async (c) => {
  try {
    const { email, password, userType } = await c.req.json();
    
    // Get user by email
    const user = await kv.get(`user:${email}`);
    
    if (!user || user.password !== password || user.type !== userType) {
      return c.json({ success: false, error: "Invalid credentials" }, 401);
    }
    
    // Don't send password back to client
    const { password: _, ...userWithoutPassword } = user;
    
    return c.json({ success: true, data: userWithoutPassword });
  } catch (error) {
    console.log("Error during login:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// User registration
app.post("/make-server-aea76cd4/auth/register", async (c) => {
  try {
    const userData = await c.req.json();
    
    // Check if user already exists
    const existingUser = await kv.get(`user:${userData.email}`);
    if (existingUser) {
      return c.json({ success: false, error: "User already exists" }, 409);
    }
    
    // Create new user
    const newUser = {
      ...userData,
      createdAt: new Date().toISOString()
    };
    
    await kv.set(`user:${userData.email}`, newUser);
    
    // Don't send password back
    const { password: _, ...userWithoutPassword } = newUser;
    
    return c.json({ success: true, data: userWithoutPassword });
  } catch (error) {
    console.log("Error during registration:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// Update user profile
app.put("/make-server-aea76cd4/users/:email", async (c) => {
  try {
    const email = c.req.param("email");
    const updates = await c.req.json();
    
    const user = await kv.get(`user:${email}`);
    if (!user) {
      return c.json({ success: false, error: "User not found" }, 404);
    }
    
    const updatedUser = { ...user, ...updates };
    await kv.set(`user:${email}`, updatedUser);
    
    const { password: _, ...userWithoutPassword } = updatedUser;
    return c.json({ success: true, data: userWithoutPassword });
  } catch (error) {
    console.log("Error updating user:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// ==================== APPOINTMENTS ====================

// Get all appointments (with optional filters)
app.get("/make-server-aea76cd4/appointments", async (c) => {
  try {
    const clientEmail = c.req.query("clientEmail");
    const counselorId = c.req.query("counselorId");
    const status = c.req.query("status");
    
    let appointments = await kv.getByPrefix("appointment:");
    
    // Apply filters
    if (clientEmail) {
      appointments = appointments.filter(apt => apt.client?.email === clientEmail);
    }
    if (counselorId) {
      appointments = appointments.filter(apt => apt.counselor.id === Number(counselorId));
    }
    if (status) {
      appointments = appointments.filter(apt => apt.status === status);
    }
    
    return c.json({ success: true, data: appointments });
  } catch (error) {
    console.log("Error fetching appointments:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// Create a new appointment
app.post("/make-server-aea76cd4/appointments", async (c) => {
  try {
    const appointment = await c.req.json();
    const id = `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    
    const newAppointment = {
      ...appointment,
      id,
      status: appointment.status || 'confirmed',
      createdAt: new Date().toISOString()
    };
    
    await kv.set(`appointment:${id}`, newAppointment);
    
    return c.json({ success: true, data: newAppointment });
  } catch (error) {
    console.log("Error creating appointment:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// Update appointment
app.put("/make-server-aea76cd4/appointments/:id", async (c) => {
  try {
    const id = c.req.param("id");
    const updates = await c.req.json();
    
    const appointment = await kv.get(`appointment:${id}`);
    if (!appointment) {
      return c.json({ success: false, error: "Appointment not found" }, 404);
    }
    
    const updatedAppointment = { ...appointment, ...updates };
    await kv.set(`appointment:${id}`, updatedAppointment);
    
    return c.json({ success: true, data: updatedAppointment });
  } catch (error) {
    console.log("Error updating appointment:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// Delete appointment
app.delete("/make-server-aea76cd4/appointments/:id", async (c) => {
  try {
    const id = c.req.param("id");
    
    const appointment = await kv.get(`appointment:${id}`);
    if (!appointment) {
      return c.json({ success: false, error: "Appointment not found" }, 404);
    }
    
    await kv.del(`appointment:${id}`);
    
    return c.json({ success: true, message: "Appointment deleted" });
  } catch (error) {
    console.log("Error deleting appointment:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// ==================== TIME SLOTS ====================

// Get all time slots (with optional filters)
app.get("/make-server-aea76cd4/timeslots", async (c) => {
  try {
    const counselorName = c.req.query("counselorName");
    const isBooked = c.req.query("isBooked");
    
    let timeSlots = await kv.getByPrefix("timeslot:");
    
    // Apply filters
    if (counselorName) {
      timeSlots = timeSlots.filter(slot => slot.counselorName === counselorName);
    }
    if (isBooked !== undefined) {
      timeSlots = timeSlots.filter(slot => slot.isBooked === (isBooked === 'true'));
    }
    
    return c.json({ success: true, data: timeSlots });
  } catch (error) {
    console.log("Error fetching time slots:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// Create a new time slot
app.post("/make-server-aea76cd4/timeslots", async (c) => {
  try {
    const timeSlot = await c.req.json();
    const id = `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    
    const newTimeSlot = {
      ...timeSlot,
      id,
      createdAt: new Date().toISOString()
    };
    
    await kv.set(`timeslot:${id}`, newTimeSlot);
    
    return c.json({ success: true, data: newTimeSlot });
  } catch (error) {
    console.log("Error creating time slot:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// Update time slot
app.put("/make-server-aea76cd4/timeslots/:id", async (c) => {
  try {
    const id = c.req.param("id");
    const updates = await c.req.json();
    
    const timeSlot = await kv.get(`timeslot:${id}`);
    if (!timeSlot) {
      return c.json({ success: false, error: "Time slot not found" }, 404);
    }
    
    const updatedTimeSlot = { ...timeSlot, ...updates };
    await kv.set(`timeslot:${id}`, updatedTimeSlot);
    
    return c.json({ success: true, data: updatedTimeSlot });
  } catch (error) {
    console.log("Error updating time slot:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// Delete time slot
app.delete("/make-server-aea76cd4/timeslots/:id", async (c) => {
  try {
    const id = c.req.param("id");
    
    const timeSlot = await kv.get(`timeslot:${id}`);
    if (!timeSlot) {
      return c.json({ success: false, error: "Time slot not found" }, 404);
    }
    
    await kv.del(`timeslot:${id}`);
    
    return c.json({ success: true, message: "Time slot deleted" });
  } catch (error) {
    console.log("Error deleting time slot:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// ==================== APPOINTMENT REQUESTS ====================

// Get all appointment requests (with optional filters)
app.get("/make-server-aea76cd4/appointment-requests", async (c) => {
  try {
    const counselorId = c.req.query("counselorId");
    const status = c.req.query("status");
    
    let requests = await kv.getByPrefix("appointmentrequest:");
    
    // Apply filters
    if (counselorId) {
      requests = requests.filter(req => req.counselorId === Number(counselorId));
    }
    if (status) {
      requests = requests.filter(req => req.status === status);
    }
    
    return c.json({ success: true, data: requests });
  } catch (error) {
    console.log("Error fetching appointment requests:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// Create a new appointment request
app.post("/make-server-aea76cd4/appointment-requests", async (c) => {
  try {
    const request = await c.req.json();
    const id = `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    
    const newRequest = {
      ...request,
      id,
      status: 'pending',
      createdAt: new Date().toISOString()
    };
    
    await kv.set(`appointmentrequest:${id}`, newRequest);
    
    return c.json({ success: true, data: newRequest });
  } catch (error) {
    console.log("Error creating appointment request:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// Update appointment request (approve/reject)
app.put("/make-server-aea76cd4/appointment-requests/:id", async (c) => {
  try {
    const id = c.req.param("id");
    const updates = await c.req.json();
    
    const request = await kv.get(`appointmentrequest:${id}`);
    if (!request) {
      return c.json({ success: false, error: "Appointment request not found" }, 404);
    }
    
    const updatedRequest = { ...request, ...updates };
    await kv.set(`appointmentrequest:${id}`, updatedRequest);
    
    return c.json({ success: true, data: updatedRequest });
  } catch (error) {
    console.log("Error updating appointment request:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// Delete appointment request
app.delete("/make-server-aea76cd4/appointment-requests/:id", async (c) => {
  try {
    const id = c.req.param("id");
    
    const request = await kv.get(`appointmentrequest:${id}`);
    if (!request) {
      return c.json({ success: false, error: "Appointment request not found" }, 404);
    }
    
    await kv.del(`appointmentrequest:${id}`);
    
    return c.json({ success: true, message: "Appointment request deleted" });
  } catch (error) {
    console.log("Error deleting appointment request:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// ==================== INITIALIZE DEFAULT DATA ====================

// Initialize default counselors and demo users
app.post("/make-server-aea76cd4/initialize", async (c) => {
  try {
    // Check if data already exists
    const existingCounselors = await kv.getByPrefix("counselor:");
    if (existingCounselors.length > 0) {
      return c.json({ success: true, message: "Data already initialized" });
    }
    
    // Create default counselors
    const counselor1 = {
      id: 1,
      name: "Bognár Tamás",
      title: "Clinical Psychologist",
      photo: "https://static.wixstatic.com/media/dd55ab_702efa8d1aff4f458f7b00c1ca18fd45~mv2.jpg/v1/fill/w_187,h_250,al_c,q_80,usm_0.66_1.00_0.01,enc_avif,quality_auto/Dr_%20Bogn%C3%A1r%20Tam%C3%A1s.jpg"
    };
    
    const counselor2 = {
      id: 2,
      name: "Mária Bogdányi",
      title: "Mental Health Specialist",
      photo: "https://images.unsplash.com/photo-1551836022-deb4988cc6c0?w=400&h=400&fit=crop"
    };
    
    await kv.set("counselor:1", counselor1);
    await kv.set("counselor:2", counselor2);
    
    // Create demo users
    const demoClient = {
      name: "Demo Client",
      email: "client@demo.com",
      password: "demo123",
      type: "client",
      neptunId: "ABC123",
      avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=demo"
    };
    
    const demoCounselor = {
      name: "Bognár Tamás",
      email: "counselor@demo.com",
      password: "demo123",
      type: "counselor",
      avatar: "https://static.wixstatic.com/media/dd55ab_702efa8d1aff4f458f7b00c1ca18fd45~mv2.jpg/v1/fill/w_187,h_250,al_c,q_80,usm_0.66_1.00_0.01,enc_avif,quality_auto/Dr_%20Bogn%C3%A1r%20Tam%C3%A1s.jpg"
    };
    
    const demoAdmin = {
      name: "Admin User",
      email: "admin@demo.com",
      password: "admin123",
      type: "admin",
      avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=admin"
    };
    
    await kv.set("user:client@demo.com", demoClient);
    await kv.set("user:counselor@demo.com", demoCounselor);
    await kv.set("user:admin@demo.com", demoAdmin);
    
    return c.json({ 
      success: true, 
      message: "Default data initialized successfully",
      counselors: [counselor1, counselor2],
      demoUsers: [
        { email: "client@demo.com", password: "demo123", type: "client" },
        { email: "counselor@demo.com", password: "demo123", type: "counselor" },
        { email: "admin@demo.com", password: "admin123", type: "admin" }
      ]
    });
  } catch (error) {
    console.log("Error initializing data:", error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

Deno.serve(app.fetch);