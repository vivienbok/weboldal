import { useState, useEffect } from "react";
import { Layout } from "./components/Layout";
import { Homepage } from "./components/Homepage";
import { AppointmentBooking } from "./components/AppointmentBooking";
import { BookedAppointments } from "./components/BookedAppointments";
import { UnifiedLogin } from "./components/UnifiedLogin";
import { Profile } from "./components/Profile";
import { Statistics } from "./components/Statistics";
import { Toaster } from "./components/ui/sonner";
import { SessionNotes } from "./components/SessionNotes";
import { AdminDashboard } from "./components/AdminDashboard";
import { LanguageProvider } from "./contexts/LanguageContext";
import { AppointmentRequests } from "./components/AppointmentRequests";
import { AppointmentRequestData } from "./components/AppointmentRequest";
import { TimeSlot } from "./components/TimeSlotManagement";
import * as api from "./utils/api";
import { toast } from "sonner@2.0.3";

type Page = "home" | "booking" | "appointments" | "profile" | "statistics" | "session-notes" | "admin" | "login" | "requests";
type UserType = "counselor" | "client" | "admin" | null;

interface UserInfo {
  name: string;
  email: string;
  type: UserType;
  avatar?: string;
  neptunId?: string;
}

export interface Counselor {
  id: number;
  name: string;
  title: string;
  photo: string;
}

export interface BookedAppointment {
  id: string;
  date: Date;
  time: string;
  counselor: Counselor;
  client?: {
    name: string;
    email: string;
  };
  status: 'confirmed' | 'cancelled';
}

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>("login");
  const [userType, setUserType] = useState<UserType>(null);
  const [userInfo, setUserInfo] = useState<UserInfo | null>(null);
  const [bookedAppointments, setBookedAppointments] = useState<BookedAppointment[]>([]);
  const [timeSlots, setTimeSlots] = useState<TimeSlot[]>([]);
  const [appointmentRequests, setAppointmentRequests] = useState<AppointmentRequestData[]>([]);
  const [counselors, setCounselors] = useState<Record<number, Counselor>>({});
  const [isLoading, setIsLoading] = useState(true);
  const [initError, setInitError] = useState<string | null>(null);

  // Initialize database and load data on mount
  useEffect(() => {
    const initializeApp = async () => {
      try {
        setIsLoading(true);
        setInitError(null);
        
        // Initialize default data (counselors and demo users)
        await api.initializeDefaultData();
        console.log('Database initialized successfully');
        
        // Load counselors
        const counselorsData = await api.getCounselors();
        const counselorsMap: Record<number, Counselor> = {};
        counselorsData.forEach((counselor: Counselor) => {
          counselorsMap[counselor.id] = counselor;
        });
        setCounselors(counselorsMap);
        
        // Load appointments
        const appointmentsData = await api.getAppointments();
        // Convert date strings to Date objects
        const parsedAppointments = appointmentsData.map((apt: any) => ({
          ...apt,
          date: new Date(apt.date)
        }));
        setBookedAppointments(parsedAppointments);
        
        // Load time slots
        const timeSlotsData = await api.getTimeSlots();
        const parsedTimeSlots = timeSlotsData.map((slot: any) => ({
          ...slot,
          date: new Date(slot.date)
        }));
        setTimeSlots(parsedTimeSlots);
        
        // Load appointment requests
        const requestsData = await api.getAppointmentRequests();
        const parsedRequests = requestsData.map((req: any) => ({
          ...req,
          preferredDate: new Date(req.preferredDate),
          createdAt: new Date(req.createdAt)
        }));
        setAppointmentRequests(parsedRequests);
        
        console.log('App data loaded successfully');
      } catch (error) {
        console.error('Error initializing app:', error);
        const errorMessage = error instanceof Error ? error.message : 'Failed to load app data';
        setInitError(errorMessage);
        toast.error('Failed to connect to the server. Please check your Supabase connection.');
      } finally {
        setIsLoading(false);
      }
    };
    
    initializeApp();
  }, []);

  const handleBookAppointment = async (appointment: Omit<BookedAppointment, 'id' | 'status'>) => {
    try {
      const newAppointment = await api.createAppointment({
        ...appointment,
        date: appointment.date.toISOString(),
        status: 'confirmed'
      });
      
      // Parse date back to Date object
      newAppointment.date = new Date(newAppointment.date);
      setBookedAppointments(prev => [...prev, newAppointment]);
      
      toast.success('Appointment booked successfully');
    } catch (error) {
      console.error('Error booking appointment:', error);
      toast.error('Failed to book appointment. Please try again.');
    }
  };

  const handleCancelAppointment = async (id: string) => {
    try {
      await api.deleteAppointment(id);
      setBookedAppointments(prev => prev.filter(apt => apt.id !== id));
      toast.success('Appointment cancelled successfully');
    } catch (error) {
      console.error('Error cancelling appointment:', error);
      toast.error('Failed to cancel appointment. Please try again.');
    }
  };

  // Time slot management handlers
  const handleAddTimeSlot = async (timeSlot: Omit<TimeSlot, 'id'>) => {
    try {
      const newSlot = await api.createTimeSlot({
        ...timeSlot,
        date: timeSlot.date.toISOString()
      });
      
      newSlot.date = new Date(newSlot.date);
      setTimeSlots(prev => [...prev, newSlot]);
    } catch (error) {
      console.error('Error adding time slot:', error);
      toast.error('Failed to add time slot. Please try again.');
    }
  };

  const handleEditTimeSlot = async (id: string, timeSlot: Omit<TimeSlot, 'id'>) => {
    try {
      const updatedSlot = await api.updateTimeSlot(id, {
        ...timeSlot,
        date: timeSlot.date.toISOString()
      });
      
      updatedSlot.date = new Date(updatedSlot.date);
      setTimeSlots(prev =>
        prev.map(slot => (slot.id === id ? { ...updatedSlot, id } : slot))
      );
    } catch (error) {
      console.error('Error editing time slot:', error);
      toast.error('Failed to edit time slot. Please try again.');
    }
  };

  const handleDeleteTimeSlot = async (id: string) => {
    try {
      await api.deleteTimeSlot(id);
      setTimeSlots(prev => prev.filter(slot => slot.id !== id));
    } catch (error) {
      console.error('Error deleting time slot:', error);
      toast.error('Failed to delete time slot. Please try again.');
    }
  };

  // Appointment request handlers
  const handleSubmitRequest = async (request: Omit<AppointmentRequestData, 'id' | 'status' | 'createdAt'>) => {
    try {
      const newRequest = await api.createAppointmentRequest({
        ...request,
        preferredDate: request.preferredDate.toISOString()
      });
      
      newRequest.preferredDate = new Date(newRequest.preferredDate);
      newRequest.createdAt = new Date(newRequest.createdAt);
      setAppointmentRequests(prev => [...prev, newRequest]);
      
      toast.success('Appointment request submitted successfully');
    } catch (error) {
      console.error('Error submitting request:', error);
      toast.error('Failed to submit appointment request. Please try again.');
    }
  };

  const handleAcceptRequest = async (requestId: string) => {
    try {
      const request = appointmentRequests.find(r => r.id === requestId);
      if (!request) return;

      // Update request status
      await api.updateAppointmentRequest(requestId, { status: 'accepted' });
      setAppointmentRequests(prev =>
        prev.map(r => (r.id === requestId ? { ...r, status: 'accepted' as const } : r))
      );

      // Add to booked appointments
      const counselor = counselors[request.counselorId as keyof typeof counselors];
      if (counselor) {
        const newAppointment = await api.createAppointment({
          date: request.preferredDate.toISOString(),
          time: request.preferredTime,
          counselor: counselor,
          client: {
            name: request.patientName,
            email: request.patientEmail
          },
          status: 'confirmed'
        });
        
        newAppointment.date = new Date(newAppointment.date);
        setBookedAppointments(prev => [...prev, newAppointment]);
      }
      
      toast.success('Appointment request accepted');
    } catch (error) {
      console.error('Error accepting request:', error);
      toast.error('Failed to accept appointment request. Please try again.');
    }
  };

  const handleRejectRequest = async (requestId: string) => {
    try {
      await api.updateAppointmentRequest(requestId, { status: 'rejected' });
      setAppointmentRequests(prev =>
        prev.map(r => (r.id === requestId ? { ...r, status: 'rejected' as const } : r))
      );
      
      toast.success('Appointment request rejected');
    } catch (error) {
      console.error('Error rejecting request:', error);
      toast.error('Failed to reject appointment request. Please try again.');
    }
  };

  const handleLogin = async (email: string, password: string, userType: "counselor" | "client" | "admin") => {
    try {
      const user = await api.login(email, password, userType);
      
      setUserType(user.type);
      setUserInfo({
        name: user.name,
        email: user.email,
        type: user.type,
        avatar: user.avatar,
        neptunId: user.neptunId
      });
      
      // If counselor, load their time slots
      if (user.type === "counselor") {
        const slots = await api.getTimeSlots({ counselorName: user.name });
        const parsedSlots = slots.map((slot: any) => ({
          ...slot,
          date: new Date(slot.date)
        }));
        setTimeSlots(parsedSlots);
        
        // Generate default time slots if none exist
        if (parsedSlots.length === 0) {
          await generateDefaultTimeSlots(user.name);
        }
      }
      
      // Set appropriate page
      if (user.type === "admin") {
        setCurrentPage("admin");
      } else {
        setCurrentPage("home");
      }
      
      toast.success(`Welcome back, ${user.name}!`);
    } catch (error) {
      console.error('Login error:', error);
      toast.error('Invalid credentials. Please try again.');
      throw error;
    }
  };

  // Generate default time slots for counselors
  const generateDefaultTimeSlots = async (counselorName: string) => {
    try {
      const slots: TimeSlot[] = [];
      const today = new Date();
      const timeSlotTimes = ["09:00", "10:00", "11:00", "13:00", "14:00", "15:00", "16:00"];
      
      // Generate slots for the next 14 days (2 weeks)
      for (let dayOffset = 0; dayOffset < 14; dayOffset++) {
        const date = new Date(today);
        date.setDate(today.getDate() + dayOffset);
        
        // Skip weekends
        if (date.getDay() === 0 || date.getDay() === 6) {
          continue;
        }
        
        // Create multiple time slots per day
        for (const time of timeSlotTimes) {
          const newSlot = await api.createTimeSlot({
            date: date.toISOString(),
            time: time,
            duration: 50,
            isBooked: false,
            counselorName: counselorName
          });
          
          newSlot.date = new Date(newSlot.date);
          slots.push(newSlot);
        }
      }
      
      setTimeSlots(slots);
    } catch (error) {
      console.error('Error generating default time slots:', error);
    }
  };

  const handleLogout = () => {
    setUserType(null);
    setUserInfo(null);
    setCurrentPage("login");
  };

  const handleUpdateUserInfo = async (updatedInfo: Partial<UserInfo>) => {
    if (!userInfo) return;
    
    try {
      // Update user in database
      await api.updateUser(userInfo.email, updatedInfo);
      
      setUserInfo({ ...userInfo, ...updatedInfo });
      
      // If avatar updated and user is a counselor, update counselor photo everywhere
      if (updatedInfo.avatar && userType === "counselor") {
        // Find counselor by name
        const counselor = Object.values(counselors).find(c => c.name === userInfo.name);
        
        if (counselor) {
          // Update counselor photo in database
          await api.updateCounselorAvatar(counselor.id, updatedInfo.avatar);
          
          // Update counselor photo in centralized state
          setCounselors(prev => ({
            ...prev,
            [counselor.id]: {
              ...prev[counselor.id],
              photo: updatedInfo.avatar!
            }
          }));
          
          // Update all existing booked appointments with new photo
          const updatedAppointments = bookedAppointments.map(apt =>
            apt.counselor.id === counselor.id
              ? {
                  ...apt,
                  counselor: {
                    ...apt.counselor,
                    photo: updatedInfo.avatar!
                  }
                }
              : apt
          );
          setBookedAppointments(updatedAppointments);
          
          // Update appointments in database
          for (const apt of updatedAppointments) {
            if (apt.counselor.id === counselor.id) {
              await api.updateAppointment(apt.id, {
                counselor: apt.counselor
              });
            }
          }
        }
      }
      
      toast.success('Profile updated successfully');
    } catch (error) {
      console.error('Error updating user info:', error);
      toast.error('Failed to update profile. Please try again.');
    }
  };

  const renderPage = () => {
    switch (currentPage) {
      case "login":
        return (
          <UnifiedLogin
            onLogin={handleLogin}
          />
        );
      case "home":
        return <Homepage onGetStarted={() => setCurrentPage("booking")} counselors={counselors} />;
      case "booking":
        return (
          <AppointmentBooking 
            userType={userType} 
            onBookAppointment={handleBookAppointment} 
            bookedAppointments={bookedAppointments} 
            userInfo={userInfo} 
            onSubmitRequest={handleSubmitRequest}
            counselors={counselors}
          />
        );
      case "appointments":
        return (
          <BookedAppointments 
            appointments={bookedAppointments} 
            onCancelAppointment={handleCancelAppointment} 
            userInfo={userInfo}
            timeSlots={timeSlots}
            onAddTimeSlot={handleAddTimeSlot}
            onEditTimeSlot={handleEditTimeSlot}
            onDeleteTimeSlot={handleDeleteTimeSlot}
            appointmentRequests={appointmentRequests}
            onAcceptRequest={handleAcceptRequest}
            onRejectRequest={handleRejectRequest}
            onNavigate={setCurrentPage}
          />
        );
      case "profile":
        return <Profile userInfo={userInfo} onUpdateUserInfo={handleUpdateUserInfo} />;
      case "statistics":
        return userType === "counselor" ? <Statistics /> : <Homepage onGetStarted={() => setCurrentPage("booking")} />;
      case "session-notes":
        return <SessionNotes />;
      case "admin":
        return userType === "admin" ? <AdminDashboard /> : <Homepage onGetStarted={() => setCurrentPage("booking")} />;
      case "requests":
        return userType === "counselor" && userInfo ? (
          <AppointmentRequests 
            requests={appointmentRequests}
            onAcceptRequest={handleAcceptRequest}
            onRejectRequest={handleRejectRequest}
            userInfo={userInfo}
          />
        ) : (
          <Homepage onGetStarted={() => setCurrentPage("booking")} />
        );
      default:
        return <Homepage onGetStarted={() => setCurrentPage("booking")} />;
    }
  };

  // Show loading screen while initializing
  if (isLoading) {
    return (
      <LanguageProvider>
        <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: '#00224B' }}>
          <div className="text-center">
            <div className="w-16 h-16 border-4 border-blue-200 border-t-white rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-white text-lg">Loading CareConnect...</p>
          </div>
        </div>
      </LanguageProvider>
    );
  }

  // Show error screen if initialization failed
  if (initError) {
    return (
      <LanguageProvider>
        <div className="min-h-screen flex items-center justify-center p-4" style={{ backgroundColor: '#00224B' }}>
          <div className="max-w-2xl w-full bg-white rounded-lg shadow-xl p-8">
            <div className="text-center mb-6">
              <div className="w-20 h-20 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-10 h-10 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <h2 className="text-2xl mb-2" style={{ color: '#00224B' }}>Connection Error</h2>
              <p className="text-gray-600 mb-6">{initError}</p>
            </div>
            
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-6 mb-6">
              <h3 className="text-lg mb-3" style={{ color: '#00224B' }}>
                <strong>Supabase Setup Required</strong>
              </h3>
              <p className="text-gray-700 mb-4">
                This application requires a Supabase backend to function. Please ensure:
              </p>
              <ol className="list-decimal list-inside space-y-2 text-gray-700 mb-4">
                <li>Your Supabase project is properly configured</li>
                <li>The Edge Function is deployed to your Supabase project</li>
                <li>The project ID and API key in <code className="bg-gray-200 px-1 rounded">/utils/supabase/info.tsx</code> are correct</li>
              </ol>
              <div className="bg-white rounded p-4 border border-blue-300">
                <p className="text-sm text-gray-600 mb-2"><strong>To deploy the Edge Function:</strong></p>
                <ol className="list-decimal list-inside space-y-1 text-sm text-gray-600">
                  <li>Install Supabase CLI: <code className="bg-gray-200 px-1 rounded">npm install -g supabase</code></li>
                  <li>Login: <code className="bg-gray-200 px-1 rounded">supabase login</code></li>
                  <li>Link project: <code className="bg-gray-200 px-1 rounded">supabase link --project-ref {'{'}your-project-id{'}'}</code></li>
                  <li>Deploy: <code className="bg-gray-200 px-1 rounded">supabase functions deploy make-server-aea76cd4</code></li>
                </ol>
              </div>
            </div>
            
            <div className="flex gap-4 justify-center">
              <button
                onClick={() => window.location.reload()}
                className="px-6 py-2 rounded-lg text-white transition-colors"
                style={{ backgroundColor: '#005FA3' }}
                onMouseOver={(e) => e.currentTarget.style.backgroundColor = '#004a82'}
                onMouseOut={(e) => e.currentTarget.style.backgroundColor = '#005FA3'}
              >
                Retry Connection
              </button>
              <a
                href="https://supabase.com/docs/guides/functions"
                target="_blank"
                rel="noopener noreferrer"
                className="px-6 py-2 rounded-lg border-2 transition-colors"
                style={{ borderColor: '#005FA3', color: '#005FA3' }}
              >
                View Documentation
              </a>
            </div>
          </div>
        </div>
      </LanguageProvider>
    );
  }

  // Don't use Layout for login pages
  if (currentPage === "login") {
    return (
      <LanguageProvider>
        {renderPage()}
      </LanguageProvider>
    );
  }

  return (
    <LanguageProvider>
      <Layout 
        currentPage={currentPage} 
        onNavigate={setCurrentPage}
        onLogout={handleLogout}
        userType={userType}
        userInfo={userInfo}
      >
        {renderPage()}
        <Toaster position="top-right" />
      </Layout>
    </LanguageProvider>
  );
}