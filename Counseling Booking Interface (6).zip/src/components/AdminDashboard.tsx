import { useState } from "react";
import { Users, UserCheck, Calendar, Settings, Edit, Trash2, Plus } from "lucide-react";
import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "./ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "./ui/alert-dialog";
import { useLanguage } from "../contexts/LanguageContext";
import { toast } from "sonner@2.0.3";

interface Student {
  id: number;
  name: string;
  email: string;
  neptunId: string;
  appointments: number;
}

interface Counselor {
  id: number;
  name: string;
  email: string;
  phone: string;
  title: string;
  specializations: string[];
}

export function AdminDashboard() {
  const { t } = useLanguage();
  const [selectedTab, setSelectedTab] = useState<"students" | "counselors">("students");

  // State for students
  const [students, setStudents] = useState<Student[]>([
    {
      id: 1,
      name: "Nagy Anna",
      email: "nagy.anna@student.edu",
      neptunId: "NA1234",
      appointments: 3
    },
    {
      id: 2,
      name: "Kovács Péter",
      email: "kovacs.peter@student.edu",
      neptunId: "KP5678",
      appointments: 2
    }
  ]);

  // State for counselors
  const [counselors, setCounselors] = useState<Counselor[]>([
    {
      id: 1,
      name: "Bognár Tamás",
      email: "bognar.tamas@careconnect.edu",
      phone: "+36 96 503 401",
      title: "Clinical Psychologist",
      specializations: ["Anxiety Management", "Stress Reduction", "Academic Support"]
    },
    {
      id: 2,
      name: "Bogdányi Mária",
      email: "maria.bogdanyi@careconnect.edu",
      phone: "+36 96 503 402",
      title: "Mental Health Specialist",
      specializations: ["Depression Support", "Relationship Counseling", "Life Transitions"]
    }
  ]);

  // Dialog states
  const [addStudentDialogOpen, setAddStudentDialogOpen] = useState(false);
  const [addCounselorDialogOpen, setAddCounselorDialogOpen] = useState(false);
  const [editStudentDialogOpen, setEditStudentDialogOpen] = useState(false);
  const [editCounselorDialogOpen, setEditCounselorDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [itemToDelete, setItemToDelete] = useState<{ type: 'student' | 'counselor', id: number } | null>(null);

  // Form states
  const [newStudent, setNewStudent] = useState({ name: "", email: "", neptunId: "" });
  const [newCounselor, setNewCounselor] = useState({ name: "", email: "", phone: "", title: "", specializations: "" });
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);
  const [editingCounselor, setEditingCounselor] = useState<Counselor | null>(null);

  // Student CRUD operations
  const handleAddStudent = () => {
    if (!newStudent.name || !newStudent.email || !newStudent.neptunId) {
      toast.error("Please fill in all fields");
      return;
    }

    const student: Student = {
      id: Math.max(...students.map(s => s.id), 0) + 1,
      name: newStudent.name,
      email: newStudent.email,
      neptunId: newStudent.neptunId,
      appointments: 0
    };

    setStudents([...students, student]);
    setNewStudent({ name: "", email: "", neptunId: "" });
    setAddStudentDialogOpen(false);
    toast.success(`Student ${student.name} added successfully`);
  };

  const handleEditStudent = () => {
    if (!editingStudent) return;

    setStudents(students.map(s => s.id === editingStudent.id ? editingStudent : s));
    setEditStudentDialogOpen(false);
    setEditingStudent(null);
    toast.success(`Student ${editingStudent.name} updated successfully`);
  };

  const handleDeleteStudent = (id: number) => {
    const student = students.find(s => s.id === id);
    setStudents(students.filter(s => s.id !== id));
    setDeleteDialogOpen(false);
    setItemToDelete(null);
    toast.success(`Student ${student?.name} deleted successfully`);
  };

  // Counselor CRUD operations
  const handleAddCounselor = () => {
    if (!newCounselor.name || !newCounselor.email || !newCounselor.phone || !newCounselor.title) {
      toast.error("Please fill in all required fields");
      return;
    }

    const counselor: Counselor = {
      id: Math.max(...counselors.map(c => c.id), 0) + 1,
      name: newCounselor.name,
      email: newCounselor.email,
      phone: newCounselor.phone,
      title: newCounselor.title,
      specializations: newCounselor.specializations.split(',').map(s => s.trim()).filter(s => s)
    };

    setCounselors([...counselors, counselor]);
    setNewCounselor({ name: "", email: "", phone: "", title: "", specializations: "" });
    setAddCounselorDialogOpen(false);
    toast.success(`Counselor ${counselor.name} added successfully`);
  };

  const handleEditCounselor = () => {
    if (!editingCounselor) return;

    setCounselors(counselors.map(c => c.id === editingCounselor.id ? editingCounselor : c));
    setEditCounselorDialogOpen(false);
    setEditingCounselor(null);
    toast.success(`Counselor ${editingCounselor.name} updated successfully`);
  };

  const handleDeleteCounselor = (id: number) => {
    const counselor = counselors.find(c => c.id === id);
    setCounselors(counselors.filter(c => c.id !== id));
    setDeleteDialogOpen(false);
    setItemToDelete(null);
    toast.success(`Counselor ${counselor?.name} deleted successfully`);
  };

  const openDeleteDialog = (type: 'student' | 'counselor', id: number) => {
    setItemToDelete({ type, id });
    setDeleteDialogOpen(true);
  };

  const confirmDelete = () => {
    if (!itemToDelete) return;
    
    if (itemToDelete.type === 'student') {
      handleDeleteStudent(itemToDelete.id);
    } else {
      handleDeleteCounselor(itemToDelete.id);
    }
  };

  return (
    <div className="max-w-7xl mx-auto p-6">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl mb-2" style={{ color: '#00224B' }}>
          {t("Administration Dashboard", "Adminisztrációs Felület")}
        </h1>
        <p className="text-gray-600">
          {t("Manage students, counselors, and system settings", "Hallgatók, tanácsadók és rendszerbeállítások kezelése")}
        </p>
      </div>

      {/* Stats Cards */}
      <div className="grid md:grid-cols-4 gap-6 mb-8">
        <Card className="p-6 bg-gradient-to-br from-blue-50 to-blue-100 border-2" style={{ borderColor: '#005FA3' }}>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">{t("Total Students", "Összes Hallgató")}</p>
              <p className="text-3xl" style={{ color: '#00224B' }}>{students.length}</p>
            </div>
            <Users className="w-12 h-12 text-blue-600" />
          </div>
        </Card>

        <Card className="p-6 bg-gradient-to-br from-purple-50 to-purple-100 border-2 border-purple-300">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">{t("Counselors", "Tanácsadók")}</p>
              <p className="text-3xl" style={{ color: '#00224B' }}>{counselors.length}</p>
            </div>
            <UserCheck className="w-12 h-12 text-purple-600" />
          </div>
        </Card>

        <Card className="p-6 bg-gradient-to-br from-green-50 to-green-100 border-2 border-green-300">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">{t("Active Appointments", "Aktív Foglalások")}</p>
              <p className="text-3xl" style={{ color: '#00224B' }}>12</p>
            </div>
            <Calendar className="w-12 h-12 text-green-600" />
          </div>
        </Card>

        <Card className="p-6 bg-gradient-to-br from-orange-50 to-orange-100 border-2 border-orange-300">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">{t("System Status", "Rendszer Állapot")}</p>
              <p className="text-lg text-green-600">{t("Online", "Online")}</p>
            </div>
            <Settings className="w-12 h-12 text-orange-600" />
          </div>
        </Card>
      </div>

      {/* Tab Navigation */}
      <div className="mb-6">
        <div className="flex gap-2 border-b-2 border-gray-200">
          <button
            onClick={() => setSelectedTab("students")}
            className={`px-6 py-3 font-semibold transition-all ${
              selectedTab === "students"
                ? "border-b-4 text-white"
                : "text-gray-600 hover:text-gray-900"
            }`}
            style={{
              borderColor: selectedTab === "students" ? '#005FA3' : 'transparent',
              backgroundColor: selectedTab === "students" ? '#005FA3' : 'transparent'
            }}
          >
            <Users className="w-5 h-5 inline mr-2" />
            {t("Students", "Hallgatók")}
          </button>
          <button
            onClick={() => setSelectedTab("counselors")}
            className={`px-6 py-3 font-semibold transition-all ${
              selectedTab === "counselors"
                ? "border-b-4 text-white"
                : "text-gray-600 hover:text-gray-900"
            }`}
            style={{
              borderColor: selectedTab === "counselors" ? '#005FA3' : 'transparent',
              backgroundColor: selectedTab === "counselors" ? '#005FA3' : 'transparent'
            }}
          >
            <UserCheck className="w-5 h-5 inline mr-2" />
            {t("Counselors", "Tanácsadók")}
          </button>
        </div>
      </div>

      {/* Students Tab */}
      {selectedTab === "students" && (
        <Card className="p-6 bg-white border-2 border-gray-200">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl" style={{ color: '#00224B' }}>
              {t("Student Management", "Hallgatók Kezelése")}
            </h2>
            
            {/* Add Student Dialog */}
            <Dialog open={addStudentDialogOpen} onOpenChange={setAddStudentDialogOpen}>
              <DialogTrigger asChild>
                <Button className="text-white" style={{ backgroundColor: '#005FA3' }}>
                  <Plus className="w-5 h-5 mr-2" />
                  {t("Add Student", "Új Hallgató")}
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>{t("Add New Student", "Új Hallgató Hozzáadása")}</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label htmlFor="student-name">{t("Name", "Név")}</Label>
                    <Input
                      id="student-name"
                      value={newStudent.name}
                      onChange={(e) => setNewStudent({ ...newStudent, name: e.target.value })}
                      placeholder="Enter student name"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="student-email">{t("Email", "E-mail")}</Label>
                    <Input
                      id="student-email"
                      type="email"
                      value={newStudent.email}
                      onChange={(e) => setNewStudent({ ...newStudent, email: e.target.value })}
                      placeholder="student@example.edu"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="student-neptun">{t("Neptun ID", "Neptun Kód")}</Label>
                    <Input
                      id="student-neptun"
                      value={newStudent.neptunId}
                      onChange={(e) => setNewStudent({ ...newStudent, neptunId: e.target.value })}
                      placeholder="ABC123"
                    />
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setAddStudentDialogOpen(false)}>
                    {t("Cancel", "Mégse")}
                  </Button>
                  <Button onClick={handleAddStudent} style={{ backgroundColor: '#005FA3', color: 'white' }}>
                    {t("Add Student", "Hozzáadás")}
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b-2 border-gray-200">
                  <th className="text-left p-4 font-semibold text-gray-700">{t("Name", "Név")}</th>
                  <th className="text-left p-4 font-semibold text-gray-700">{t("Email", "E-mail")}</th>
                  <th className="text-left p-4 font-semibold text-gray-700">{t("Neptun ID", "Neptun Kód")}</th>
                  <th className="text-left p-4 font-semibold text-gray-700">{t("Appointments", "Foglalások")}</th>
                  <th className="text-left p-4 font-semibold text-gray-700">{t("Actions", "Műveletek")}</th>
                </tr>
              </thead>
              <tbody>
                {students.map((student) => (
                  <tr key={student.id} className="border-b border-gray-200 hover:bg-gray-50">
                    <td className="p-4">{student.name}</td>
                    <td className="p-4 text-gray-600">{student.email}</td>
                    <td className="p-4 text-gray-600">{student.neptunId}</td>
                    <td className="p-4">
                      <span className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm">
                        {student.appointments}
                      </span>
                    </td>
                    <td className="p-4">
                      <div className="flex gap-2">
                        <Button 
                          size="sm" 
                          variant="outline" 
                          className="border-blue-300 text-blue-700 hover:bg-blue-50"
                          onClick={() => {
                            setEditingStudent(student);
                            setEditStudentDialogOpen(true);
                          }}
                        >
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button 
                          size="sm" 
                          variant="outline" 
                          className="border-red-300 text-red-700 hover:bg-red-50"
                          onClick={() => openDeleteDialog('student', student.id)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Edit Student Dialog */}
          <Dialog open={editStudentDialogOpen} onOpenChange={setEditStudentDialogOpen}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>{t("Edit Student", "Hallgató Szerkesztése")}</DialogTitle>
              </DialogHeader>
              {editingStudent && (
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label htmlFor="edit-student-name">{t("Name", "Név")}</Label>
                    <Input
                      id="edit-student-name"
                      value={editingStudent.name}
                      onChange={(e) => setEditingStudent({ ...editingStudent, name: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="edit-student-email">{t("Email", "E-mail")}</Label>
                    <Input
                      id="edit-student-email"
                      type="email"
                      value={editingStudent.email}
                      onChange={(e) => setEditingStudent({ ...editingStudent, email: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="edit-student-neptun">{t("Neptun ID", "Neptun Kód")}</Label>
                    <Input
                      id="edit-student-neptun"
                      value={editingStudent.neptunId}
                      onChange={(e) => setEditingStudent({ ...editingStudent, neptunId: e.target.value })}
                    />
                  </div>
                </div>
              )}
              <DialogFooter>
                <Button variant="outline" onClick={() => setEditStudentDialogOpen(false)}>
                  {t("Cancel", "Mégse")}
                </Button>
                <Button onClick={handleEditStudent} style={{ backgroundColor: '#005FA3', color: 'white' }}>
                  {t("Save Changes", "Mentés")}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </Card>
      )}

      {/* Counselors Tab */}
      {selectedTab === "counselors" && (
        <Card className="p-6 bg-white border-2 border-gray-200">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl" style={{ color: '#00224B' }}>
              {t("Counselor Management", "Tanácsadók Kezelése")}
            </h2>
            
            {/* Add Counselor Dialog */}
            <Dialog open={addCounselorDialogOpen} onOpenChange={setAddCounselorDialogOpen}>
              <DialogTrigger asChild>
                <Button className="text-white" style={{ backgroundColor: '#005FA3' }}>
                  <Plus className="w-5 h-5 mr-2" />
                  {t("Add Counselor", "Új Tanácsadó")}
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>{t("Add New Counselor", "Új Tanácsadó Hozzáadása")}</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label htmlFor="counselor-name">{t("Name", "Név")}</Label>
                    <Input
                      id="counselor-name"
                      value={newCounselor.name}
                      onChange={(e) => setNewCounselor({ ...newCounselor, name: e.target.value })}
                      placeholder="Enter counselor name"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="counselor-email">{t("Email", "E-mail")}</Label>
                    <Input
                      id="counselor-email"
                      type="email"
                      value={newCounselor.email}
                      onChange={(e) => setNewCounselor({ ...newCounselor, email: e.target.value })}
                      placeholder="counselor@example.edu"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="counselor-phone">{t("Phone", "Telefon")}</Label>
                    <Input
                      id="counselor-phone"
                      value={newCounselor.phone}
                      onChange={(e) => setNewCounselor({ ...newCounselor, phone: e.target.value })}
                      placeholder="+36 96 503 400"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="counselor-title">{t("Title", "Beosztás")}</Label>
                    <Input
                      id="counselor-title"
                      value={newCounselor.title}
                      onChange={(e) => setNewCounselor({ ...newCounselor, title: e.target.value })}
                      placeholder="Clinical Psychologist"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="counselor-specializations">{t("Specializations", "Szakterületek")}</Label>
                    <Input
                      id="counselor-specializations"
                      value={newCounselor.specializations}
                      onChange={(e) => setNewCounselor({ ...newCounselor, specializations: e.target.value })}
                      placeholder="Comma separated values"
                    />
                    <p className="text-xs text-gray-500">Enter specializations separated by commas</p>
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setAddCounselorDialogOpen(false)}>
                    {t("Cancel", "Mégse")}
                  </Button>
                  <Button onClick={handleAddCounselor} style={{ backgroundColor: '#005FA3', color: 'white' }}>
                    {t("Add Counselor", "Hozzáadás")}
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>

          <div className="grid gap-6">
            {counselors.map((counselor) => (
              <Card key={counselor.id} className="p-6 bg-gray-50 border-2 border-gray-200 hover:shadow-lg transition-all">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h3 className="text-xl mb-2" style={{ color: '#00224B' }}>{counselor.name}</h3>
                    <p className="text-purple-600 mb-3">{counselor.title}</p>
                    
                    <div className="space-y-2 mb-4">
                      <div className="flex items-center gap-2 text-sm text-gray-600">
                        <span className="font-semibold">{t("Email", "E-mail")}:</span>
                        <span>{counselor.email}</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-gray-600">
                        <span className="font-semibold">{t("Phone", "Telefon")}:</span>
                        <span>{counselor.phone}</span>
                      </div>
                    </div>

                    <div className="flex flex-wrap gap-2">
                      {counselor.specializations.map((spec, idx) => (
                        <span key={idx} className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm">
                          {spec}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="flex gap-2 ml-4">
                    <Button 
                      size="sm" 
                      variant="outline" 
                      className="border-blue-300 text-blue-700 hover:bg-blue-50"
                      onClick={() => {
                        setEditingCounselor(counselor);
                        setEditCounselorDialogOpen(true);
                      }}
                    >
                      <Edit className="w-4 h-4" />
                    </Button>
                    <Button 
                      size="sm" 
                      variant="outline" 
                      className="border-red-300 text-red-700 hover:bg-red-50"
                      onClick={() => openDeleteDialog('counselor', counselor.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>

          {/* Edit Counselor Dialog */}
          <Dialog open={editCounselorDialogOpen} onOpenChange={setEditCounselorDialogOpen}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>{t("Edit Counselor", "Tanácsadó Szerkesztése")}</DialogTitle>
              </DialogHeader>
              {editingCounselor && (
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label htmlFor="edit-counselor-name">{t("Name", "Név")}</Label>
                    <Input
                      id="edit-counselor-name"
                      value={editingCounselor.name}
                      onChange={(e) => setEditingCounselor({ ...editingCounselor, name: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="edit-counselor-email">{t("Email", "E-mail")}</Label>
                    <Input
                      id="edit-counselor-email"
                      type="email"
                      value={editingCounselor.email}
                      onChange={(e) => setEditingCounselor({ ...editingCounselor, email: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="edit-counselor-phone">{t("Phone", "Telefon")}</Label>
                    <Input
                      id="edit-counselor-phone"
                      value={editingCounselor.phone}
                      onChange={(e) => setEditingCounselor({ ...editingCounselor, phone: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="edit-counselor-title">{t("Title", "Beosztás")}</Label>
                    <Input
                      id="edit-counselor-title"
                      value={editingCounselor.title}
                      onChange={(e) => setEditingCounselor({ ...editingCounselor, title: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="edit-counselor-specializations">{t("Specializations", "Szakterületek")}</Label>
                    <Input
                      id="edit-counselor-specializations"
                      value={editingCounselor.specializations.join(', ')}
                      onChange={(e) => setEditingCounselor({ 
                        ...editingCounselor, 
                        specializations: e.target.value.split(',').map(s => s.trim()).filter(s => s)
                      })}
                    />
                    <p className="text-xs text-gray-500">Enter specializations separated by commas</p>
                  </div>
                </div>
              )}
              <DialogFooter>
                <Button variant="outline" onClick={() => setEditCounselorDialogOpen(false)}>
                  {t("Cancel", "Mégse")}
                </Button>
                <Button onClick={handleEditCounselor} style={{ backgroundColor: '#005FA3', color: 'white' }}>
                  {t("Save Changes", "Mentés")}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </Card>
      )}

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{t("Confirm Deletion", "Törlés Megerősítése")}</AlertDialogTitle>
            <AlertDialogDescription>
              {t(
                "Are you sure you want to delete this user? This action cannot be undone.",
                "Biztosan törölni szeretné ezt a felhasználót? Ez a művelet nem vonható vissza."
              )}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>{t("Cancel", "Mégse")}</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDelete}
              className="bg-red-600 hover:bg-red-700"
            >
              {t("Delete", "Törlés")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}