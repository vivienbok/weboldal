import { useState, useRef } from "react";
import { User, Mail, CreditCard, Save, Edit2, Check, Camera } from "lucide-react";
import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";

interface UserInfo {
  name: string;
  email: string;
  type: "counselor" | "client" | "admin" | null;
  avatar?: string;
  neptunId?: string;
}

interface ProfileProps {
  userInfo: UserInfo | null;
  onUpdateUserInfo?: (updatedInfo: Partial<UserInfo>) => void;
}

export function Profile({ userInfo, onUpdateUserInfo }: ProfileProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [showSaved, setShowSaved] = useState(false);
  const [avatarPreview, setAvatarPreview] = useState<string | undefined>(userInfo?.avatar);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [formData, setFormData] = useState({
    name: userInfo?.name || "",
    email: userInfo?.email || "",
    neptunId: userInfo?.neptunId || ""
  });

  const handleAvatarClick = () => {
    if (isEditing) {
      fileInputRef.current?.click();
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setAvatarPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const getInitials = (name?: string) => {
    if (!name) return "U";
    return name
      .split(" ")
      .map(n => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);
  };

  const handleSave = () => {
    setIsEditing(false);
    setShowSaved(true);
    
    // Call the callback to update user info in parent
    if (onUpdateUserInfo) {
      onUpdateUserInfo({
        ...formData,
        avatar: avatarPreview
      });
    }
    
    setTimeout(() => setShowSaved(false), 3000);
  };

  const handleCancel = () => {
    setFormData({
      name: userInfo?.name || "",
      email: userInfo?.email || "",
      neptunId: userInfo?.neptunId || ""
    });
    setIsEditing(false);
  };

  return (
    <div className="px-4 sm:px-6 lg:px-8 py-12">
      <div className="max-w-3xl mx-auto space-y-8">
        {/* Page Header */}
        <div className="text-center">
          <h1 className="text-3xl font-bold mb-3" style={{ color: '#00224B' }}>Profile Settings</h1>
          <p className="text-gray-600 text-lg">
            View and manage your account information
          </p>
        </div>

        {/* Success Message */}
        {showSaved && (
          <Card className="p-4 text-white shadow-lg animate-in fade-in slide-in-from-top-2 duration-300" style={{ backgroundColor: '#005FA3' }}>
            <div className="flex items-center gap-3">
              <div className="p-2 bg-white/20 rounded-full">
                <Check className="w-5 h-5" />
              </div>
              <div>
                <p className="font-semibold">Profile updated successfully!</p>
                <p className="text-sm text-blue-100">Your changes have been saved.</p>
              </div>
            </div>
          </Card>
        )}

        {/* Profile Information Card */}
        <Card className="p-8 bg-white border-2 border-gray-200">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-3">
              <div className="p-3 rounded-lg" style={{ backgroundColor: '#00224B' }}>
                <User className="w-6 h-6 text-white" />
              </div>
              <div>
                <h2 className="text-xl font-bold" style={{ color: '#00224B' }}>Personal Information</h2>
                <p className="text-sm text-gray-600">Update your personal details</p>
              </div>
            </div>

            {!isEditing ? (
              <Button
                onClick={() => setIsEditing(true)}
                className="text-white font-semibold"
                style={{ backgroundColor: '#005FA3' }}
              >
                <Edit2 className="w-4 h-4 mr-2" />
                Edit Profile
              </Button>
            ) : (
              <div className="flex gap-2">
                <Button
                  onClick={handleCancel}
                  variant="outline"
                  className="border-2 border-gray-300 font-semibold"
                >
                  Cancel
                </Button>
                <Button
                  onClick={handleSave}
                  className="text-white font-semibold"
                  style={{ backgroundColor: '#005FA3' }}
                >
                  <Save className="w-4 h-4 mr-2" />
                  Save Changes
                </Button>
              </div>
            )}
          </div>

          {/* Profile Picture Section */}
          <div className="flex justify-center mb-8">
            <div className="relative">
              <Avatar className="w-32 h-32 border-4 border-blue-200">
                <AvatarImage src={avatarPreview || userInfo?.avatar} alt={userInfo?.name} />
                <AvatarFallback className="bg-gradient-to-br from-blue-200 to-purple-200 text-blue-900 text-2xl">
                  {getInitials(userInfo?.name)}
                </AvatarFallback>
              </Avatar>
              {isEditing && (
                <button
                  type="button"
                  onClick={handleAvatarClick}
                  className="absolute bottom-0 right-0 p-2 bg-blue-600 text-white rounded-full hover:bg-blue-700 transition-colors shadow-lg"
                >
                  <Camera className="w-5 h-5" />
                </button>
              )}
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleFileChange}
                className="hidden"
              />
            </div>
          </div>

          <div className="space-y-6">
            {/* Full Name */}
            <div className="space-y-2">
              <Label htmlFor="name" className="flex items-center gap-2 font-semibold" style={{ color: '#00224B' }}>
                <User className="w-4 h-4" />
                Full Name
              </Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                disabled={!isEditing}
                className={`text-lg border-2 ${isEditing ? 'border-[#005FA3]' : 'border-gray-300 bg-gray-50'}`}
              />
            </div>

            {/* Email Address */}
            <div className="space-y-2">
              <Label htmlFor="email" className="flex items-center gap-2 font-semibold" style={{ color: '#00224B' }}>
                <Mail className="w-4 h-4" />
                Email Address
              </Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                disabled={!isEditing}
                className={`text-lg border-2 ${isEditing ? 'border-[#005FA3]' : 'border-gray-300 bg-gray-50'}`}
              />
            </div>

            {/* Neptun Code (Student ID) */}
            {userInfo?.type === "client" && (
              <div className="space-y-2">
                <Label htmlFor="neptunId" className="flex items-center gap-2 font-semibold" style={{ color: '#00224B' }}>
                  <CreditCard className="w-4 h-4" />
                  Neptun Code (Student ID)
                </Label>
                <Input
                  id="neptunId"
                  value={formData.neptunId}
                  onChange={(e) => setFormData({ ...formData, neptunId: e.target.value.toUpperCase() })}
                  disabled={!isEditing}
                  className={`text-lg border-2 font-mono ${isEditing ? 'border-[#005FA3]' : 'border-gray-300 bg-gray-50'}`}
                  style={{ color: '#005FA3', fontWeight: 'bold' }}
                  maxLength={6}
                  placeholder="ABC123"
                />
                <p className="text-sm text-gray-600 flex items-center gap-2">
                  <span>Your unique student identification code</span>
                </p>
              </div>
            )}
          </div>

          {/* Info Message when Editing */}
          {isEditing && (
            <div className="mt-8 p-4 bg-blue-50 border-2 rounded-lg" style={{ borderColor: '#005FA3' }}>
              <p className="text-sm font-medium" style={{ color: '#00224B' }}>
                💡 Make sure to save your changes before leaving this page.
              </p>
            </div>
          )}
        </Card>

        {/* Account Type Info */}
        <Card className="p-6 bg-gray-50 border-2 border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Account Type</p>
              <p className="font-semibold capitalize" style={{ color: '#00224B' }}>
                {userInfo?.type || "User"}
              </p>
            </div>
            <div className="px-4 py-2 rounded-lg text-white font-semibold" style={{ backgroundColor: '#005FA3' }}>
              {userInfo?.type === "counselor" ? "Counselor" : "Student"}
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}