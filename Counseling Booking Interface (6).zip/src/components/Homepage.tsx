import { Calendar, Shield, Clock, ArrowRight, CheckCircle, GraduationCap, Users, Phone, Mail } from "lucide-react";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import logo from 'figma:asset/80b194f303c6ba8424bc64751d05f8e5809bf7ff.png';
import { Counselor } from "../App";

interface HomepageProps {
  onGetStarted: () => void;
  counselors?: Record<number, Counselor>;
}

export function Homepage({ onGetStarted, counselors }: HomepageProps) {
  const features = [
    {
      icon: Calendar,
      title: "Easy Scheduling",
      description: "Browse available counselors and book appointments with just a few clicks"
    },
    {
      icon: Shield,
      title: "Confidential & Secure",
      description: "Your privacy is our priority. All sessions are completely confidential"
    },
    {
      icon: Clock,
      title: "Flexible Hours",
      description: "Multiple time slots available throughout the week to fit your schedule"
    },
    {
      icon: Users,
      title: "Professional Support",
      description: "Connect with licensed counselors who understand student life"
    }
  ];

  const services = [
    "Anxiety & Stress Management",
    "Depression Support",
    "Academic Performance Counseling",
    "Relationship Counseling",
    "Life Transitions Support",
    "Self-Esteem Building",
    "Crisis Intervention",
    "Group Therapy Sessions"
  ];

  return (
    <div className="bg-white">
      {/* Hero Section */}
      <div className="relative py-20" style={{ backgroundColor: '#00224B' }}>
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center text-white">
            <div className="flex justify-center mb-8">
              <div className="bg-white rounded-lg px-6 py-4 shadow-lg">
                <img 
                  src={logo} 
                  alt="Széchenyi István University" 
                  className="h-20"
                />
              </div>
            </div>
            
            <h1 className="text-4xl md:text-5xl font-bold mb-6 leading-tight">
              Student Mental Health &<br />Counseling Services
            </h1>
            
            <p className="text-lg text-gray-300 max-w-2xl mx-auto mb-8 leading-relaxed">
              Taking care of your mental health is just as important as your academic success. 
              We're here to support you through every challenge, big or small.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                onClick={onGetStarted}
                className="text-white font-semibold px-8 py-6 text-lg"
                style={{ backgroundColor: '#005FA3' }}
              >
                Book an Appointment
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </div>

            {/* Quick Stats */}
            <div className="mt-16 grid grid-cols-3 gap-8 max-w-3xl mx-auto">
              <div className="text-center">
                <div className="text-4xl font-bold mb-2">500+</div>
                <div className="text-sm text-gray-300">Students Helped</div>
              </div>
              <div className="text-center">
                <div className="text-4xl font-bold mb-2">12</div>
                <div className="text-sm text-gray-300">Professional Counselors</div>
              </div>
              <div className="text-center">
                <div className="text-4xl font-bold mb-2">4.9/5</div>
                <div className="text-sm text-gray-300">Satisfaction Rating</div>
              </div>
            </div>
          </div>
        </div>
      </div>



      {/* Services Section */}
      <div className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4" style={{ color: '#00224B' }}>
              Our Services
            </h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              We provide specialized counseling for various mental health and well-being concerns
            </p>
          </div>
          
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 max-w-6xl mx-auto">
            {services.map((service, index) => (
              <div key={index} className="flex items-center gap-3 bg-gray-50 p-4 rounded-lg border-2 border-gray-200 hover:border-[#005FA3] transition-all">
                <CheckCircle className="w-5 h-5 flex-shrink-0" style={{ color: '#005FA3' }} />
                <span className="text-gray-700 font-medium">{service}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Counselors Section */}
      <div className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4" style={{ color: '#00224B' }}>
              Meet Our Professional Counselors
            </h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Our experienced team is here to support your mental health journey
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {/* Counselor 1 */}
            <Card className="p-6 bg-white border-2 border-gray-200 hover:shadow-lg transition-all">
              <div className="flex flex-col items-center text-center">
                <img 
                  src={counselors?.[1]?.photo || "https://static.wixstatic.com/media/dd55ab_702efa8d1aff4f458f7b00c1ca18fd45~mv2.jpg/v1/fill/w_187,h_250,al_c,q_80,usm_0.66_1.00_0.01,enc_avif,quality_auto/Dr_%20Bogn%C3%A1r%20Tam%C3%A1s.jpg"}
                  alt="Bognár Tamás"
                  className="w-48 h-48 rounded-full object-cover mb-6 border-4 border-blue-100"
                />
                <h3 className="text-xl font-semibold mb-2" style={{ color: '#00224B' }}>Bognár Tamás</h3>
                <p className="text-purple-600 font-medium mb-4">Clinical Psychologist</p>
                <p className="text-gray-600 leading-relaxed">
                  Specializes in anxiety management, stress reduction, and academic support. Tamás has over 8 years of experience helping students navigate mental health challenges.
                </p>
                <div className="flex gap-3 mt-4 justify-center text-sm text-gray-600">
                  <div className="flex items-center gap-2">
                    <Mail className="w-4 h-4" style={{ color: '#005FA3' }} />
                    <span>bognar.tamas@sze.hu</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Phone className="w-4 h-4" style={{ color: '#005FA3' }} />
                    <span>+36 96 503 401</span>
                  </div>
                </div>
                <div className="flex flex-wrap gap-2 mt-4 justify-center">
                  <span className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm">Anxiety Management</span>
                  <span className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm">Stress Reduction</span>
                  <span className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm">Academic Support</span>
                </div>
              </div>
            </Card>

            {/* Counselor 2 */}
            <Card className="p-6 bg-white border-2 border-gray-200 hover:shadow-lg transition-all">
              <div className="flex flex-col items-center text-center">
                <img 
                  src={counselors?.[2]?.photo || "https://images.unsplash.com/photo-1551836022-deb4988cc6c0?w=400&h=400&fit=crop"}
                  alt="Mária Bogdányi"
                  className="w-48 h-48 rounded-full object-cover mb-6 border-4 border-blue-100"
                />
                <h3 className="text-xl font-semibold mb-2" style={{ color: '#00224B' }}>Mária Bogdányi</h3>
                <p className="text-purple-600 font-medium mb-4">Mental Health Specialist</p>
                <p className="text-gray-600 leading-relaxed">
                  Focuses on depression support, relationship counseling, and life transitions. Mária creates a safe, supportive environment for students to explore their emotions.
                </p>
                <div className="flex gap-3 mt-4 justify-center text-sm text-gray-600">
                  <div className="flex items-center gap-2">
                    <Mail className="w-4 h-4" style={{ color: '#005FA3' }} />
                    <span>maria.bogdanyi@sze.hu</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Phone className="w-4 h-4" style={{ color: '#005FA3' }} />
                    <span>+36 96 503 402</span>
                  </div>
                </div>
                <div className="flex flex-wrap gap-2 mt-4 justify-center">
                  <span className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm">Depression Support</span>
                  <span className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm">Relationship Counseling</span>
                  <span className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm">Life Transitions</span>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}