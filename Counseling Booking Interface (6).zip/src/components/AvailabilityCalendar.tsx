import { useState } from "react";
import { Calendar as CalendarIcon, Clock, Check, X, AlertCircle } from "lucide-react";
import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Calendar } from "./ui/calendar";
import { BookedAppointment } from "../App";
import { toast } from "sonner@2.0.3";

interface Counselor {
  id: number;
  name: string;
  title: string;
  photo: string;
  office: string;
  specialties: string[];
}

interface TimeSlot {
  time: string;
  counselor: Counselor;
}

interface UserInfo {
  name: string;
  email: string;
  type: "counselor" | "client" | null;
  avatar?: string;
  neptunId?: string;
}

interface AvailabilityCalendarProps {
  counselors: Counselor[];
  selectedCounselorId: number | null;
  onBookAppointment: (appointment: Omit<BookedAppointment, 'id' | 'status'>) => void;
  bookedAppointments: BookedAppointment[];
  userInfo: UserInfo | null;
}

export function AvailabilityCalendar({ counselors, selectedCounselorId, onBookAppointment, bookedAppointments, userInfo }: AvailabilityCalendarProps) {
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(undefined);
  const [selectedSlot, setSelectedSlot] = useState<TimeSlot | null>(null);
  const [showConfirmation, setShowConfirmation] = useState(false);

  // Helper function to check if a slot is already booked
  const isSlotBooked = (date: Date, time: string, counselorId: number): boolean => {
    return bookedAppointments.some(apt => {
      const aptDate = new Date(apt.date);
      return (
        aptDate.toDateString() === date.toDateString() &&
        apt.time === time &&
        apt.counselor.id === counselorId &&
        apt.status === 'confirmed'
      );
    });
  };

  // Helper function to check if time slot is in the past
  const isTimeSlotPast = (date: Date, time: string): boolean => {
    const now = new Date();
    const slotDate = new Date(date);
    
    // Parse time string (e.g., "9:00 AM" or "2:00 PM")
    const [timeStr, period] = time.split(' ');
    const [hours, minutes] = timeStr.split(':').map(Number);
    let slotHours = hours;
    
    if (period === 'PM' && hours !== 12) {
      slotHours += 12;
    } else if (period === 'AM' && hours === 12) {
      slotHours = 0;
    }
    
    slotDate.setHours(slotHours, minutes, 0, 0);
    
    return slotDate < now;
  };

  // Count user's active bookings
  const getUserActiveBookingsCount = (): number => {
    if (!userInfo?.email) return 0;
    return bookedAppointments.filter(apt => {
      // Check if appointment belongs to current user and is in the future
      const aptDate = new Date(apt.date);
      return apt.client?.email === userInfo.email && 
             apt.status === 'confirmed' &&
             aptDate >= new Date();
    }).length;
  };

  // Get available time slots for a specific date
  const getAvailableSlots = (date: Date): TimeSlot[] => {
    if (!date) return [];
    
    const dayOfWeek = date.getDay();
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    // Don't show slots for past dates or weekends
    if (date < today || dayOfWeek === 0 || dayOfWeek === 6) {
      return [];
    }

    let slots: TimeSlot[] = [];

    // Filter counselors based on selection
    const filteredCounselors = selectedCounselorId 
      ? counselors.filter(c => c.id === selectedCounselorId)
      : counselors;

    // Generate slots for each counselor
    filteredCounselors.forEach(counselor => {
      if (counselor.id === 1) { // Bognár Tamás
        if (dayOfWeek === 1) { // Monday
          slots.push(
            { time: "9:00 AM", counselor },
            { time: "10:30 AM", counselor },
            { time: "2:00 PM", counselor },
            { time: "4:00 PM", counselor }
          );
        } else if (dayOfWeek === 3) { // Wednesday
          slots.push(
            { time: "10:00 AM", counselor },
            { time: "1:00 PM", counselor },
            { time: "3:00 PM", counselor }
          );
        } else if (dayOfWeek === 5) { // Friday
          slots.push(
            { time: "9:00 AM", counselor },
            { time: "11:00 AM", counselor }
          );
        }
      } else if (counselor.id === 2) { // Mária Bogdányi
        if (dayOfWeek === 2) { // Tuesday
          slots.push(
            { time: "10:00 AM", counselor },
            { time: "11:30 AM", counselor },
            { time: "2:00 PM", counselor },
            { time: "3:30 PM", counselor }
          );
        } else if (dayOfWeek === 4) { // Thursday
          slots.push(
            { time: "9:00 AM", counselor },
            { time: "11:00 AM", counselor },
            { time: "2:00 PM", counselor }
          );
        } else if (dayOfWeek === 5) { // Friday
          slots.push(
            { time: "1:00 PM", counselor },
            { time: "3:00 PM", counselor }
          );
        }
      }
    });

    // Filter out booked slots and past time slots
    slots = slots.filter(slot => 
      !isSlotBooked(date, slot.time, slot.counselor.id) && 
      !isTimeSlotPast(date, slot.time)
    );

    return slots;
  };

  // Disable dates that are in the past, weekends, or have no available slots
  const disabledDates = (date: Date) => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const dayOfWeek = date.getDay();
    
    // Disable past dates and weekends
    if (date < today || dayOfWeek === 0 || dayOfWeek === 6) {
      return true;
    }
    
    // Disable dates with no available slots
    const slots = getAvailableSlots(date);
    return slots.length === 0;
  };

  const handleSlotSelect = (slot: TimeSlot) => {
    setSelectedSlot(slot);
  };

  const handleConfirmBooking = () => {
    if (!selectedDate || !selectedSlot) return;

    // Check if user has reached 3 booking limit
    const activeBookingsCount = getUserActiveBookingsCount();
    if (activeBookingsCount >= 3) {
      toast.error("Booking Limit Reached", {
        description: "You have reached the maximum limit of 3 active appointments. Please cancel an existing appointment to book a new one.",
        duration: 6000,
      });
      return;
    }

    // Double-check slot isn't booked (race condition protection)
    if (isSlotBooked(selectedDate, selectedSlot.time, selectedSlot.counselor.id)) {
      toast.error("Slot Already Booked", {
        description: "This time slot has just been booked by someone else. Please select another slot.",
        duration: 5000,
      });
      setSelectedSlot(null);
      return;
    }

    // Check if slot is in the past
    if (isTimeSlotPast(selectedDate, selectedSlot.time)) {
      toast.error("Invalid Time Slot", {
        description: "This time slot is in the past. Please select a future time slot.",
        duration: 5000,
      });
      setSelectedSlot(null);
      return;
    }

    setShowConfirmation(true);

    // Reset after showing confirmation
    setTimeout(() => {
      setShowConfirmation(false);
      setSelectedSlot(null);
      setSelectedDate(null);
    }, 3000);

    // Book the appointment with client info
    if (selectedDate) {
      onBookAppointment({
        date: selectedDate,
        time: selectedSlot.time,
        counselor: selectedSlot.counselor,
        client: userInfo ? {
          name: userInfo.name,
          email: userInfo.email
        } : undefined
      });
      
      // Show success toast
      const selectedDateStr = selectedDate.toLocaleDateString('default', { 
        weekday: 'long', 
        month: 'long', 
        day: 'numeric',
        year: 'numeric'
      });
      
      toast.success("Booking Confirmed", {
        description: `Your appointment with ${selectedSlot.counselor.name} on ${selectedDateStr} at ${selectedSlot.time} has been confirmed.`,
        duration: 5000,
      });
    }
  };

  const availableSlots = selectedDate ? getAvailableSlots(selectedDate) : [];
  const selectedDateStr = selectedDate?.toLocaleDateString('default', { 
    weekday: 'long', 
    month: 'long', 
    day: 'numeric',
    year: 'numeric'
  });

  const getInitials = (name: string) => {
    return name.split(" ").map(n => n[0]).join("").toUpperCase();
  };

  return (
    <div className="space-y-8">
      {/* Show warning if no counselor is selected */}
      {!selectedCounselorId && (
        <Card className="p-6 bg-yellow-50 border-2 border-yellow-300">
          <div className="flex items-start gap-4">
            <AlertCircle className="w-6 h-6 text-yellow-600 flex-shrink-0 mt-1" />
            <div>
              <h3 className="text-yellow-900 font-semibold mb-2">Please Select a Counselor First</h3>
              <p className="text-gray-700">
                To view available appointment slots, please select a counselor from the options above.
              </p>
            </div>
          </div>
        </Card>
      )}

      {/* Only show calendar if counselor is selected */}
      {selectedCounselorId && (
        <>
      {/* Show booking count */}
      {userInfo && (
        <Card className="p-4 bg-blue-50 border-2 border-blue-300">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-700">
                Active Appointments: <span className="font-semibold" style={{ color: '#00224B' }}>{getUserActiveBookingsCount()} / 3</span>
              </p>
            </div>
            {getUserActiveBookingsCount() >= 3 && (
              <div className="flex items-center gap-2 text-orange-700">
                <AlertCircle className="w-5 h-5" />
                <span className="text-sm font-medium">Limit Reached</span>
              </div>
            )}
          </div>
        </Card>
      )}
      
      {/* Calendar and Time Slots - Side by Side */}
      <div className="grid lg:grid-cols-2 gap-6">
        {/* Date Selection Calendar */}
        <Card className="p-6 bg-white border-2 border-gray-200">
          <div className="flex items-center gap-2 mb-4">
            <div className="p-2 rounded" style={{ backgroundColor: '#005FA3' }}>
              <CalendarIcon className="w-5 h-5 text-white" />
            </div>
            <h3 className="font-semibold" style={{ color: '#00224B' }}>
              Select Date
            </h3>
          </div>
          
          <Calendar
            mode="single"
            selected={selectedDate}
            onSelect={(date) => {
              setSelectedDate(date);
              setSelectedSlot(null);
            }}
            disabled={disabledDates}
            className="rounded-lg border-2 border-gray-200"
          />
          
          <p className="text-xs text-gray-600 mt-3">
            Weekends and past dates are disabled
          </p>
        </Card>

        {/* Available Time Slots for Selected Date */}
        {selectedDate && availableSlots.length > 0 && (
          <Card className="p-6 bg-white border-2 border-gray-200">
            <div className="flex items-center gap-2 mb-6">
              <div className="p-2 rounded" style={{ backgroundColor: '#005FA3' }}>
                <Clock className="w-5 h-5 text-white" />
              </div>
              <div>
                <h3 className="font-semibold" style={{ color: '#00224B' }}>Select Your Time Slot</h3>
                <p className="text-sm text-gray-600">{selectedDateStr}</p>
              </div>
            </div>

            <div className="space-y-3 max-h-[500px] overflow-y-auto pr-2">
              {availableSlots.map((slot, index) => {
                const isSelected = selectedSlot?.time === slot.time && 
                                  selectedSlot?.counselor.id === slot.counselor.id;
                
                return (
                  <button
                    key={index}
                    onClick={() => handleSlotSelect(slot)}
                    className={`w-full p-5 rounded-xl text-left transition-all duration-200 ${
                      isSelected
                        ? 'bg-gradient-to-br from-blue-500 to-purple-500 text-white shadow-xl scale-105 ring-4 ring-blue-200'
                        : 'bg-gradient-to-br from-blue-50 to-purple-50 border-2 border-blue-200 hover:shadow-lg hover:scale-105 hover:border-blue-300'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-2">
                        <Clock className={`w-4 h-4 ${isSelected ? 'text-white' : 'text-emerald-600'}`} />
                        <span className={`font-medium ${isSelected ? 'text-white' : 'text-gray-900'}`}>
                          {slot.time}
                        </span>
                      </div>
                      {isSelected && (
                        <div className="p-1 bg-white/20 rounded-full">
                          <Check className="w-4 h-4" />
                        </div>
                      )}
                    </div>
                    
                    <div className="flex items-center gap-3">
                      <Avatar className={`w-10 h-10 ${isSelected ? 'border-2 border-white' : 'border-2 border-emerald-200'}`}>
                        <AvatarImage src={slot.counselor.photo} />
                        <AvatarFallback className={`text-xs ${isSelected ? 'bg-white/20 text-white' : 'bg-emerald-200 text-emerald-900'}`}>
                          {getInitials(slot.counselor.name)}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <p className={`text-sm truncate ${isSelected ? 'text-white' : 'text-gray-900'}`}>
                          {slot.counselor.name}
                        </p>
                        <p className={`text-xs truncate ${isSelected ? 'text-emerald-100' : 'text-gray-600'}`}>
                          {slot.counselor.title}
                        </p>
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Booking Confirmation Button */}
            {selectedSlot && (
              <div className="mt-6 pt-6 border-t border-gray-200">
                <div className="p-4 rounded-lg mb-4 border-2" style={{ backgroundColor: '#f0f9ff', borderColor: '#005FA3' }}>
                  <p className="text-sm font-medium mb-2" style={{ color: '#00224B' }}>📅 Selected Appointment:</p>
                  <p className="text-gray-700">{selectedDateStr} at {selectedSlot.time}</p>
                  <p className="text-sm text-gray-600 mt-1">with {selectedSlot.counselor.name}</p>
                </div>
                <Button
                  onClick={handleConfirmBooking}
                  className="w-full text-white shadow-lg py-6"
                  style={{ backgroundColor: '#005FA3' }}
                >
                  <Check className="w-5 h-5 mr-2" />
                  Confirm Appointment with {selectedSlot.counselor.name}
                </Button>
              </div>
            )}
          </Card>
        )}

        {/* No slots available message */}
        {selectedDate && availableSlots.length === 0 && (
          <Card className="p-6 bg-white border-2 border-gray-200">
            <div className="flex items-center gap-2 mb-4">
              <div className="p-2 rounded bg-gray-300">
                <Clock className="w-5 h-5 text-gray-600" />
              </div>
              <div>
                <h3 className="font-semibold" style={{ color: '#00224B' }}>No Available Slots</h3>
                <p className="text-sm text-gray-600">{selectedDateStr}</p>
              </div>
            </div>
            <p className="text-sm text-gray-600">
              There are no available time slots on this date. Please select a different date.
            </p>
          </Card>
        )}

        {/* Instructions when no date selected */}
        {!selectedDate && (
          <Card className="p-6 bg-white border-2 border-gray-200">
            <div className="flex items-center gap-2 mb-4">
              <div className="p-2 rounded" style={{ backgroundColor: '#005FA3' }}>
                <CalendarIcon className="w-5 h-5 text-white" />
              </div>
              <h3 className="font-semibold" style={{ color: '#00224B' }}>How to Book</h3>
            </div>
            <ol className="space-y-3 text-sm text-gray-700">
              <li className="flex gap-2">
                <span className="font-semibold" style={{ color: '#005FA3' }}>1.</span>
                <span>Select a counselor above to view their available appointment slots</span>
              </li>
              <li className="flex gap-2">
                <span className="font-semibold" style={{ color: '#005FA3' }}>2.</span>
                <span>Select a date from the calendar to view available time slots</span>
              </li>
              <li className="flex gap-2">
                <span className="font-semibold" style={{ color: '#005FA3' }}>3.</span>
                <span>Choose your preferred time slot and confirm your booking</span>
              </li>
            </ol>
          </Card>
        )}
      </div>

      {/* Success Confirmation */}
      {showConfirmation && (
        <Card className="p-6 text-white shadow-xl animate-in fade-in slide-in-from-bottom-4 duration-300" style={{ backgroundColor: '#005FA3' }}>
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-white/20 rounded-full">
                <Check className="w-8 h-8" />
              </div>
              <div>
                <h3 className="text-xl">Appointment Confirmed!</h3>
                <p className="text-blue-100">
                  Your appointment has been successfully booked for {selectedDateStr} at {selectedSlot?.time}
                </p>
                <p className="text-blue-100 text-sm mt-1">
                  You will receive a confirmation email shortly.
                </p>
              </div>
            </div>
            <button
              onClick={() => setShowConfirmation(false)}
              className="p-2 hover:bg-white/20 rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </Card>
      )}
        </>
      )}
    </div>
  );
}