import { Calendar, Clock, User, MessageSquare, Check, X } from "lucide-react";
import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { AppointmentRequestData } from "./AppointmentRequest";
import { toast } from "sonner@2.0.3";

interface AppointmentRequestsProps {
  requests: AppointmentRequestData[];
  onAcceptRequest: (requestId: string) => void;
  onRejectRequest: (requestId: string) => void;
  userInfo: {
    name: string;
    email: string;
  };
}

export function AppointmentRequests({ 
  requests, 
  onAcceptRequest, 
  onRejectRequest,
  userInfo 
}: AppointmentRequestsProps) {
  
  // Filter requests for the current counselor
  const counselorRequests = requests.filter(
    request => request.counselorName === userInfo.name
  );

  const pendingRequests = counselorRequests.filter(r => r.status === 'pending');
  const processedRequests = counselorRequests.filter(r => r.status !== 'pending');

  const handleAccept = (request: AppointmentRequestData) => {
    onAcceptRequest(request.id);
    toast.success("Request Accepted", {
      description: `Appointment with ${request.patientName} has been added to your schedule`,
      duration: 5000,
    });
  };

  const handleReject = (request: AppointmentRequestData) => {
    onRejectRequest(request.id);
    toast.success("Request Rejected", {
      description: `Request from ${request.patientName} has been declined`,
      duration: 5000,
    });
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('default', { 
      weekday: 'long',
      month: 'long', 
      day: 'numeric',
      year: 'numeric' 
    });
  };

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase();
  };

  return (
    <div className="px-0">
      <div className="max-w-5xl mx-auto">
        {/* Statistics */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <Card className="p-4 bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
            <div className="text-2xl text-blue-700 mb-1">{counselorRequests.length}</div>
            <p className="text-sm text-gray-700">Total Requests</p>
          </Card>
          <Card className="p-4 bg-gradient-to-br from-yellow-50 to-yellow-100 border-yellow-200">
            <div className="text-2xl text-yellow-700 mb-1">{pendingRequests.length}</div>
            <p className="text-sm text-gray-700">Pending</p>
          </Card>
          <Card className="p-4 bg-gradient-to-br from-green-50 to-green-100 border-green-200">
            <div className="text-2xl text-green-700 mb-1">
              {counselorRequests.filter(r => r.status === 'accepted').length}
            </div>
            <p className="text-sm text-gray-700">Accepted</p>
          </Card>
        </div>

        {/* Pending Requests */}
        {pendingRequests.length > 0 && (
          <div className="mb-8">
            <h2 className="text-xl mb-4 text-gray-800">Pending Requests</h2>
            <div className="space-y-4">
              {pendingRequests.map((request) => (
                <Card key={request.id} className="overflow-hidden bg-white/90 shadow-lg hover:shadow-xl transition-shadow">
                  <div className="p-6">
                    <div className="flex flex-col lg:flex-row gap-6">
                      {/* Patient Info */}
                      <div className="flex items-start gap-4">
                        <Avatar className="w-16 h-16 border-4 border-blue-100 flex-shrink-0">
                          <AvatarImage src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${request.patientEmail}`} />
                          <AvatarFallback className="bg-gradient-to-br from-blue-200 to-purple-200 text-blue-900">
                            {getInitials(request.patientName)}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <h3 className="text-gray-800 mb-1">{request.patientName}</h3>
                          <p className="text-sm text-gray-600 mb-2">{request.patientEmail}</p>
                          <Badge className="bg-yellow-100 text-yellow-800 border-yellow-300">
                            Pending Review
                          </Badge>
                        </div>
                      </div>

                      {/* Request Details */}
                      <div className="flex-1 space-y-3">
                        <div className="flex items-start gap-3">
                          <div className="p-2 bg-blue-100 rounded-lg flex-shrink-0">
                            <Calendar className="w-4 h-4 text-blue-700" />
                          </div>
                          <div>
                            <p className="text-xs text-gray-600 mb-1">Preferred Date</p>
                            <p className="text-gray-900">{formatDate(request.preferredDate)}</p>
                          </div>
                        </div>

                        <div className="flex items-start gap-3">
                          <div className="p-2 bg-purple-100 rounded-lg flex-shrink-0">
                            <Clock className="w-4 h-4 text-purple-700" />
                          </div>
                          <div>
                            <p className="text-xs text-gray-600 mb-1">Preferred Time</p>
                            <p className="text-gray-900">{request.preferredTime}</p>
                          </div>
                        </div>

                        {request.comment && (
                          <div className="flex items-start gap-3">
                            <div className="p-2 bg-pink-100 rounded-lg flex-shrink-0">
                              <MessageSquare className="w-4 h-4 text-pink-700" />
                            </div>
                            <div>
                              <p className="text-xs text-gray-600 mb-1">Comment</p>
                              <p className="text-gray-900 text-sm">{request.comment}</p>
                            </div>
                          </div>
                        )}
                      </div>

                      {/* Action Buttons */}
                      <div className="flex lg:flex-col gap-3 justify-end lg:justify-start">
                        <Button
                          onClick={() => handleAccept(request)}
                          className="flex-1 lg:flex-none bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white"
                        >
                          <Check className="w-4 h-4 mr-2" />
                          Accept
                        </Button>
                        <Button
                          onClick={() => handleReject(request)}
                          variant="outline"
                          className="flex-1 lg:flex-none border-red-300 text-red-700 hover:bg-red-50 hover:border-red-400"
                        >
                          <X className="w-4 h-4 mr-2" />
                          Reject
                        </Button>
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Processed Requests */}
        {processedRequests.length > 0 && (
          <div>
            <h2 className="text-xl mb-4 text-gray-800">Processed Requests</h2>
            <div className="space-y-4">
              {processedRequests.map((request) => (
                <Card key={request.id} className="overflow-hidden bg-gray-50/90 border-gray-200">
                  <div className="p-6">
                    <div className="flex flex-col lg:flex-row gap-6 items-start">
                      {/* Patient Info */}
                      <div className="flex items-start gap-4">
                        <Avatar className="w-12 h-12 border-2 border-gray-200 flex-shrink-0">
                          <AvatarImage src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${request.patientEmail}`} />
                          <AvatarFallback className="bg-gradient-to-br from-gray-200 to-gray-300 text-gray-700">
                            {getInitials(request.patientName)}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <h3 className="text-gray-800">{request.patientName}</h3>
                          <p className="text-sm text-gray-600">{request.patientEmail}</p>
                        </div>
                      </div>

                      {/* Request Details */}
                      <div className="flex-1 flex flex-wrap gap-6">
                        <div>
                          <p className="text-xs text-gray-600 mb-1">Date</p>
                          <p className="text-gray-900 text-sm">{formatDate(request.preferredDate)}</p>
                        </div>
                        <div>
                          <p className="text-xs text-gray-600 mb-1">Time</p>
                          <p className="text-gray-900 text-sm">{request.preferredTime}</p>
                        </div>
                        <div>
                          <p className="text-xs text-gray-600 mb-1">Status</p>
                          <Badge 
                            className={
                              request.status === 'accepted'
                                ? "bg-green-100 text-green-800 border-green-300"
                                : "bg-red-100 text-red-800 border-red-300"
                            }
                          >
                            {request.status === 'accepted' ? 'Accepted' : 'Rejected'}
                          </Badge>
                        </div>
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Empty State */}
        {counselorRequests.length === 0 && (
          <Card className="p-12 text-center bg-white/90">
            <Calendar className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-gray-800 mb-2">No Appointment Requests</h3>
            <p className="text-gray-600">
              You don't have any appointment requests at the moment.
            </p>
          </Card>
        )}
      </div>
    </div>
  );
}