import { useState } from "react";
import { Calendar as CalendarIcon, Clock, Plus, Check, Video, MapPin } from "lucide-react";
import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { Label } from "./ui/label";
import { Textarea } from "./ui/textarea";
import { Calendar } from "./ui/calendar";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select";
import { useLanguage } from "../contexts/LanguageContext";

export function CreateAppointmentForm() {
  const { t } = useLanguage();
  const [date, setDate] = useState<Date>();
  const [formData, setFormData] = useState({
    timeSlot: "",
    duration: "50",
    sessionType: "",
    counselingType: "",
    notes: ""
  });
  const [showConfirmation, setShowConfirmation] = useState(false);

  const timeSlots = [
    "09:00", "09:30", "10:00", "10:30", "11:00", "11:30",
    "12:00", "12:30", "13:00", "13:30", "14:00", "14:30",
    "15:00", "15:30", "16:00", "16:30", "17:00"
  ];

  const counselingTypes = [
    { value: "anxiety", label: t("Anxiety Management", "Szorongáskezelés") },
    { value: "depression", label: t("Depression Support", "Depresszió Támogatás") },
    { value: "stress", label: t("Stress Reduction", "Stresszcsökkentés") },
    { value: "academic", label: t("Academic Support", "Tanulmányi Támogatás") },
    { value: "relationship", label: t("Relationship Counseling", "Kapcsolati Tanácsadás") },
    { value: "life-transitions", label: t("Life Transitions", "Élethelyzet Változások") },
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setShowConfirmation(true);
    
    // Reset after 3 seconds
    setTimeout(() => {
      setShowConfirmation(false);
      setFormData({
        timeSlot: "",
        duration: "50",
        sessionType: "",
        counselingType: "",
        notes: ""
      });
      setDate(undefined);
    }, 3000);
  };

  const isFormValid = date && formData.timeSlot && formData.sessionType && formData.counselingType;

  // Filter out past dates and disable past time slots
  const disabledDates = (date: Date) => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return date < today || date.getDay() === 0 || date.getDay() === 6; // Disable weekends
  };

  // Check if time slot is in the past
  const isTimeSlotPast = (timeSlot: string) => {
    if (!date) return false;
    const today = new Date();
    const selectedDate = new Date(date);
    selectedDate.setHours(0, 0, 0, 0);
    const todayDate = new Date();
    todayDate.setHours(0, 0, 0, 0);
    
    // If selected date is today, check time
    if (selectedDate.getTime() === todayDate.getTime()) {
      const [hours, minutes] = timeSlot.split(":").map(Number);
      const slotTime = new Date();
      slotTime.setHours(hours, minutes, 0, 0);
      return slotTime < today;
    }
    return false;
  };

  return (
    <div className="max-w-4xl mx-auto">
      {/* Success Message */}
      {showConfirmation && (
        <Card className="mb-6 p-6 text-white shadow-xl animate-in fade-in slide-in-from-bottom-4 duration-300" style={{ backgroundColor: '#005FA3' }}>
          <div className="flex items-center gap-4">
            <div className="p-3 bg-white/20 rounded-full">
              <Check className="w-8 h-8" />
            </div>
            <div>
              <h3 className="text-xl font-semibold">
                {t("Appointment Created Successfully!", "Időpont Sikeresen Létrehozva!")}
              </h3>
              <p className="text-blue-100">
                {t("The appointment has been scheduled for", "Az időpont ütemezve:")} {date?.toLocaleDateString()} {t("at", "időpontban:")} {formData.timeSlot}
              </p>
            </div>
          </div>
        </Card>
      )}

      <form onSubmit={handleSubmit}>
        <div className="grid lg:grid-cols-2 gap-6">
          {/* Left Column - Session Details */}
          <div className="space-y-6">
            {/* Date Selection */}
            <Card className="p-6 bg-white border-2 border-gray-200">
              <div className="flex items-center gap-2 mb-4">
                <div className="p-2 rounded" style={{ backgroundColor: '#005FA3' }}>
                  <CalendarIcon className="w-5 h-5 text-white" />
                </div>
                <h3 className="font-semibold" style={{ color: '#00224B' }}>
                  {t("Select Date", "Válassz Dátumot")} *
                </h3>
              </div>
              
              <Calendar
                mode="single"
                selected={date}
                onSelect={setDate}
                disabled={disabledDates}
                className="rounded-lg border-2 border-gray-200"
              />
              
              <p className="text-xs text-gray-600 mt-3">
                {t("Weekends and past dates are disabled", "Hétvégék és múltbeli dátumok tiltottak")}
              </p>
            </Card>

            {/* Time Selection */}
            <Card className="p-6 bg-white border-2 border-gray-200">
              <div className="flex items-center gap-2 mb-4">
                <div className="p-2 rounded" style={{ backgroundColor: '#005FA3' }}>
                  <Clock className="w-5 h-5 text-white" />
                </div>
                <h3 className="font-semibold" style={{ color: '#00224B' }}>
                  {t("Time & Duration", "Idő és Időtartam")}
                </h3>
              </div>

              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="timeSlot">{t("Time Slot", "Időpont")} *</Label>
                  <Select value={formData.timeSlot} onValueChange={(value) => setFormData({ ...formData, timeSlot: value })}>
                    <SelectTrigger className="border-gray-300">
                      <SelectValue placeholder={t("Select time slot", "Válassz időpontot")} />
                    </SelectTrigger>
                    <SelectContent>
                      {timeSlots.map((slot) => (
                        <SelectItem 
                          key={slot} 
                          value={slot}
                          disabled={isTimeSlotPast(slot)}
                        >
                          {slot} {isTimeSlotPast(slot) ? `(${t("Past", "Múlt")})` : ""}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="duration">{t("Duration (minutes)", "Időtartam (perc)")}</Label>
                  <Select value={formData.duration} onValueChange={(value) => setFormData({ ...formData, duration: value })}>
                    <SelectTrigger className="border-gray-300">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="30">30 {t("minutes", "perc")}</SelectItem>
                      <SelectItem value="45">45 {t("minutes", "perc")}</SelectItem>
                      <SelectItem value="50">50 {t("minutes", "perc")}</SelectItem>
                      <SelectItem value="60">60 {t("minutes", "perc")}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </Card>
          </div>

          {/* Right Column - Session Type & Counseling Type */}
          <div className="space-y-6">
            {/* Session Type */}
            <Card className="p-6 bg-white border-2 border-gray-200">
              <div className="flex items-center gap-2 mb-4">
                <div className="p-2 rounded" style={{ backgroundColor: '#005FA3' }}>
                  <Video className="w-5 h-5 text-white" />
                </div>
                <h3 className="font-semibold" style={{ color: '#00224B' }}>
                  {t("Session Type", "Ülés Típusa")} *
                </h3>
              </div>

              <div className="space-y-3">
                <button
                  type="button"
                  onClick={() => setFormData({ ...formData, sessionType: "online" })}
                  className={`w-full p-4 rounded-lg border-2 transition-all text-left ${
                    formData.sessionType === "online"
                      ? "border-blue-500 bg-blue-50"
                      : "border-gray-300 hover:border-gray-400"
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <Video className="w-6 h-6" style={{ color: '#005FA3' }} />
                    <div>
                      <p className="font-semibold text-gray-900">{t("Online Session", "Online Ülés")}</p>
                      <p className="text-sm text-gray-600">{t("Video call via secure platform", "Videóhívás biztonságos platformon")}</p>
                    </div>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setFormData({ ...formData, sessionType: "in-person" })}
                  className={`w-full p-4 rounded-lg border-2 transition-all text-left ${
                    formData.sessionType === "in-person"
                      ? "border-blue-500 bg-blue-50"
                      : "border-gray-300 hover:border-gray-400"
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <MapPin className="w-6 h-6" style={{ color: '#005FA3' }} />
                    <div>
                      <p className="font-semibold text-gray-900">{t("In-Person Session", "Személyes Ülés")}</p>
                      <p className="text-sm text-gray-600">{t("Face-to-face at the office", "Személyes találkozó az irodában")}</p>
                    </div>
                  </div>
                </button>
              </div>
            </Card>

            {/* Counseling Type */}
            <Card className="p-6 bg-white border-2 border-gray-200">
              <Label htmlFor="counselingType" className="mb-3 block">
                {t("Type of Counseling", "Tanácsadás Típusa")} *
              </Label>
              <Select value={formData.counselingType} onValueChange={(value) => setFormData({ ...formData, counselingType: value })}>
                <SelectTrigger className="border-gray-300">
                  <SelectValue placeholder={t("Select counseling type", "Válassz tanácsadási típust")} />
                </SelectTrigger>
                <SelectContent>
                  {counselingTypes.map((type) => (
                    <SelectItem key={type.value} value={type.value}>
                      {type.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </Card>

            {/* Session Notes */}
            <Card className="p-6 bg-white border-2 border-gray-200">
              <Label htmlFor="notes" className="mb-3 block">
                {t("Session Notes (Optional)", "Ülés Jegyzetek (Opcionális)")}
              </Label>
              <Textarea
                id="notes"
                placeholder={t("Any important notes about this session...", "Fontos megjegyzések az ülésről...")}
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                rows={4}
                className="border-gray-300"
              />
            </Card>
          </div>
        </div>

        {/* Submit Button */}
        <div className="mt-6">
          <Card className="p-6 bg-gray-50 border-2 border-gray-200">
            {date && formData.timeSlot && formData.sessionType && (
              <div className="mb-4 p-4 bg-white rounded-lg border-2" style={{ borderColor: '#005FA3' }}>
                <p className="text-sm font-semibold mb-2" style={{ color: '#00224B' }}>📅 {t("Appointment Summary", "Időpont Összefoglaló")}:</p>
                <p className="text-gray-700">
                  <strong>{date.toLocaleDateString('default', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' })}</strong> {t("at", "időpontban:")} {" "}
                  <strong>{formData.timeSlot}</strong> ({formData.duration} {t("minutes", "perc")})
                </p>
                <p className="text-sm text-gray-600 mt-1">
                  {formData.sessionType === "online" ? t("Online Session", "Online Ülés") : t("In-Person Session", "Személyes Ülés")}
                </p>
              </div>
            )}
            
            <Button
              type="submit"
              disabled={!isFormValid}
              className="w-full text-white font-semibold py-6 text-lg"
              style={{ backgroundColor: isFormValid ? '#005FA3' : '#9ca3af' }}
            >
              <Plus className="w-5 h-5 mr-2" />
              {t("Create Appointment", "Időpont Létrehozása")}
            </Button>

            {!isFormValid && (
              <p className="text-sm text-gray-600 text-center mt-3">
                {t("Please fill in all required fields to create an appointment", "Kérjük, töltse ki az összes kötelező mezőt")}
              </p>
            )}
          </Card>
        </div>
      </form>
    </div>
  );
}
