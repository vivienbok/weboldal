import { useState } from "react";
import { GraduationCap, Mail, Lock, Eye, EyeOff, AlertCircle, UserCheck, Users, User } from "lucide-react";
import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Checkbox } from "./ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";

interface UnifiedLoginProps {
  onLogin: (email: string, password: string, userType: "counselor" | "client" | "admin") => void;
}

// All demo accounts (counselors, clients, and admin)
const ALL_ACCOUNTS = [
  { 
    email: "counselor@demo.com", 
    password: "demo123",
    name: "Bognár Tamás", 
    type: "counselor" as const
  },
  { 
    email: "client@demo.com", 
    password: "demo123",
    name: "Demo Client", 
    type: "client" as const
  },
  { 
    email: "admin@demo.com", 
    password: "admin123",
    name: "Admin User", 
    type: "admin" as const
  },
];

export function UnifiedLogin({ onLogin }: UnifiedLoginProps) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const [rememberPassword, setRememberPassword] = useState(false);
  const [isRegistering, setIsRegistering] = useState(false);
  const [registrationData, setRegistrationData] = useState({
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
    userType: "client" as "client" | "counselor"
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    // Validate credentials
    const validAccount = ALL_ACCOUNTS.find(
      account => account.email === email && account.password === password
    );

    if (validAccount) {
      onLogin(email, password, validAccount.type);
    } else {
      setError("Invalid email or password. Please try one of the demo accounts below.");
    }
  };

  const handleDemoAccountClick = (account: typeof ALL_ACCOUNTS[0]) => {
    onLogin(account.email, account.password, account.type);
  };

  const handleRegistration = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    // Validate registration
    if (registrationData.password !== registrationData.confirmPassword) {
      setError("Passwords do not match");
      return;
    }

    if (registrationData.password.length < 6) {
      setError("Password must be at least 6 characters long");
      return;
    }

    // Check if email already exists
    const emailExists = ALL_ACCOUNTS.some(acc => acc.email === registrationData.email);
    if (emailExists) {
      setError("An account with this email already exists");
      return;
    }

    // Registration successful - for demo purposes, we'll just switch to login
    setError("");
    setEmail(registrationData.email);
    setIsRegistering(false);
    alert(`Registration successful! In a production app, account would be created for ${registrationData.name}. For now, please use one of the demo accounts to login.`);
    
    // Reset registration form
    setRegistrationData({
      name: "",
      email: "",
      password: "",
      confirmPassword: "",
      userType: "client"
    });
  };

  // Separate accounts by type
  const counselorAccounts = ALL_ACCOUNTS.filter(acc => acc.type === "counselor");
  const clientAccounts = ALL_ACCOUNTS.filter(acc => acc.type === "client");
  const adminAccounts = ALL_ACCOUNTS.filter(acc => acc.type === "admin");

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      {/* Header Bar */}
      <div className="fixed top-0 left-0 right-0 bg-white border-b-2 border-gray-200 z-50">
        <div className="px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded" style={{ backgroundColor: '#00224B' }}>
              <GraduationCap className="w-8 h-8 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-semibold" style={{ color: '#00224B' }}>
                Széchenyi István University
              </h1>
              <p className="text-sm text-gray-600">Student Counseling Services</p>
            </div>
          </div>
        </div>
      </div>

      <div className="w-full max-w-md relative z-10 mt-20">
        {/* Login Card */}
        <Card className="p-8 md:p-10 bg-white/95 backdrop-blur-lg border-gray-200 shadow-2xl">
          {/* Logo and Header */}
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl shadow-lg mb-4" style={{ backgroundColor: '#00224B' }}>
              <GraduationCap className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-2xl mb-2" style={{ color: '#00224B' }}>
              {isRegistering ? 'Create Account' : 'Counseling Portal'}
            </h1>
            <p className="text-gray-600">
              {isRegistering ? 'Register for counseling services' : 'Sign in to your account'}
            </p>
          </div>

          {!isRegistering ? (
            // Login Form
            <form onSubmit={handleSubmit} className="space-y-5">
              {/* Error Message */}
              {error && (
                <div className="flex items-start gap-3 p-4 bg-red-50 border border-red-200 rounded-lg">
                  <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                  <p className="text-sm text-red-800">{error}</p>
                </div>
              )}

              {/* Email Field */}
              <div className="space-y-2">
                <Label htmlFor="email" className="text-gray-700">
                  Email Address
                </Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <Input
                    id="email"
                    type="email"
                    placeholder="your.email@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="pl-10 border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                    required
                  />
                </div>
              </div>

              {/* Password Field */}
              <div className="space-y-2">
                <Label htmlFor="password" className="text-gray-700">
                  Password
                </Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <Input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    placeholder="Enter your password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="pl-10 pr-10 border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                  >
                    {showPassword ? (
                      <EyeOff className="w-5 h-5" />
                    ) : (
                      <Eye className="w-5 h-5" />
                    )}
                  </button>
                </div>
              </div>

              {/* Remember Password Checkbox */}
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="remember-password"
                  checked={rememberPassword}
                  onCheckedChange={(checked) => setRememberPassword(checked as boolean)}
                />
                <Label 
                  htmlFor="remember-password" 
                  className="text-sm text-gray-700 cursor-pointer"
                >
                  Remember password
                </Label>
              </div>

              {/* Login Button */}
              <Button
                type="submit"
                className="w-full text-white shadow-lg py-6"
                style={{ backgroundColor: '#005FA3' }}
              >
                Login to Portal
              </Button>

              {/* Switch to Registration */}
              <div className="text-center">
                <button
                  type="button"
                  onClick={() => {
                    setIsRegistering(true);
                    setError("");
                  }}
                  className="text-sm hover:underline"
                  style={{ color: '#005FA3' }}
                >
                  Don&apos;t have an account? Sign Up
                </button>
              </div>
            </form>
          ) : (
            // Registration Form
            <form onSubmit={handleRegistration} className="space-y-5">
              {/* Error Message */}
              {error && (
                <div className="flex items-start gap-3 p-4 bg-red-50 border border-red-200 rounded-lg">
                  <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                  <p className="text-sm text-red-800">{error}</p>
                </div>
              )}

              {/* Name Field */}
              <div className="space-y-2">
                <Label htmlFor="reg-name" className="text-gray-700">
                  Full Name
                </Label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <Input
                    id="reg-name"
                    type="text"
                    placeholder="Your full name"
                    value={registrationData.name}
                    onChange={(e) => setRegistrationData({ ...registrationData, name: e.target.value })}
                    className="pl-10 border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                    required
                  />
                </div>
              </div>

              {/* Email Field */}
              <div className="space-y-2">
                <Label htmlFor="reg-email" className="text-gray-700">
                  Email Address
                </Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <Input
                    id="reg-email"
                    type="email"
                    placeholder="your.email@example.com"
                    value={registrationData.email}
                    onChange={(e) => setRegistrationData({ ...registrationData, email: e.target.value })}
                    className="pl-10 border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                    required
                  />
                </div>
              </div>

              {/* User Type */}
              <div className="space-y-2">
                <Label htmlFor="user-type" className="text-gray-700">
                  I am a...
                </Label>
                <Select 
                  value={registrationData.userType} 
                  onValueChange={(value: "client" | "counselor") => setRegistrationData({ ...registrationData, userType: value })}
                >
                  <SelectTrigger className="border-gray-300">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="client">Student</SelectItem>
                    <SelectItem value="counselor">Counselor</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Password Field */}
              <div className="space-y-2">
                <Label htmlFor="reg-password" className="text-gray-700">
                  Password
                </Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <Input
                    id="reg-password"
                    type={showPassword ? "text" : "password"}
                    placeholder="Create a password"
                    value={registrationData.password}
                    onChange={(e) => setRegistrationData({ ...registrationData, password: e.target.value })}
                    className="pl-10 pr-10 border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                  >
                    {showPassword ? (
                      <EyeOff className="w-5 h-5" />
                    ) : (
                      <Eye className="w-5 h-5" />
                    )}
                  </button>
                </div>
              </div>

              {/* Confirm Password Field */}
              <div className="space-y-2">
                <Label htmlFor="reg-confirm-password" className="text-gray-700">
                  Confirm Password
                </Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <Input
                    id="reg-confirm-password"
                    type={showPassword ? "text" : "password"}
                    placeholder="Confirm your password"
                    value={registrationData.confirmPassword}
                    onChange={(e) => setRegistrationData({ ...registrationData, confirmPassword: e.target.value })}
                    className="pl-10 border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                    required
                  />
                </div>
              </div>

              {/* Register Button */}
              <Button
                type="submit"
                className="w-full text-white shadow-lg py-6"
                style={{ backgroundColor: '#005FA3' }}
              >
                Create Account
              </Button>

              {/* Switch to Login */}
              <div className="text-center">
                <button
                  type="button"
                  onClick={() => {
                    setIsRegistering(false);
                    setError("");
                  }}
                  className="text-sm hover:underline"
                  style={{ color: '#005FA3' }}
                >
                  Already have an account? Login
                </button>
              </div>
            </form>
          )}

          {/* Additional Info */}
          <div className="mt-6 pt-6 border-t border-gray-200">
            <p className="text-xs text-gray-500 text-center">
              By {isRegistering ? 'creating an account' : 'logging in'}, you agree to our Terms of Service and Privacy Policy.
            </p>
          </div>
        </Card>

        {/* Demo Accounts Section */}
        <Card className="mt-6 p-6 bg-white border-2 border-gray-200">
          <h3 className="font-bold mb-4 text-center" style={{ color: '#00224B' }}>Demo Accounts</h3>
          
          <div className="space-y-4">
            {/* Counselor Demo Accounts */}
            <div>
              <div className="flex items-center gap-2 mb-3">
                <UserCheck className="w-5 h-5" style={{ color: '#005FA3' }} />
                <h4 className="font-semibold" style={{ color: '#00224B' }}>Counselors</h4>
              </div>
              <div className="space-y-2">
                {counselorAccounts.map((account) => (
                  <button
                    key={account.email}
                    onClick={() => handleDemoAccountClick(account)}
                    className="w-full p-3 bg-blue-50 rounded-lg border-2 border-blue-200 hover:border-blue-400 hover:shadow-md transition-all text-left"
                  >
                    <p className="font-semibold text-gray-900">{account.name}</p>
                    <p className="text-sm text-gray-600">{account.email}</p>
                  </button>
                ))}
              </div>
            </div>

            {/* Student Demo Accounts */}
            <div>
              <div className="flex items-center gap-2 mb-3">
                <Users className="w-5 h-5" style={{ color: '#1E90FF' }} />
                <h4 className="font-semibold" style={{ color: '#00224B' }}>Students</h4>
              </div>
              <div className="space-y-2">
                {clientAccounts.map((account) => (
                  <button
                    key={account.email}
                    onClick={() => handleDemoAccountClick(account)}
                    className="w-full p-3 bg-green-50 rounded-lg border-2 border-green-200 hover:border-green-400 hover:shadow-md transition-all text-left"
                  >
                    <p className="font-semibold text-gray-900">{account.name}</p>
                    <p className="text-sm text-gray-600">{account.email}</p>
                  </button>
                ))}
              </div>
            </div>

            {/* Admin Demo Account */}
            {adminAccounts.length > 0 && (
              <div>
                <div className="flex items-center gap-2 mb-3">
                  <UserCheck className="w-5 h-5" style={{ color: '#FF6B6B' }} />
                  <h4 className="font-semibold" style={{ color: '#00224B' }}>Administrator</h4>
                </div>
                <div className="space-y-2">
                  {adminAccounts.map((account) => (
                    <button
                      key={account.email}
                      onClick={() => handleDemoAccountClick(account)}
                      className="w-full p-3 bg-red-50 rounded-lg border-2 border-red-200 hover:border-red-400 hover:shadow-md transition-all text-left"
                    >
                      <p className="font-semibold text-gray-900">{account.name}</p>
                      <p className="text-sm text-gray-600">{account.email}</p>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </Card>

        {/* Help Section */}
        <div className="mt-6 text-center">
          <p className="text-sm text-gray-600">
            Need assistance?{" "}
            <a href="mailto:counseling@sze.hu" className="font-medium hover:underline" style={{ color: '#005FA3' }}>
              Contact Support
            </a>
          </p>
        </div>
      </div>
    </div>
  );
}