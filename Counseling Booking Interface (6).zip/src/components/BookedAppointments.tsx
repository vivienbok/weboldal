import { useState } from "react";
import { Calendar, Clock, MapPin, Edit, Trash2, X, Check } from "lucide-react";
import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { RescheduleDialog } from "./RescheduleDialog";
import { BookedAppointment } from "../App";
import { toast } from "sonner@2.0.3";
import { TimeSlotManagement, TimeSlot } from "./TimeSlotManagement";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { AppointmentRequestData } from "./AppointmentRequest";
import { AppointmentRequests } from "./AppointmentRequests";

type Page = "home" | "booking" | "appointments" | "profile" | "statistics" | "session-notes" | "admin" | "login" | "requests";

interface UserInfo {
  name: string;
  email: string;
  type: "counselor" | "client" | "admin" | null;
  avatar?: string;
  neptunId?: string;
}

interface BookedAppointmentsProps {
  appointments: BookedAppointment[];
  onCancelAppointment: (id: string) => void;
  userInfo: UserInfo | null;
  timeSlots?: TimeSlot[];
  onAddTimeSlot?: (timeSlot: Omit<TimeSlot, 'id'>) => void;
  onEditTimeSlot?: (id: string, timeSlot: Omit<TimeSlot, 'id'>) => void;
  onDeleteTimeSlot?: (id: string) => void;
  appointmentRequests?: AppointmentRequestData[];
  onAcceptRequest?: (requestId: string) => void;
  onRejectRequest?: (requestId: string) => void;
  onNavigate?: (page: Page) => void;
}

export function BookedAppointments({ 
  appointments, 
  onCancelAppointment, 
  userInfo,
  timeSlots = [],
  onAddTimeSlot,
  onEditTimeSlot,
  onDeleteTimeSlot,
  appointmentRequests = [],
  onAcceptRequest,
  onRejectRequest,
  onNavigate
}: BookedAppointmentsProps) {
  const [rescheduleDialogOpen, setRescheduleDialogOpen] = useState(false);
  const [selectedAppointment, setSelectedAppointment] = useState<BookedAppointment | null>(null);

  // Filter appointments based on user role
  const filteredAppointments = appointments.filter(appointment => {
    if (!userInfo) return false;
    
    // Admin sees all appointments
    if (userInfo.type === "admin") {
      return true;
    }
    
    // Client sees only their own appointments
    if (userInfo.type === "client") {
      return appointment.client?.email === userInfo.email;
    }
    
    // Counselor sees only their appointments
    if (userInfo.type === "counselor") {
      // Match by email or name
      return appointment.counselor.name === userInfo.name;
    }
    
    return false;
  });

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase();
  };

  const handleDeleteClick = (id: string) => {
    const appointment = filteredAppointments.find(apt => apt.id === id);
    onCancelAppointment(id);
    
    // Show cancellation notification
    if (appointment) {
      toast.success("Appointment Cancelled", {
        description: `Your appointment with ${appointment.counselor.name} on ${formatDate(appointment.date)} at ${appointment.time} has been cancelled.`,
        duration: 5000,
      });
    }
  };

  const handleEditClick = (appointment: BookedAppointment) => {
    setSelectedAppointment(appointment);
    setRescheduleDialogOpen(true);
  };

  const handleReschedule = (appointmentId: string, newDate: string, newTime: string) => {
    const updatedAppointments = filteredAppointments.map(apt => 
      apt.id === appointmentId 
        ? { ...apt, date: newDate, time: newTime }
        : apt
    );
    setRescheduleDialogOpen(false);
    setSelectedAppointment(null);
  };

  // Format date for display
  const formatDate = (date: Date) => {
    return date.toLocaleDateString('default', { 
      weekday: 'long',
      month: 'long', 
      day: 'numeric',
      year: 'numeric' 
    });
  };

  const getDayName = (date: Date) => {
    return date.toLocaleDateString('default', { weekday: 'long' });
  };

  return (
    <div className="px-4 sm:px-6 lg:px-8 py-12">
      <div className="max-w-5xl mx-auto">
        {/* Page Header */}
        <div className="mb-12">
          <h1 className="text-3xl font-bold mb-3" style={{ color: '#00224B' }}>
            {userInfo?.type === 'counselor' ? 'Appointments & Schedule' : 'Your Booked Appointments'}
          </h1>
          <p className="text-gray-600 text-lg">
            {userInfo?.type === 'counselor' 
              ? 'Manage your appointments and time slots'
              : 'Manage and view your upcoming counseling sessions'
            }
          </p>
        </div>

        {/* For Counselors: Tabs for Appointments and Time Slots */}
        {userInfo?.type === 'counselor' ? (
          <Tabs defaultValue="booked" className="w-full">
            <TabsList className="grid w-full max-w-3xl mx-auto grid-cols-3 mb-8">
              <TabsTrigger value="booked">Booked Appointments</TabsTrigger>
              <TabsTrigger value="timeslots">Time Slot Management</TabsTrigger>
              <TabsTrigger value="requests">Appointment Requests</TabsTrigger>
            </TabsList>

            <TabsContent value="booked">
              {/* Appointments List */}
              {filteredAppointments.length > 0 ? (
                <div className="space-y-6">
                  {filteredAppointments.map((appointment) => (
                    <Card
                      key={appointment.id}
                      className="overflow-hidden bg-white/90 backdrop-blur-sm border-gray-200 shadow-lg hover:shadow-xl transition-all duration-300"
                    >
                      <div className="p-6 md:p-8">
                        <div className="flex flex-col lg:flex-row gap-6">
                          {/* Counselor Info */}
                          <div className="flex items-center gap-4">
                            <Avatar className="w-20 h-20 md:w-24 md:h-24 border-4 border-blue-100 flex-shrink-0">
                              <AvatarImage src={appointment.counselor.photo} alt={appointment.counselor.name} />
                              <AvatarFallback className="bg-gradient-to-br from-blue-200 to-purple-200 text-blue-900 text-xl">
                                {getInitials(appointment.counselor.name)}
                              </AvatarFallback>
                            </Avatar>
                            <div>
                              <h3 className="text-gray-800 mb-1">{appointment.counselor.name}</h3>
                              <p className="text-purple-600 mb-2">{appointment.counselor.title}</p>
                              {appointment.client && userInfo?.type === 'counselor' && (
                                <p className="text-sm text-gray-700 mb-1">
                                  <strong>Client:</strong> {appointment.client.name}
                                </p>
                              )}
                              <Badge className="bg-green-100 text-green-800 border-green-300">
                                {appointment.status === "confirmed" ? "Confirmed" : "Pending"}
                              </Badge>
                            </div>
                          </div>

                          {/* Appointment Details */}
                          <div className="flex-1 grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                            <div className="flex items-start gap-3">
                              <div className="p-2 bg-blue-100 rounded-lg flex-shrink-0">
                                <Calendar className="w-5 h-5 text-blue-700" />
                              </div>
                              <div>
                                <p className="text-xs text-gray-600 mb-1">Date</p>
                                <p className="text-gray-900">{formatDate(appointment.date)}</p>
                                <p className="text-sm text-gray-600">{getDayName(appointment.date)}</p>
                              </div>
                            </div>

                            <div className="flex items-start gap-3">
                              <div className="p-2 bg-purple-100 rounded-lg flex-shrink-0">
                                <Clock className="w-5 h-5 text-purple-700" />
                              </div>
                              <div>
                                <p className="text-xs text-gray-600 mb-1">Time</p>
                                <p className="text-gray-900">{appointment.time}</p>
                                <p className="text-sm text-gray-600">50 minutes</p>
                              </div>
                            </div>

                            <div className="flex items-start gap-3 sm:col-span-2 lg:col-span-1">
                              <div className="p-2 bg-pink-100 rounded-lg flex-shrink-0">
                                <MapPin className="w-5 h-5 text-pink-700" />
                              </div>
                              <div>
                                <p className="text-xs text-gray-600 mb-1">Counselor</p>
                                <p className="text-gray-900">{appointment.counselor.name}</p>
                                <p className="text-sm text-gray-600">{appointment.counselor.title}</p>
                              </div>
                            </div>
                          </div>

                          {/* Action Buttons */}
                          <div className="flex lg:flex-col gap-3 justify-end lg:justify-start">
                            <Button
                              onClick={() => handleEditClick(appointment)}
                              className="flex-1 lg:flex-none bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white shadow-md"
                            >
                              <Edit className="w-4 h-4 mr-2" />
                              Edit
                            </Button>
                            <Button
                              onClick={() => handleDeleteClick(appointment.id)}
                              variant="outline"
                              className="flex-1 lg:flex-none border-red-300 text-red-700 hover:bg-red-50 hover:border-red-400"
                            >
                              <Trash2 className="w-4 h-4 mr-2" />
                              Delete
                            </Button>
                          </div>
                        </div>
                      </div>

                      {/* Reminder Footer */}
                      <div className="bg-gradient-to-r from-blue-50 to-purple-50 px-6 md:px-8 py-4 border-t border-gray-200">
                        <p className="text-sm text-gray-700">
                          <strong>Reminder:</strong> Please arrive 5 minutes early. If you need to cancel, please do so at least 24 hours in advance.
                        </p>
                      </div>
                    </Card>
                  ))}
                </div>
              ) : (
                <Card className="p-12 text-center bg-white/90">
                  <Calendar className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-gray-800 mb-2">No Appointments Booked</h3>
                  <p className="text-gray-600">
                    You don't have any upcoming appointments.
                  </p>
                </Card>
              )}

              {/* Summary Stats */}
              {filteredAppointments.length > 0 && (
                <div className="mt-12 grid sm:grid-cols-3 gap-6">
                  <Card className="p-6 bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200 text-center">
                    <div className="text-3xl text-blue-700 mb-2">{filteredAppointments.length}</div>
                    <p className="text-gray-700">Total Appointments</p>
                  </Card>
                  <Card className="p-6 bg-gradient-to-br from-green-50 to-green-100 border-green-200 text-center">
                    <div className="text-3xl text-green-700 mb-2">
                      {filteredAppointments.filter(a => a.status === "confirmed").length}
                    </div>
                    <p className="text-gray-700">Confirmed</p>
                  </Card>
                  <Card className="p-6 bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200 text-center">
                    <div className="text-3xl text-purple-700 mb-2">
                      {new Set(filteredAppointments.map(a => a.counselor.name)).size}
                    </div>
                    <p className="text-gray-700">Counselors</p>
                  </Card>
                </div>
              )}
            </TabsContent>

            <TabsContent value="timeslots">
              {onAddTimeSlot && onEditTimeSlot && onDeleteTimeSlot && (
                <TimeSlotManagement
                  timeSlots={timeSlots.filter(slot => slot.counselorName === userInfo?.name)}
                  onAddTimeSlot={onAddTimeSlot}
                  onEditTimeSlot={onEditTimeSlot}
                  onDeleteTimeSlot={onDeleteTimeSlot}
                />
              )}
            </TabsContent>

            <TabsContent value="requests">
              {onAcceptRequest && onRejectRequest && userInfo ? (
                <div className="mt-0">
                  <AppointmentRequests
                    requests={appointmentRequests}
                    onAcceptRequest={onAcceptRequest}
                    onRejectRequest={onRejectRequest}
                    userInfo={userInfo}
                  />
                </div>
              ) : (
                <Card className="p-12 text-center bg-white/90">
                  <Calendar className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-gray-800 mb-2">No Appointment Requests</h3>
                  <p className="text-gray-600">
                    You don't have any pending appointment requests.
                  </p>
                </Card>
              )}
            </TabsContent>
          </Tabs>
        ) : (
          <>
            {/* For Clients: Just show appointments */}
            {filteredAppointments.length > 0 ? (
              <div className="space-y-6">
                {filteredAppointments.map((appointment) => (
                  <Card
                    key={appointment.id}
                    className="overflow-hidden bg-white/90 backdrop-blur-sm border-gray-200 shadow-lg hover:shadow-xl transition-all duration-300"
                  >
                    <div className="p-6 md:p-8">
                      <div className="flex flex-col lg:flex-row gap-6">
                        {/* Counselor Info */}
                        <div className="flex items-center gap-4">
                          <Avatar className="w-20 h-20 md:w-24 md:h-24 border-4 border-blue-100 flex-shrink-0">
                            <AvatarImage src={appointment.counselor.photo} alt={appointment.counselor.name} />
                            <AvatarFallback className="bg-gradient-to-br from-blue-200 to-purple-200 text-blue-900 text-xl">
                              {getInitials(appointment.counselor.name)}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <h3 className="text-gray-800 mb-1">{appointment.counselor.name}</h3>
                            <p className="text-purple-600 mb-2">{appointment.counselor.title}</p>
                            <Badge className="bg-green-100 text-green-800 border-green-300">
                              {appointment.status === "confirmed" ? "Confirmed" : "Pending"}
                            </Badge>
                          </div>
                        </div>

                        {/* Appointment Details */}
                        <div className="flex-1 grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                          <div className="flex items-start gap-3">
                            <div className="p-2 bg-blue-100 rounded-lg flex-shrink-0">
                              <Calendar className="w-5 h-5 text-blue-700" />
                            </div>
                            <div>
                              <p className="text-xs text-gray-600 mb-1">Date</p>
                              <p className="text-gray-900">{formatDate(appointment.date)}</p>
                              <p className="text-sm text-gray-600">{getDayName(appointment.date)}</p>
                            </div>
                          </div>

                          <div className="flex items-start gap-3">
                            <div className="p-2 bg-purple-100 rounded-lg flex-shrink-0">
                              <Clock className="w-5 h-5 text-purple-700" />
                            </div>
                            <div>
                              <p className="text-xs text-gray-600 mb-1">Time</p>
                              <p className="text-gray-900">{appointment.time}</p>
                              <p className="text-sm text-gray-600">50 minutes</p>
                            </div>
                          </div>

                          <div className="flex items-start gap-3 sm:col-span-2 lg:col-span-1">
                            <div className="p-2 bg-pink-100 rounded-lg flex-shrink-0">
                              <MapPin className="w-5 h-5 text-pink-700" />
                            </div>
                            <div>
                              <p className="text-xs text-gray-600 mb-1">Counselor</p>
                              <p className="text-gray-900">{appointment.counselor.name}</p>
                              <p className="text-sm text-gray-600">{appointment.counselor.title}</p>
                            </div>
                          </div>
                        </div>

                        {/* Action Buttons */}
                        <div className="flex lg:flex-col gap-3 justify-end lg:justify-start">
                          <Button
                            onClick={() => handleEditClick(appointment)}
                            className="flex-1 lg:flex-none bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white shadow-md"
                          >
                            <Edit className="w-4 h-4 mr-2" />
                            Edit
                          </Button>
                          <Button
                            onClick={() => handleDeleteClick(appointment.id)}
                            variant="outline"
                            className="flex-1 lg:flex-none border-red-300 text-red-700 hover:bg-red-50 hover:border-red-400"
                          >
                            <Trash2 className="w-4 h-4 mr-2" />
                            Delete
                          </Button>
                        </div>
                      </div>
                    </div>

                    {/* Reminder Footer */}
                    <div className="bg-gradient-to-r from-blue-50 to-purple-50 px-6 md:px-8 py-4 border-t border-gray-200">
                      <p className="text-sm text-gray-700">
                        <strong>Reminder:</strong> Please arrive 5 minutes early. If you need to cancel, please do so at least 24 hours in advance.
                      </p>
                    </div>
                  </Card>
                ))}
              </div>
            ) : (
              <Card className="p-12 text-center bg-white/90">
                <Calendar className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-gray-800 mb-2">No Appointments Booked</h3>
                <p className="text-gray-600 mb-6">
                  You don't have any upcoming appointments. Book your first session to get started.
                </p>
                <Button 
                  className="bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 text-white"
                  onClick={() => onNavigate?.("booking")}
                >
                  Book an Appointment
                </Button>
              </Card>
            )}

            {/* Summary Stats */}
            {filteredAppointments.length > 0 && (
              <div className="mt-12 grid sm:grid-cols-3 gap-6">
                <Card className="p-6 bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200 text-center">
                  <div className="text-3xl text-blue-700 mb-2">{filteredAppointments.length}</div>
                  <p className="text-gray-700">Total Appointments</p>
                </Card>
                <Card className="p-6 bg-gradient-to-br from-green-50 to-green-100 border-green-200 text-center">
                  <div className="text-3xl text-green-700 mb-2">
                    {filteredAppointments.filter(a => a.status === "confirmed").length}
                  </div>
                  <p className="text-gray-700">Confirmed</p>
                </Card>
                <Card className="p-6 bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200 text-center">
                  <div className="text-3xl text-purple-700 mb-2">
                    {new Set(filteredAppointments.map(a => a.counselor.name)).size}
                  </div>
                  <p className="text-gray-700">Counselors</p>
                </Card>
              </div>
            )}
          </>
        )}

        {/* Reschedule Dialog */}
        {rescheduleDialogOpen && selectedAppointment && (
          <RescheduleDialog
            appointment={selectedAppointment}
            onReschedule={handleReschedule}
            onClose={() => setRescheduleDialogOpen(false)}
          />
        )}

        {/* Help Section */}
        <Card className="mt-8 p-6 bg-gradient-to-r from-blue-50 to-purple-50 border-blue-200">
          <div className="flex flex-col sm:flex-row items-center gap-4 text-center sm:text-left">
            <div className="p-3 bg-blue-100 rounded-full flex-shrink-0">
              <Calendar className="w-6 h-6 text-blue-600" />
            </div>
            <div className="flex-1">
              <h3 className="text-gray-800 mb-1">Need Help?</h3>
              <p className="text-gray-600">
                Contact our support team at <span className="text-blue-700">support@careconnect.edu</span> or call <span className="text-blue-700">+36 1 234 5680</span>
              </p>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}