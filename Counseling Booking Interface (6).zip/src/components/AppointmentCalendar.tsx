import { useState } from "react";
import { Calendar, Clock, Check } from "lucide-react";
import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";

interface TimeSlot {
  time: string;
  available: boolean;
}

interface AvailableTime {
  day: string;
  times: string[];
}

interface AppointmentCalendarProps {
  availableTimes: AvailableTime[];
  counselorName: string;
}

export function AppointmentCalendar({ availableTimes, counselorName }: AppointmentCalendarProps) {
  const [selectedSlot, setSelectedSlot] = useState<{ day: string; time: string } | null>(null);

  const handleSlotClick = (day: string, time: string) => {
    if (selectedSlot?.day === day && selectedSlot?.time === time) {
      setSelectedSlot(null);
    } else {
      setSelectedSlot({ day, time });
    }
  };

  const allDays = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"];

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <div className="p-2 bg-gradient-to-br from-green-100 to-emerald-100 rounded-lg">
          <Calendar className="w-6 h-6 text-green-700" />
        </div>
        <div>
          <h3 className="text-gray-800">Available Appointment Times</h3>
          <p className="text-sm text-gray-600">Click on a time slot to select your appointment</p>
        </div>
      </div>

      {/* Calendar Grid */}
      <Card className="p-6 bg-gradient-to-br from-green-50/50 to-emerald-50/50 border-green-200">
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-4">
          {allDays.map((day) => {
            const daySchedule = availableTimes.find((schedule) => schedule.day === day);
            const hasSlots = daySchedule && daySchedule.times.length > 0;

            return (
              <div
                key={day}
                className={`rounded-lg overflow-hidden ${
                  hasSlots 
                    ? "bg-white border-2 border-green-200" 
                    : "bg-gray-50 border-2 border-gray-200 opacity-60"
                }`}
              >
                {/* Day Header */}
                <div
                  className={`px-4 py-3 text-center ${
                    hasSlots
                      ? "bg-gradient-to-r from-green-500 to-emerald-500 text-white"
                      : "bg-gray-300 text-gray-600"
                  }`}
                >
                  <p className="font-medium">{day}</p>
                </div>

                {/* Time Slots */}
                <div className="p-3 space-y-2">
                  {hasSlots ? (
                    daySchedule.times.map((time, index) => {
                      const isSelected = selectedSlot?.day === day && selectedSlot?.time === time;
                      return (
                        <button
                          key={index}
                          onClick={() => handleSlotClick(day, time)}
                          className={`w-full px-3 py-3 rounded-lg text-sm transition-all duration-200 ${
                            isSelected
                              ? "bg-gradient-to-r from-blue-500 to-purple-500 text-white shadow-lg scale-105"
                              : "bg-gradient-to-r from-green-100 to-emerald-100 text-green-800 hover:from-green-200 hover:to-emerald-200 hover:shadow-md"
                          }`}
                        >
                          <div className="flex items-center justify-center gap-2">
                            {isSelected && <Check className="w-4 h-4" />}
                            <Clock className="w-3 h-3" />
                            <span className={isSelected ? "" : ""}>{time}</span>
                          </div>
                        </button>
                      );
                    })
                  ) : (
                    <p className="text-center text-sm text-gray-500 py-4">No availability</p>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Legend */}
        <div className="flex flex-wrap items-center gap-4 mt-6 pt-6 border-t border-green-200">
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 rounded bg-gradient-to-r from-green-100 to-emerald-100 border border-green-300"></div>
            <span className="text-sm text-gray-600">Available</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 rounded bg-gradient-to-r from-blue-500 to-purple-500"></div>
            <span className="text-sm text-gray-600">Selected</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 rounded bg-gray-300"></div>
            <span className="text-sm text-gray-600">Unavailable</span>
          </div>
        </div>
      </Card>

      {/* Selected Appointment Summary */}
      {selectedSlot && (
        <Card className="p-6 bg-gradient-to-r from-blue-50 to-purple-50 border-blue-300 animate-in fade-in slide-in-from-bottom-4 duration-300">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div className="space-y-1">
              <p className="text-sm text-gray-600">Selected Appointment</p>
              <p className="text-blue-900">
                <span className="mr-2">{counselorName}</span>
                <Badge variant="secondary" className="bg-white/80">
                  {selectedSlot.day}, {selectedSlot.time}
                </Badge>
              </p>
            </div>
            <div className="flex gap-3">
              <Button
                variant="outline"
                onClick={() => setSelectedSlot(null)}
                className="border-gray-300 hover:bg-gray-100"
              >
                Clear
              </Button>
              <Button className="bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 text-white shadow-lg">
                Confirm Booking
              </Button>
            </div>
          </div>
        </Card>
      )}

      <p className="text-sm text-gray-500 italic text-center">
        All sessions are 50 minutes. Please arrive 5 minutes early for your appointment.
      </p>
    </div>
  );
}
