import { Mail, MapPin, Phone, Sparkles } from "lucide-react";
import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { AppointmentCalendar } from "./AppointmentCalendar";

interface AvailableTime {
  day: string;
  times: string[];
}

interface Counselor {
  id: number;
  name: string;
  title: string;
  description: string;
  photo: string;
  email: string;
  office: string;
  phone: string;
  specialties: string[];
  availableTimes: AvailableTime[];
}

interface CounselorProfileProps {
  counselor: Counselor;
}

export function CounselorProfile({ counselor }: CounselorProfileProps) {
  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase();
  };

  return (
    <Card className="overflow-hidden bg-white/90 backdrop-blur-sm border-gray-200 shadow-lg hover:shadow-xl transition-shadow duration-300">
      <div className="grid md:grid-cols-3 gap-8 p-8 md:p-12">
        {/* Left Column - Profile Photo and Basic Info */}
        <div className="md:col-span-1 flex flex-col items-center text-center space-y-6">
          <div className="relative">
            <div className="absolute -inset-1 bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 rounded-full blur opacity-30"></div>
            <Avatar className="relative w-48 h-48 border-4 border-white shadow-xl">
              <AvatarImage src={counselor.photo} alt={counselor.name} />
              <AvatarFallback className="bg-gradient-to-br from-blue-200 to-purple-200 text-blue-900 text-3xl">
                {getInitials(counselor.name)}
              </AvatarFallback>
            </Avatar>
          </div>

          <div className="space-y-2">
            <h2 className="text-blue-900">{counselor.name}</h2>
            <p className="text-purple-600">{counselor.title}</p>
          </div>

          {/* Specialties */}
          <div className="w-full pt-4">
            <div className="flex items-center justify-center gap-2 mb-3">
              <Sparkles className="w-4 h-4 text-purple-500" />
              <h3 className="text-gray-700">Areas of Expertise</h3>
            </div>
            <div className="flex flex-wrap gap-2 justify-center">
              {counselor.specialties.map((specialty, index) => (
                <Badge
                  key={index}
                  variant="secondary"
                  className="bg-gradient-to-r from-blue-100 to-purple-100 text-blue-800 border-blue-200 hover:from-blue-200 hover:to-purple-200"
                >
                  {specialty}
                </Badge>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column - Details */}
        <div className="md:col-span-2 space-y-8">
          {/* Description */}
          <div>
            <h3 className="text-gray-700 mb-3">About</h3>
            <p className="text-gray-600 leading-relaxed">{counselor.description}</p>
          </div>

          {/* Contact Information */}
          <div>
            <h3 className="text-gray-700 mb-4">Contact Information</h3>
            <div className="grid sm:grid-cols-2 gap-4">
              <Card className="p-4 bg-gradient-to-br from-blue-50 to-blue-100/50 border-blue-200">
                <div className="flex items-start gap-3">
                  <div className="p-2 bg-blue-200 rounded-lg">
                    <Mail className="w-5 h-5 text-blue-700" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-gray-600 mb-1">Email</p>
                    <p className="text-blue-700 truncate">{counselor.email}</p>
                  </div>
                </div>
              </Card>

              <Card className="p-4 bg-gradient-to-br from-purple-50 to-purple-100/50 border-purple-200">
                <div className="flex items-start gap-3">
                  <div className="p-2 bg-purple-200 rounded-lg">
                    <MapPin className="w-5 h-5 text-purple-700" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-gray-600 mb-1">Office</p>
                    <p className="text-purple-700">{counselor.office}</p>
                  </div>
                </div>
              </Card>

              <Card className="p-4 bg-gradient-to-br from-pink-50 to-pink-100/50 border-pink-200 sm:col-span-2">
                <div className="flex items-start gap-3">
                  <div className="p-2 bg-pink-200 rounded-lg">
                    <Phone className="w-5 h-5 text-pink-700" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-gray-600 mb-1">Phone</p>
                    <p className="text-pink-700">{counselor.phone}</p>
                  </div>
                </div>
              </Card>
            </div>
          </div>

          {/* Available Times */}
          <div>
            <AppointmentCalendar 
              availableTimes={counselor.availableTimes} 
              counselorName={counselor.name}
            />
          </div>
        </div>
      </div>
    </Card>
  );
}