import { Card } from "./ui/card";
import { Users, Calendar, TrendingUp, Clock, BarChart3, PieChart } from "lucide-react";
import { 
  LineChart, 
  Line, 
  BarChart, 
  Bar, 
  PieChart as RePieChart, 
  Pie, 
  Cell,
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer 
} from "recharts";
import { Badge } from "./ui/badge";

export function Statistics() {
  // Sample data for charts
  const monthlyData = [
    { month: "Jan", appointments: 28, completed: 25, cancelled: 3 },
    { month: "Feb", appointments: 32, completed: 30, cancelled: 2 },
    { month: "Mar", appointments: 38, completed: 35, cancelled: 3 },
    { month: "Apr", appointments: 35, completed: 32, cancelled: 3 },
    { month: "May", appointments: 42, completed: 40, cancelled: 2 },
    { month: "Jun", appointments: 40, completed: 37, cancelled: 3 },
  ];

  const issueTypeData = [
    { name: "Anxiety & Stress", value: 35, color: "#10b981" },
    { name: "Depression", value: 25, color: "#3b82f6" },
    { name: "Academic Issues", value: 20, color: "#8b5cf6" },
    { name: "Relationships", value: 15, color: "#f59e0b" },
    { name: "Other", value: 5, color: "#6b7280" },
  ];

  const timeSlotData = [
    { time: "08:00-10:00", bookings: 12 },
    { time: "10:00-12:00", bookings: 28 },
    { time: "12:00-14:00", bookings: 15 },
    { time: "14:00-16:00", bookings: 32 },
    { time: "16:00-18:00", bookings: 25 },
  ];

  const stats = [
    {
      label: "Total Appointments",
      value: "215",
      change: "+12%",
      icon: Calendar,
      color: "emerald",
      bgColor: "from-emerald-500 to-green-500"
    },
    {
      label: "Active Clients",
      value: "89",
      change: "+8%",
      icon: Users,
      color: "blue",
      bgColor: "from-blue-500 to-cyan-500"
    },
    {
      label: "Avg. Session Duration",
      value: "48 min",
      change: "+2 min",
      icon: Clock,
      color: "purple",
      bgColor: "from-purple-500 to-pink-500"
    },
    {
      label: "Completion Rate",
      value: "94%",
      change: "+3%",
      icon: TrendingUp,
      color: "orange",
      bgColor: "from-orange-500 to-red-500"
    },
  ];

  return (
    <div className="px-4 sm:px-6 lg:px-8 py-8 max-w-7xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <div className="p-3 bg-gradient-to-br from-emerald-600 to-green-600 rounded-xl">
            <BarChart3 className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-emerald-900">Statistics & Analytics</h1>
            <p className="text-gray-600">
              Overview of your counseling sessions and client insights
            </p>
          </div>
        </div>
        <Badge variant="outline" className="mt-2">
          Last updated: Today at 3:45 PM
        </Badge>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <Card key={index} className="p-6 bg-white/90 backdrop-blur-sm border-emerald-200 hover:shadow-lg transition-shadow">
              <div className="flex items-start justify-between mb-4">
                <div className={`p-3 bg-gradient-to-br ${stat.bgColor} rounded-lg`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <Badge className="bg-green-100 text-green-700 hover:bg-green-100">
                  {stat.change}
                </Badge>
              </div>
              <p className="text-gray-600 text-sm mb-1">{stat.label}</p>
              <p className="text-3xl font-bold text-gray-900">{stat.value}</p>
            </Card>
          );
        })}
      </div>

      {/* Charts Row 1 */}
      <div className="grid lg:grid-cols-2 gap-6 mb-6">
        {/* Monthly Appointments Trend */}
        <Card className="p-6 bg-white/90 backdrop-blur-sm border-emerald-200">
          <div className="flex items-center gap-2 mb-6">
            <TrendingUp className="w-5 h-5 text-emerald-600" />
            <h3 className="text-gray-800">Monthly Appointment Trends</h3>
          </div>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={monthlyData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
              <XAxis dataKey="month" stroke="#6b7280" />
              <YAxis stroke="#6b7280" />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'white', 
                  border: '1px solid #d1d5db',
                  borderRadius: '8px'
                }} 
              />
              <Legend />
              <Line 
                type="monotone" 
                dataKey="appointments" 
                stroke="#10b981" 
                strokeWidth={2}
                name="Total Appointments"
              />
              <Line 
                type="monotone" 
                dataKey="completed" 
                stroke="#3b82f6" 
                strokeWidth={2}
                name="Completed"
              />
              <Line 
                type="monotone" 
                dataKey="cancelled" 
                stroke="#ef4444" 
                strokeWidth={2}
                name="Cancelled"
              />
            </LineChart>
          </ResponsiveContainer>
        </Card>

        {/* Issue Type Distribution */}
        <Card className="p-6 bg-white/90 backdrop-blur-sm border-emerald-200">
          <div className="flex items-center gap-2 mb-6">
            <PieChart className="w-5 h-5 text-emerald-600" />
            <h3 className="text-gray-800">Issue Type Distribution</h3>
          </div>
          <ResponsiveContainer width="100%" height={300}>
            <RePieChart>
              <Pie
                data={issueTypeData}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                outerRadius={80}
                fill="#8884d8"
                dataKey="value"
              >
                {issueTypeData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip />
            </RePieChart>
          </ResponsiveContainer>
          <div className="mt-4 space-y-2">
            {issueTypeData.map((item, index) => (
              <div key={index} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div 
                    className="w-3 h-3 rounded-full" 
                    style={{ backgroundColor: item.color }}
                  />
                  <span className="text-sm text-gray-700">{item.name}</span>
                </div>
                <span className="text-sm font-medium text-gray-900">{item.value}%</span>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Charts Row 2 */}
      <div className="grid lg:grid-cols-3 gap-6">
        {/* Time Slot Popularity */}
        <Card className="lg:col-span-2 p-6 bg-white/90 backdrop-blur-sm border-emerald-200">
          <div className="flex items-center gap-2 mb-6">
            <Clock className="w-5 h-5 text-emerald-600" />
            <h3 className="text-gray-800">Most Popular Time Slots</h3>
          </div>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={timeSlotData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
              <XAxis dataKey="time" stroke="#6b7280" />
              <YAxis stroke="#6b7280" />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'white', 
                  border: '1px solid #d1d5db',
                  borderRadius: '8px'
                }} 
              />
              <Bar dataKey="bookings" fill="#10b981" name="Bookings" radius={[8, 8, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Card>

        {/* Quick Insights */}
        <Card className="p-6 bg-gradient-to-br from-emerald-50 to-green-50 border-emerald-200">
          <h3 className="text-gray-800 mb-4">Quick Insights</h3>
          <div className="space-y-4">
            <div className="p-4 bg-white/80 rounded-lg border border-emerald-200">
              <p className="text-sm text-gray-600 mb-1">Peak Day</p>
              <p className="text-lg font-semibold text-emerald-900">Thursday</p>
              <p className="text-xs text-gray-500">38 avg. appointments</p>
            </div>
            <div className="p-4 bg-white/80 rounded-lg border border-emerald-200">
              <p className="text-sm text-gray-600 mb-1">Most Common Issue</p>
              <p className="text-lg font-semibold text-emerald-900">Anxiety & Stress</p>
              <p className="text-xs text-gray-500">35% of all cases</p>
            </div>
            <div className="p-4 bg-white/80 rounded-lg border border-emerald-200">
              <p className="text-sm text-gray-600 mb-1">Avg. Wait Time</p>
              <p className="text-lg font-semibold text-emerald-900">2.3 days</p>
              <p className="text-xs text-gray-500">From booking to session</p>
            </div>
            <div className="p-4 bg-white/80 rounded-lg border border-emerald-200">
              <p className="text-sm text-gray-600 mb-1">Client Satisfaction</p>
              <p className="text-lg font-semibold text-emerald-900">4.8/5.0</p>
              <p className="text-xs text-gray-500">Based on 127 reviews</p>
            </div>
          </div>
        </Card>
      </div>

      {/* Recent Activity Table */}
      <Card className="mt-6 p-6 bg-white/90 backdrop-blur-sm border-emerald-200">
        <h3 className="text-gray-800 mb-4">Recent Appointments</h3>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-emerald-200">
                <th className="text-left py-3 px-4 text-sm font-medium text-gray-700">Client</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-gray-700">Date & Time</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-gray-700">Issue Type</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-gray-700">Duration</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-gray-700">Status</th>
              </tr>
            </thead>
            <tbody>
              {[
                { client: "John Doe", date: "Nov 10, 2025", time: "10:00 AM", issue: "Anxiety", duration: "50 min", status: "Completed" },
                { client: "Jane Smith", date: "Nov 10, 2025", time: "2:00 PM", issue: "Academic Stress", duration: "45 min", status: "Completed" },
                { client: "Alex Johnson", date: "Nov 11, 2025", time: "11:00 AM", issue: "Depression", duration: "60 min", status: "Scheduled" },
                { client: "Sarah Williams", date: "Nov 11, 2025", time: "3:00 PM", issue: "Relationships", duration: "45 min", status: "Scheduled" },
                { client: "Mike Brown", date: "Nov 12, 2025", time: "9:00 AM", issue: "Anxiety", duration: "50 min", status: "Scheduled" },
              ].map((appointment, index) => (
                <tr key={index} className="border-b border-gray-100 hover:bg-emerald-50/50 transition-colors">
                  <td className="py-3 px-4 text-sm text-gray-900">{appointment.client}</td>
                  <td className="py-3 px-4 text-sm text-gray-700">{appointment.date} at {appointment.time}</td>
                  <td className="py-3 px-4 text-sm text-gray-700">{appointment.issue}</td>
                  <td className="py-3 px-4 text-sm text-gray-700">{appointment.duration}</td>
                  <td className="py-3 px-4">
                    <Badge 
                      className={
                        appointment.status === "Completed"
                          ? "bg-green-100 text-green-700 hover:bg-green-100"
                          : "bg-blue-100 text-blue-700 hover:bg-blue-100"
                      }
                    >
                      {appointment.status}
                    </Badge>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
