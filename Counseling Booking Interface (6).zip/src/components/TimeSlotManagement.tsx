import { useState } from "react";
import { Calendar as CalendarIcon, Clock, Edit, Trash2, Plus, Check, Video, MapPin } from "lucide-react";
import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "./ui/dialog";
import { Label } from "./ui/label";
import { Input } from "./ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Calendar } from "./ui/calendar";
import { Textarea } from "./ui/textarea";
import { toast } from "sonner@2.0.3";
import { useLanguage } from "../contexts/LanguageContext";

export interface TimeSlot {
  id: string;
  date: Date;
  time: string;
  duration: number; // in minutes
  isBooked: boolean;
  bookedBy?: string;
  counselorName?: string;
  sessionType?: "online" | "in-person";
  counselingType?: string;
  notes?: string;
}

interface TimeSlotManagementProps {
  timeSlots: TimeSlot[];
  onAddTimeSlot: (timeSlot: Omit<TimeSlot, 'id'>) => void;
  onEditTimeSlot: (id: string, timeSlot: Omit<TimeSlot, 'id'>) => void;
  onDeleteTimeSlot: (id: string) => void;
}

export function TimeSlotManagement({ 
  timeSlots, 
  onAddTimeSlot, 
  onEditTimeSlot, 
  onDeleteTimeSlot 
}: TimeSlotManagementProps) {
  const { t } = useLanguage();
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [selectedSlot, setSelectedSlot] = useState<TimeSlot | null>(null);
  const [selectedDay, setSelectedDay] = useState<Date | null>(() => {
    // Default to today
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return today;
  });
  const [formData, setFormData] = useState({
    date: new Date().toISOString().split('T')[0],
    time: "09:00",
    duration: 50,
    sessionType: "in-person",
    counselingType: "anxiety",
    notes: ""
  });

  // Counseling types matching CreateAppointmentForm
  const counselingTypes = [
    { value: "anxiety", label: t("Anxiety Management", "Szorongáskezelés") },
    { value: "depression", label: t("Depression Support", "Depresszió Támogatás") },
    { value: "stress", label: t("Stress Reduction", "Stresszcsökkentés") },
    { value: "academic", label: t("Academic Support", "Tanulmányi Támogatás") },
    { value: "relationship", label: t("Relationship Counseling", "Kapcsolati Tanácsadás") },
    { value: "life-transitions", label: t("Life Transitions", "Élethelyzet Változások") },
  ];

  const handleAddSlot = () => {
    onAddTimeSlot({
      date: new Date(formData.date),
      time: formData.time,
      duration: formData.duration,
      isBooked: false,
      sessionType: formData.sessionType,
      counselingType: formData.counselingType,
      notes: formData.notes
    });
    setIsAddDialogOpen(false);
    setFormData({
      date: new Date().toISOString().split('T')[0],
      time: "09:00",
      duration: 50,
      sessionType: "in-person",
      counselingType: "anxiety",
      notes: ""
    });
    toast.success("Time Slot Added", {
      description: `New time slot created for ${formData.date} at ${formData.time}`,
    });
  };

  const handleEditSlot = () => {
    if (!selectedSlot) return;
    
    onEditTimeSlot(selectedSlot.id, {
      date: new Date(formData.date),
      time: formData.time,
      duration: formData.duration,
      isBooked: selectedSlot.isBooked,
      bookedBy: selectedSlot.bookedBy,
      sessionType: formData.sessionType,
      counselingType: formData.counselingType,
      notes: formData.notes
    });
    setIsEditDialogOpen(false);
    setSelectedSlot(null);
    toast.success("Time Slot Updated", {
      description: `Time slot updated to ${formData.date} at ${formData.time}`,
    });
  };

  const handleDeleteSlot = (slot: TimeSlot) => {
    if (slot.isBooked) {
      toast.error("Cannot Delete", {
        description: "Cannot delete a booked time slot. Please cancel the appointment first.",
      });
      return;
    }
    
    onDeleteTimeSlot(slot.id);
    toast.success("Time Slot Deleted", {
      description: `Time slot for ${formatDate(slot.date)} at ${slot.time} has been deleted.`,
    });
  };

  const openEditDialog = (slot: TimeSlot) => {
    setSelectedSlot(slot);
    setFormData({
      date: slot.date.toISOString().split('T')[0],
      time: slot.time,
      duration: slot.duration,
      sessionType: slot.sessionType || "in-person",
      counselingType: slot.counselingType || "anxiety",
      notes: slot.notes || ""
    });
    setIsEditDialogOpen(true);
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('default', { 
      weekday: 'short',
      month: 'short', 
      day: 'numeric',
      year: 'numeric' 
    });
  };

  const sortedSlots = [...timeSlots].sort((a, b) => {
    const dateA = new Date(a.date).getTime();
    const dateB = new Date(b.date).getTime();
    if (dateA !== dateB) return dateA - dateB;
    return a.time.localeCompare(b.time);
  });

  const bookedSlots = sortedSlots.filter(slot => slot.isBooked);
  const availableSlots = sortedSlots.filter(slot => !slot.isBooked);

  const isSameDay = (date1: Date | null | undefined, date2: Date | null | undefined) => {
    if (!date1 || !date2) return false;
    return (
      date1.getDate() === date2.getDate() &&
      date1.getMonth() === date2.getMonth() &&
      date1.getFullYear() === date2.getFullYear()
    );
  };

  const isToday = (date: Date) => {
    const today = new Date();
    return isSameDay(date, today);
  };

  const handleDayClick = (day: Date) => {
    setSelectedDay(day);
  };

  const getSelectedDaySlots = () => {
    if (!selectedDay) return [];
    const dateKey = selectedDay.toISOString().split('T')[0];
    return sortedSlots.filter(slot => {
      const slotDateKey = new Date(slot.date).toISOString().split('T')[0];
      return slotDateKey === dateKey;
    });
  };



  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl" style={{ color: '#00224B' }}>Your Time Slots</h2>
          <p className="text-gray-600 mt-1">
            Manage your availability schedule
          </p>
        </div>
        <Button 
          onClick={() => setIsAddDialogOpen(true)}
          className="bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 text-white"
        >
          <Plus className="w-4 h-4 mr-2" />
          Add Time Slot
        </Button>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="p-4 bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
          <div className="text-2xl text-blue-700 mb-1">{timeSlots.length}</div>
          <p className="text-sm text-gray-700">Total Slots</p>
        </Card>
        <Card className="p-4 bg-gradient-to-br from-green-50 to-green-100 border-green-200">
          <div className="text-2xl text-green-700 mb-1">{bookedSlots.length}</div>
          <p className="text-sm text-gray-700">Booked</p>
        </Card>
        <Card className="p-4 bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200">
          <div className="text-2xl text-purple-700 mb-1">{availableSlots.length}</div>
          <p className="text-sm text-gray-700">Available</p>
        </Card>
      </div>

      {/* Two Column Layout: Calendar on Left, Time Slots on Right */}
      <div className="grid lg:grid-cols-2 gap-6">
        {/* Left Side - Calendar */}
        <Card className="p-6 bg-white border-2 border-gray-200 flex flex-col">
          <div className="flex items-center gap-2 mb-4">
            <div className="p-2 rounded" style={{ backgroundColor: '#005FA3' }}>
              <CalendarIcon className="w-5 h-5 text-white" />
            </div>
            <h3 className="font-semibold" style={{ color: '#00224B' }}>
              Select Date
            </h3>
          </div>
          
          <div className="flex justify-center">
            <Calendar
              mode="single"
              selected={selectedDay || undefined}
              onSelect={(date) => date && handleDayClick(date)}
              disabled={(date) => {
                const today = new Date();
                today.setHours(0, 0, 0, 0);
                return date < today || date.getDay() === 0 || date.getDay() === 6;
              }}
              className="rounded-lg border-2 border-gray-200"
            />
          </div>
          
          <p className="text-xs text-gray-600 mt-3">
            Weekends and past dates are disabled
            {selectedDay && ` • Selected: ${formatDate(selectedDay)}`}
          </p>
        </Card>

        {/* Right Side - Selected Day Time Slots */}
        <Card className="bg-white border-2 border-gray-200 overflow-hidden">
            {/* Selected Day Header */}
            <div className="p-4 border-b-2" style={{ backgroundColor: '#00224B', borderColor: '#005FA3' }}>
              <div className="flex items-center gap-2 mb-2">
                <CalendarIcon className="w-5 h-5 text-white" />
                <h3 className="text-white font-semibold">
                  {selectedDay ? 'Selected Day' : 'Select a Day'}
                </h3>
              </div>
              {selectedDay && (
                <p className="text-blue-200 text-sm">
                  {selectedDay.toLocaleDateString('default', { 
                    weekday: 'long', 
                    month: 'long', 
                    day: 'numeric',
                    year: 'numeric'
                  })}
                </p>
              )}
            </div>

            {/* Time Slots List */}
            <div className="p-4 max-h-[600px] overflow-y-auto">
              {selectedDay ? (
                getSelectedDaySlots().length > 0 ? (
                  <div className="space-y-3">
                    {getSelectedDaySlots().map((slot) => {
                      const isPast = new Date(slot.date) < new Date(new Date().setHours(0, 0, 0, 0));
                      
                      return (
                        <Card
                          key={slot.id}
                          className={`p-4 border-2 transition-all duration-200 ${
                            slot.isBooked 
                              ? 'bg-gradient-to-br from-blue-50 to-blue-100 border-blue-300' 
                              : 'bg-gradient-to-br from-green-50 to-green-100 border-green-300'
                          } ${isPast ? 'opacity-50' : 'hover:shadow-lg'}`}
                        >
                          <div className="space-y-3">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-2">
                                <div className={`p-2 rounded-full ${
                                  slot.isBooked ? 'bg-blue-200' : 'bg-green-200'
                                }`}>
                                  <Clock className={`w-4 h-4 ${
                                    slot.isBooked ? 'text-blue-700' : 'text-green-700'
                                  }`} />
                                </div>
                                <div>
                                  <h4 className="font-semibold text-gray-900">{slot.time}</h4>
                                  <p className="text-xs text-gray-600">{slot.duration} min</p>
                                </div>
                              </div>
                              <Badge className={`${
                                slot.isBooked 
                                  ? 'bg-blue-500 text-white border-blue-600' 
                                  : 'bg-green-500 text-white border-green-600'
                              }`}>
                                {slot.isBooked ? 'Booked' : 'Free'}
                              </Badge>
                            </div>
                            
                            {slot.bookedBy && (
                              <div className="p-2 bg-white/50 rounded border border-blue-200">
                                <p className="text-xs text-gray-700">
                                  <strong>Patient:</strong> {slot.bookedBy}
                                </p>
                              </div>
                            )}

                            <div className="flex gap-2">
                              <Button
                                onClick={() => openEditDialog(slot)}
                                variant="outline"
                                size="sm"
                                className="flex-1 border-gray-400 hover:bg-gray-100"
                              >
                                <Edit className="w-3 h-3 mr-1" />
                                Edit
                              </Button>
                              <Button
                                onClick={() => handleDeleteSlot(slot)}
                                variant="outline"
                                size="sm"
                                disabled={slot.isBooked}
                                className={`flex-1 ${
                                  slot.isBooked 
                                    ? 'opacity-50 cursor-not-allowed' 
                                    : 'border-red-300 text-red-700 hover:bg-red-50'
                                }`}
                              >
                                <Trash2 className="w-3 h-3 mr-1" />
                                Delete
                              </Button>
                            </div>

                            {slot.isBooked && (
                              <p className="text-[10px] text-gray-600 italic">
                                Cannot delete booked slots
                              </p>
                            )}
                          </div>
                        </Card>
                      );
                    })}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <Clock className="w-12 h-12 mx-auto mb-3 text-gray-400" />
                    <h4 className="text-gray-800 mb-2">No Time Slots</h4>
                    <p className="text-sm text-gray-600 mb-4">
                      No time slots for this day yet.
                    </p>
                    <Button
                      onClick={() => {
                        setFormData({
                          date: selectedDay.toISOString().split('T')[0],
                          time: "09:00",
                          duration: 50,
                          sessionType: "in-person",
                          counselingType: "anxiety",
                          notes: ""
                        });
                        setIsAddDialogOpen(true);
                      }}
                      size="sm"
                      className="bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 text-white"
                    >
                      <Plus className="w-3 h-3 mr-1" />
                      Add Slot
                    </Button>
                  </div>
                )
              ) : (
                <div className="text-center py-8">
                  <CalendarIcon className="w-12 h-12 mx-auto mb-3 text-gray-400" />
                  <h4 className="text-gray-800 mb-2">Select a Day</h4>
                  <p className="text-sm text-gray-600">
                    Click on any day in the calendar to view and manage time slots.
                  </p>
                </div>
              )}
            </div>
          </Card>
      </div>

      {/* Add Time Slot Dialog */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add New Time Slot</DialogTitle>
            <DialogDescription>
              Create a new time slot for your availability schedule.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="date">Date</Label>
              <Input
                id="date"
                type="date"
                value={formData.date}
                onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                min={new Date().toISOString().split('T')[0]}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="time">Time</Label>
              <Input
                id="time"
                type="time"
                value={formData.time}
                onChange={(e) => setFormData({ ...formData, time: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="duration">Duration (minutes)</Label>
              <Select
                value={formData.duration.toString()}
                onValueChange={(value) => setFormData({ ...formData, duration: parseInt(value) })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="30">30 minutes</SelectItem>
                  <SelectItem value="50">50 minutes</SelectItem>
                  <SelectItem value="60">60 minutes</SelectItem>
                  <SelectItem value="90">90 minutes</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="sessionType">Session Type</Label>
              <Select
                value={formData.sessionType}
                onValueChange={(value) => setFormData({ ...formData, sessionType: value as "online" | "in-person" })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="in-person">
                    <MapPin className="w-4 h-4 mr-2" />
                    In-Person
                  </SelectItem>
                  <SelectItem value="online">
                    <Video className="w-4 h-4 mr-2" />
                    Online
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="counselingType">Counseling Type</Label>
              <Select
                value={formData.counselingType}
                onValueChange={(value) => setFormData({ ...formData, counselingType: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {counselingTypes.map(type => (
                    <SelectItem key={type.value} value={type.value}>{type.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="notes">Notes</Label>
              <Textarea
                id="notes"
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                placeholder="Add any additional notes here..."
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
              Cancel
            </Button>
            <Button 
              onClick={handleAddSlot}
              className="bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 text-white"
            >
              <Check className="w-4 h-4 mr-2" />
              Add Slot
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Time Slot Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Time Slot</DialogTitle>
            <DialogDescription>
              Modify the details of this time slot.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="edit-date">Date</Label>
              <Input
                id="edit-date"
                type="date"
                value={formData.date}
                onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                min={new Date().toISOString().split('T')[0]}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-time">Time</Label>
              <Input
                id="edit-time"
                type="time"
                value={formData.time}
                onChange={(e) => setFormData({ ...formData, time: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-duration">Duration (minutes)</Label>
              <Select
                value={formData.duration.toString()}
                onValueChange={(value) => setFormData({ ...formData, duration: parseInt(value) })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="30">30 minutes</SelectItem>
                  <SelectItem value="50">50 minutes</SelectItem>
                  <SelectItem value="60">60 minutes</SelectItem>
                  <SelectItem value="90">90 minutes</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-sessionType">Session Type</Label>
              <Select
                value={formData.sessionType}
                onValueChange={(value) => setFormData({ ...formData, sessionType: value as "online" | "in-person" })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="in-person">
                    <MapPin className="w-4 h-4 mr-2" />
                    In-Person
                  </SelectItem>
                  <SelectItem value="online">
                    <Video className="w-4 h-4 mr-2" />
                    Online
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-counselingType">Counseling Type</Label>
              <Select
                value={formData.counselingType}
                onValueChange={(value) => setFormData({ ...formData, counselingType: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {counselingTypes.map(type => (
                    <SelectItem key={type.value} value={type.value}>{type.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-notes">Notes</Label>
              <Textarea
                id="edit-notes"
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                placeholder="Add any additional notes here..."
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
              Cancel
            </Button>
            <Button 
              onClick={handleEditSlot}
              className="bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 text-white"
            >
              <Check className="w-4 h-4 mr-2" />
              Save Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}