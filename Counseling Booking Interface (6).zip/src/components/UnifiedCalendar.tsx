import { useState } from "react";
import { ChevronLeft, ChevronRight, Calendar as CalendarIcon } from "lucide-react";
import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { ToggleGroup, ToggleGroupItem } from "./ui/toggle-group";

interface UnifiedCalendarProps {
  selectedDate: Date | undefined;
  onSelectDate: (date: Date | undefined) => void;
  disabledDates?: (date: Date) => boolean;
}

export function UnifiedCalendar({ selectedDate, onSelectDate, disabledDates }: UnifiedCalendarProps) {
  const [view, setView] = useState<"month" | "week">("month");
  const [currentMonth, setCurrentMonth] = useState(new Date());

  const getDaysInMonth = (date: Date) => {
    const year = date.getFullYear();
    const month = date.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysInMonth = lastDay.getDate();
    const startingDayOfWeek = firstDay.getDay();

    const days: (Date | null)[] = [];
    
    // Add empty slots for days before the month starts
    for (let i = 0; i < startingDayOfWeek; i++) {
      days.push(null);
    }
    
    // Add all days in the month
    for (let day = 1; day <= daysInMonth; day++) {
      days.push(new Date(year, month, day));
    }
    
    return days;
  };

  const getWeekDays = (date: Date) => {
    const currentDate = new Date(date);
    const dayOfWeek = currentDate.getDay();
    const startOfWeek = new Date(currentDate);
    startOfWeek.setDate(currentDate.getDate() - dayOfWeek);
    
    const days: Date[] = [];
    for (let i = 0; i < 7; i++) {
      const day = new Date(startOfWeek);
      day.setDate(startOfWeek.getDate() + i);
      days.push(day);
    }
    
    return days;
  };

  const navigateMonth = (direction: 'prev' | 'next') => {
    const newMonth = new Date(currentMonth);
    if (direction === 'prev') {
      newMonth.setMonth(currentMonth.getMonth() - 1);
    } else {
      newMonth.setMonth(currentMonth.getMonth() + 1);
    }
    setCurrentMonth(newMonth);
  };

  const navigateWeek = (direction: 'prev' | 'next') => {
    const newDate = new Date(currentMonth);
    if (direction === 'prev') {
      newDate.setDate(currentMonth.getDate() - 7);
    } else {
      newDate.setDate(currentMonth.getDate() + 7);
    }
    setCurrentMonth(newDate);
  };

  const isSameDay = (date1: Date | null | undefined, date2: Date | null | undefined) => {
    if (!date1 || !date2) return false;
    return (
      date1.getDate() === date2.getDate() &&
      date1.getMonth() === date2.getMonth() &&
      date1.getFullYear() === date2.getFullYear()
    );
  };

  const isToday = (date: Date) => {
    const today = new Date();
    return isSameDay(date, today);
  };

  const monthName = currentMonth.toLocaleDateString('default', { month: 'long', year: 'numeric' });
  const weekDayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  return (
    <Card className="p-6 bg-white border-2 border-gray-200">
      {/* Header with View Toggle */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <div className="p-2 rounded" style={{ backgroundColor: '#005FA3' }}>
            <CalendarIcon className="w-5 h-5 text-white" />
          </div>
          <h3 className="font-semibold" style={{ color: '#00224B' }}>
            Select Date
          </h3>
        </div>
        
        <ToggleGroup type="single" value={view} onValueChange={(value) => value && setView(value as "month" | "week")}>
          <ToggleGroupItem value="month" aria-label="Month view">
            Month
          </ToggleGroupItem>
          <ToggleGroupItem value="week" aria-label="Week view">
            Week
          </ToggleGroupItem>
        </ToggleGroup>
      </div>

      {/* Navigation */}
      <div className="flex items-center justify-between mb-4">
        <Button
          variant="outline"
          size="sm"
          onClick={() => view === 'month' ? navigateMonth('prev') : navigateWeek('prev')}
        >
          <ChevronLeft className="w-4 h-4" />
        </Button>
        <h4 className="font-semibold" style={{ color: '#00224B' }}>
          {monthName}
        </h4>
        <Button
          variant="outline"
          size="sm"
          onClick={() => view === 'month' ? navigateMonth('next') : navigateWeek('next')}
        >
          <ChevronRight className="w-4 h-4" />
        </Button>
      </div>

      {/* Month View */}
      {view === 'month' && (
        <div>
          {/* Day names header */}
          <div className="grid grid-cols-7 gap-1 mb-2">
            {weekDayNames.map((day) => (
              <div key={day} className="text-center text-sm font-medium text-gray-600 py-2">
                {day}
              </div>
            ))}
          </div>

          {/* Days grid */}
          <div className="grid grid-cols-7 gap-1">
            {getDaysInMonth(currentMonth).map((day, index) => {
              if (!day) {
                return <div key={`empty-${index}`} className="aspect-square" />;
              }

              const isDisabled = disabledDates ? disabledDates(day) : false;
              const isSelected = isSameDay(day, selectedDate);
              const isTodayDate = isToday(day);

              return (
                <button
                  key={index}
                  onClick={() => !isDisabled && onSelectDate(day)}
                  disabled={isDisabled}
                  className={`aspect-square rounded-lg text-sm font-medium transition-all ${
                    isSelected
                      ? 'bg-blue-600 text-white shadow-lg'
                      : isTodayDate
                      ? 'bg-blue-100 text-blue-900 border-2 border-blue-600'
                      : isDisabled
                      ? 'text-gray-300 cursor-not-allowed'
                      : 'hover:bg-gray-100 text-gray-900'
                  }`}
                >
                  {day.getDate()}
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Week View */}
      {view === 'week' && (
        <div>
          {/* Day names header */}
          <div className="grid grid-cols-7 gap-2 mb-2">
            {weekDayNames.map((day) => (
              <div key={day} className="text-center text-sm font-medium text-gray-600 py-2">
                {day}
              </div>
            ))}
          </div>

          {/* Days row */}
          <div className="grid grid-cols-7 gap-2">
            {getWeekDays(currentMonth).map((day, index) => {
              const isDisabled = disabledDates ? disabledDates(day) : false;
              const isSelected = isSameDay(day, selectedDate);
              const isTodayDate = isToday(day);

              return (
                <button
                  key={index}
                  onClick={() => !isDisabled && onSelectDate(day)}
                  disabled={isDisabled}
                  className={`p-4 rounded-lg text-center transition-all ${
                    isSelected
                      ? 'bg-blue-600 text-white shadow-lg'
                      : isTodayDate
                      ? 'bg-blue-100 text-blue-900 border-2 border-blue-600'
                      : isDisabled
                      ? 'text-gray-300 cursor-not-allowed bg-gray-50'
                      : 'hover:bg-gray-100 text-gray-900 bg-white border-2 border-gray-200'
                  }`}
                >
                  <div className="text-2xl font-bold">{day.getDate()}</div>
                  <div className="text-xs mt-1">
                    {day.toLocaleDateString('default', { month: 'short' })}
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      )}

      <p className="text-xs text-gray-600 mt-3">
        Weekends and past dates are disabled
      </p>
    </Card>
  );
}
