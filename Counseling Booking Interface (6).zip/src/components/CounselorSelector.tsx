import { Check, Info } from "lucide-react";
import { Card } from "./ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "./ui/dialog";

interface Counselor {
  id: number;
  name: string;
  title: string;
  photo: string;
  office: string;
  specialties: string[];
}

interface CounselorSelectorProps {
  counselors: Counselor[];
  selectedCounselorId: number | null;
  onSelectCounselor: (id: number | null) => void;
}

export function CounselorSelector({ counselors, selectedCounselorId, onSelectCounselor }: CounselorSelectorProps) {
  const getInitials = (name: string) => {
    return name.split(" ").map(n => n[0]).join("").toUpperCase();
  };

  return (
    <div className="space-y-4">
      <div className="text-center">
        <h2 className="text-gray-800 mb-2">Select a Counselor</h2>
        <p className="text-gray-600">Choose a counselor to view their available appointment times</p>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        {/* Individual Counselors */}
        {counselors.map((counselor) => {
          const isSelected = selectedCounselorId === counselor.id;

          return (
            <div key={counselor.id} className="relative">
              <button
                onClick={() => onSelectCounselor(counselor.id)}
                className="text-left w-full"
              >
                <Card
                  className={`p-6 transition-all duration-300 cursor-pointer ${
                    isSelected
                      ? 'bg-gradient-to-br from-blue-500 to-purple-500 text-white shadow-xl scale-105 border-0'
                      : 'bg-white/90 backdrop-blur-sm hover:shadow-lg hover:scale-102 border-gray-200'
                  }`}
                >
                  <div className="flex flex-col items-center text-center space-y-4">
                    <div className="relative">
                      <Avatar
                        className={`w-24 h-24 ${
                          isSelected ? 'border-4 border-white shadow-xl' : 'border-4 border-blue-100'
                        }`}
                      >
                        <AvatarImage src={counselor.photo} alt={counselor.name} />
                        <AvatarFallback
                          className={`text-xl ${
                            isSelected
                              ? 'bg-white/20 text-white'
                              : 'bg-gradient-to-br from-blue-200 to-purple-200 text-blue-900'
                          }`}
                        >
                          {getInitials(counselor.name)}
                        </AvatarFallback>
                      </Avatar>
                      {isSelected && (
                        <div className="absolute -top-2 -right-2 p-1.5 bg-green-500 rounded-full shadow-lg">
                          <Check className="w-4 h-4 text-white" />
                        </div>
                      )}
                    </div>
                    <div>
                      <h3
                        className={`mb-1 ${isSelected ? 'text-white' : 'text-gray-800'}`}
                      >
                        {counselor.name}
                      </h3>
                      <p
                        className={`text-sm ${
                          isSelected ? 'text-blue-100' : 'text-purple-600'
                        }`}
                      >
                        {counselor.title}
                      </p>
                    </div>
                    {counselor.specialties && (
                      <div className="flex flex-wrap gap-2 justify-center">
                        {counselor.specialties.slice(0, 2).map((specialty, index) => (
                          <span
                            key={index}
                            className={`text-xs px-2 py-1 rounded-full ${
                              isSelected
                                ? 'bg-white/20 text-white'
                                : 'bg-blue-100 text-blue-700'
                            }`}
                          >
                            {specialty}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                </Card>
              </button>

              {/* Info Icon */}
              <Dialog>
                <DialogTrigger asChild>
                  <button
                    onClick={(e) => e.stopPropagation()}
                    className={`absolute top-2 right-2 p-2 rounded-full transition-all hover:scale-110 ${
                      isSelected
                        ? 'bg-white/20 hover:bg-white/30 text-white'
                        : 'bg-blue-100 hover:bg-blue-200 text-blue-700'
                    }`}
                  >
                    <Info className="w-4 h-4" />
                  </button>
                </DialogTrigger>
                <DialogContent className="max-w-md">
                  <DialogHeader>
                    <DialogTitle className="flex items-center gap-3">
                      <Avatar className="w-16 h-16 border-4 border-blue-100">
                        <AvatarImage src={counselor.photo} alt={counselor.name} />
                        <AvatarFallback className="bg-gradient-to-br from-blue-200 to-purple-200 text-blue-900">
                          {getInitials(counselor.name)}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <div className="text-lg">{counselor.name}</div>
                        <div className="text-sm font-normal text-purple-600">{counselor.title}</div>
                      </div>
                    </DialogTitle>
                    <DialogDescription asChild>
                      <div className="space-y-4">
                        <div>
                          <h4 className="font-semibold text-gray-900 mb-2">Office Location</h4>
                          <p className="text-gray-600">{counselor.office}</p>
                        </div>
                        <div>
                          <h4 className="font-semibold text-gray-900 mb-2">Specializations</h4>
                          <div className="flex flex-wrap gap-2">
                            {counselor.specialties.map((specialty, index) => (
                              <span
                                key={index}
                                className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm"
                              >
                                {specialty}
                              </span>
                            ))}
                          </div>
                        </div>
                        {counselor.id === 1 && (
                          <div>
                            <h4 className="font-semibold text-gray-900 mb-2">About</h4>
                            <p className="text-gray-600 text-sm leading-relaxed">
                              Tamás has over 8 years of experience helping students navigate mental health challenges. He creates a supportive environment for students dealing with anxiety, stress, and academic pressures.
                            </p>
                          </div>
                        )}
                        {counselor.id === 2 && (
                          <div>
                            <h4 className="font-semibold text-gray-900 mb-2">About</h4>
                            <p className="text-gray-600 text-sm leading-relaxed">
                              Mária focuses on depression support, relationship counseling, and life transitions. She creates a safe, supportive environment for students to explore their emotions and develop coping strategies.
                            </p>
                          </div>
                        )}
                      </div>
                    </DialogDescription>
                  </DialogHeader>
                </DialogContent>
              </Dialog>
            </div>
          );
        })}
      </div>
    </div>
  );
}