import { useState } from "react";
import { CounselorSelector } from "./CounselorSelector";
import { AvailabilityCalendar } from "./AvailabilityCalendar";
import { CreateAppointmentForm } from "./CreateAppointmentForm";
import { BookedAppointment, Counselor } from "../App";
import { AppointmentRequest, AppointmentRequestData } from "./AppointmentRequest";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";

interface UserInfo {
  name: string;
  email: string;
  type: "counselor" | "client" | null;
  avatar?: string;
  neptunId?: string;
}

interface AppointmentBookingProps {
  userType?: "counselor" | "client" | null;
  onBookAppointment: (appointment: Omit<BookedAppointment, 'id' | 'status'>) => void;
  bookedAppointments: BookedAppointment[];
  userInfo: UserInfo | null;
  onSubmitRequest?: (request: Omit<AppointmentRequestData, 'id' | 'status' | 'createdAt'>) => void;
  counselors?: Record<number, Counselor>;
}

export function AppointmentBooking({ 
  userType, 
  onBookAppointment, 
  bookedAppointments, 
  userInfo,
  onSubmitRequest,
  counselors: counselorsFromProps
}: AppointmentBookingProps) {
  const [selectedCounselorId, setSelectedCounselorId] = useState<number | null>(null);

  const language = 'hu'; // Set the language here

  // Use centralized counselors if available, otherwise use local data
  const counselorsArray = counselorsFromProps 
    ? Object.values(counselorsFromProps).map(c => ({
        ...c,
        office: c.id === 1 ? "Student Center, Room 301" : "Student Center, Room 312",
        specialties: c.id === 1 
          ? [language === 'hu' ? 'Szorongáskezelés' : 'Anxiety Management', language === 'hu' ? 'Stresszcsökkentés' : 'Stress Reduction']
          : ["Depression Support", "Relationship Counseling", "Life Transitions"]
      }))
    : [
        {
          id: 1,
          name: "Bognár Tamás",
          title: "Clinical Psychologist",
          photo: "https://static.wixstatic.com/media/dd55ab_702efa8d1aff4f458f7b00c1ca18fd45~mv2.jpg/v1/fill/w_187,h_250,al_c,q_80,usm_0.66_1.00_0.01,enc_avif,quality_auto/Dr_%20Bogn%C3%A1r%20Tam%C3%A1s.jpg",
          office: "Student Center, Room 301",
          specialties: [language === 'hu' ? 'Szorongáskezelés' : 'Anxiety Management', language === 'hu' ? 'Stresszcsökkentés' : 'Stress Reduction']
        },
        {
          id: 2,
          name: "Mária Bogdányi",
          title: "Mental Health Specialist",
          photo: "https://images.unsplash.com/photo-1551836022-deb4988cc6c0?w=400&h=400&fit=crop",
          office: "Student Center, Room 312",
          specialties: ["Depression Support", "Relationship Counseling", "Life Transitions"]
        }
      ];

  // Counselor view: Create appointment form
  if (userType === "counselor") {
    return (
      <div className="px-4 sm:px-6 lg:px-8 py-12">
        <div className="max-w-7xl mx-auto space-y-12">
          {/* Page Header */}
          <div className="text-center">
            <h1 className="text-3xl font-bold mb-3" style={{ color: '#00224B' }}>Create New Appointment</h1>
            <p className="text-gray-600 text-lg">
              Create appointments for your clients
            </p>
          </div>

          {/* Create Appointment Form */}
          <CreateAppointmentForm />

          {/* Info Footer */}
          <div className="text-center text-gray-600 bg-gray-50 rounded-lg p-6 border-2 border-gray-200">
            <p>For emergency support, please call our 24/7 crisis line: <span className="font-semibold" style={{ color: '#005FA3' }}>+36 96 503 400</span></p>
            <p className="mt-2 text-sm">All sessions are confidential and provided free of charge to enrolled students.</p>
          </div>
        </div>
      </div>
    );
  }

  // Client view: Book appointment
  return (
    <div className="px-4 sm:px-6 lg:px-8 py-12">
      <div className="max-w-7xl mx-auto space-y-12">
        {/* Page Header */}
        <div className="text-center">
          <h1 className="text-3xl mb-3" style={{ color: '#00224B' }}>Book an Appointment</h1>
          <p className="text-gray-600 text-lg">
            Choose from available time slots or request a specific appointment
          </p>
        </div>

        {/* Tabs for Book Appointment and Request Appointment */}
        <Tabs defaultValue="book" className="w-full">
          <TabsList className="grid w-full max-w-md mx-auto grid-cols-2 mb-8">
            <TabsTrigger value="book">Book Appointment</TabsTrigger>
            <TabsTrigger value="request">Request Appointment</TabsTrigger>
          </TabsList>

          <TabsContent value="book" className="space-y-12">
            {/* Counselor Selection */}
            <CounselorSelector
              counselors={counselorsArray}
              selectedCounselorId={selectedCounselorId}
              onSelectCounselor={setSelectedCounselorId}
            />

            {/* Calendar View */}
            <AvailabilityCalendar
              counselors={counselorsArray}
              selectedCounselorId={selectedCounselorId}
              onBookAppointment={onBookAppointment}
              bookedAppointments={bookedAppointments}
              userInfo={userInfo}
            />
          </TabsContent>

          <TabsContent value="request">
            {userInfo && onSubmitRequest && (
              <AppointmentRequest 
                onSubmitRequest={onSubmitRequest} 
                userInfo={userInfo}
              />
            )}
          </TabsContent>
        </Tabs>

        {/* Info Footer */}
        <div className="text-center text-gray-600 bg-gray-50 rounded-lg p-6 border-2 border-gray-200">
          <p>For emergency support, please call our 24/7 crisis line: <span className="font-semibold" style={{ color: '#005FA3' }}>+36 96 503 400</span></p>
          <p className="mt-2 text-sm">All sessions are confidential and provided free of charge to enrolled students.</p>
        </div>
      </div>
    </div>
  );
}