import { useState } from "react";
import { Menu, X, Calendar, CalendarCheck, User, LogOut, GraduationCap, Bell, BarChart3, Plus, FileText, Languages, Shield, Inbox } from "lucide-react";
import { Button } from "./ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Badge } from "./ui/badge";
import logo from 'figma:asset/80b194f303c6ba8424bc64751d05f8e5809bf7ff.png';
import { useLanguage } from "../contexts/LanguageContext";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "./ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "./ui/alert-dialog";

type Page = "home" | "booking" | "appointments" | "profile" | "statistics" | "session-notes" | "admin" | "requests";
type UserType = "counselor" | "client" | "admin" | null;

interface UserInfo {
  name: string;
  email: string;
  type: UserType;
  avatar?: string;
}

interface LayoutProps {
  children: React.ReactNode;
  currentPage: Page | string;
  onNavigate: (page: Page) => void;
  onLogout?: () => void;
  userType?: UserType;
  userInfo?: UserInfo | null;
}

export function Layout({ children, currentPage, onNavigate, onLogout, userType, userInfo }: LayoutProps) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [showLogoutDialog, setShowLogoutDialog] = useState(false);
  const { language, setLanguage, t } = useLanguage();
  const [notifications] = useState([
    { id: 1, text: "Upcoming appointment tomorrow at 10:00 AM", read: false },
    { id: 2, text: "Profile updated successfully", read: true },
    { id: 3, text: "New counselor available: Dr. Smith", read: false },
  ]);

  const unreadCount = notifications.filter(n => !n.read).length;

  const menuItems = [
    {
      id: "booking" as Page,
      label: "Book Appointment",
      icon: Calendar,
      description: "Browse counselors and book sessions",
      forClient: true
    },
    {
      id: "appointments" as Page,
      label: "Appointments",
      icon: CalendarCheck,
      description: "View scheduled sessions",
      forAll: true
    },
    {
      id: "statistics" as Page,
      label: "Statistics & Analytics",
      icon: BarChart3,
      description: "View appointment statistics",
      forCounselor: true
    },
    {
      id: "session-notes" as Page,
      label: "Session Notes",
      icon: FileText,
      description: "View and manage session notes",
      forCounselor: true
    },
    {
      id: "admin" as Page,
      label: "Administration",
      icon: Shield,
      description: "Manage system settings",
      forAdmin: true
    }
  ];

  const filteredMenuItems = menuItems.filter(item => 
    item.forAll || 
    (item.forCounselor && userType === "counselor") || 
    (item.forAdmin && userType === "admin") ||
    (item.forClient && userType === "client")
  );

  const handleNavigation = (page: Page) => {
    onNavigate(page);
    setSidebarOpen(false);
  };

  const handleLogoutClick = () => {
    setShowLogoutDialog(true);
  };

  const confirmLogout = () => {
    setShowLogoutDialog(false);
    if (onLogout) {
      onLogout();
    }
  };

  const getInitials = (name?: string) => {
    if (!name) return "U";
    return name
      .split(" ")
      .map(n => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Top White Header Bar */}
      <div className="fixed top-0 left-0 right-0 z-50 bg-white border-b-2 border-gray-200">
        <div className="px-6 py-4 flex items-center justify-between">
          {/* Left: Logo and University Name */}
          <div className="flex items-center gap-4">
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="lg:hidden p-2 rounded hover:bg-gray-100 transition-colors"
              aria-label="Toggle menu"
            >
              {sidebarOpen ? (
                <X className="w-6 h-6" style={{ color: '#00224B' }} />
              ) : (
                <Menu className="w-6 h-6" style={{ color: '#00224B' }} />
              )}
            </button>
            
            <div className="flex items-center gap-4">
              <img 
                src={logo} 
                alt="Széchenyi István University" 
                className="h-12 md:h-14 w-auto"
              />
              <div className="hidden sm:block border-l-2 border-gray-300 pl-4">
                <h1 className="text-lg md:text-xl font-semibold leading-tight" style={{ color: '#00224B' }}>
                  Student Counseling Services
                </h1>
                <p className="text-xs md:text-sm text-gray-600">Széchenyi István University</p>
              </div>
            </div>
          </div>

          {/* Right: User Actions */}
          <div className="flex items-center gap-3">
            {/* Notifications */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  className="relative hover:bg-gray-100"
                  style={{ color: '#00224B' }}
                >
                  <Bell className="w-5 h-5" />
                  {unreadCount > 0 && (
                    <Badge 
                      variant="destructive" 
                      className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 text-xs"
                      style={{ backgroundColor: '#005FA3' }}
                    >
                      {unreadCount}
                    </Badge>
                  )}
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-80">
                <DropdownMenuLabel>Notifications</DropdownMenuLabel>
                <DropdownMenuSeparator />
                {notifications.map(notif => (
                  <DropdownMenuItem key={notif.id} className="flex items-start gap-3 p-3">
                    <div className={`mt-1 w-2 h-2 rounded-full flex-shrink-0`} style={{ backgroundColor: notif.read ? '#d1d5db' : '#005FA3' }} />
                    <div className="flex-1">
                      <p className="text-sm">{notif.text}</p>
                    </div>
                  </DropdownMenuItem>
                ))}
                <DropdownMenuSeparator />
                <DropdownMenuItem className="justify-center" style={{ color: '#005FA3' }}>
                  View all notifications
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            {/* Profile Menu */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="ghost"
                  className="flex items-center gap-2 hover:bg-gray-100"
                  style={{ color: '#00224B' }}
                >
                  <Avatar className="w-9 h-9 border-2" style={{ borderColor: '#005FA3' }}>
                    <AvatarImage src={userInfo?.avatar} />
                    <AvatarFallback className="text-white text-sm" style={{ backgroundColor: '#00224B' }}>
                      {getInitials(userInfo?.name)}
                    </AvatarFallback>
                  </Avatar>
                  <span className="hidden sm:inline font-medium">{userInfo?.name?.split(" ")[0] || "User"}</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuLabel>
                  <div>
                    <p className="font-medium">{userInfo?.name}</p>
                    <p className="text-xs text-gray-500 font-normal">{userInfo?.email}</p>
                    <Badge variant="outline" className="mt-2 capitalize">
                      {userType}
                    </Badge>
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => handleNavigation("profile")}>
                  <User className="w-4 h-4 mr-2" />
                  Profile Settings
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem 
                  onClick={handleLogoutClick}
                  className="text-red-600 focus:text-red-600 focus:bg-red-50"
                >
                  <LogOut className="w-4 h-4 mr-2" />
                  Logout
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            {/* Language Switcher */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  className="hover:bg-gray-100"
                  style={{ color: '#00224B' }}
                >
                  <Languages className="w-5 h-5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-40">
                <DropdownMenuLabel>Language</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem
                  onClick={() => setLanguage('en')}
                  className={language === 'en' ? "bg-gray-100" : ""}
                >
                  English
                </DropdownMenuItem>
                <DropdownMenuItem
                  onClick={() => setLanguage('hu')}
                  className={language === 'hu' ? "bg-gray-100" : ""}
                >
                  Hungarian
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>

      {/* Navigation Bar - Below Header */}
      <nav className="fixed top-[88px] left-0 right-0 z-40 border-b border-gray-200" style={{ backgroundColor: '#00224B' }}>
        <div className="px-6">
          <div className="flex items-center gap-1">
            <button
              onClick={() => handleNavigation("home")}
              className={`px-6 py-4 text-white hover:bg-white/10 transition-colors font-medium ${
                currentPage === "home" ? "bg-white/20 border-b-2" : ""
              }`}
              style={currentPage === "home" ? { borderBottomColor: '#1E90FF' } : {}}
            >
              Home
            </button>
            {filteredMenuItems.map((item) => (
              <button
                key={item.id}
                onClick={() => handleNavigation(item.id)}
                className={`px-6 py-4 text-white hover:bg-white/10 transition-colors font-medium ${
                  currentPage === item.id ? "bg-white/20 border-b-2" : ""
                }`}
                style={currentPage === item.id ? { borderBottomColor: '#1E90FF' } : {}}
              >
                {item.label}
              </button>
            ))}
          </div>
        </div>
      </nav>

      {/* Mobile Sidebar Overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-30 lg:hidden"
          style={{ top: '88px' }}
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Mobile Sidebar */}
      <aside
        className={`fixed top-[88px] left-0 bottom-0 z-40 w-72 bg-white border-r border-gray-200 shadow-lg transition-transform duration-300 lg:hidden ${
          sidebarOpen ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        <nav className="p-4 space-y-1">
          <button
            onClick={() => handleNavigation("home")}
            className={`w-full text-left px-4 py-3 rounded transition-colors font-medium ${
              currentPage === "home" 
                ? "text-white" 
                : "hover:bg-gray-100"
            }`}
            style={currentPage === "home" ? { backgroundColor: '#00224B', color: 'white' } : { color: '#00224B' }}
          >
            Home
          </button>
          {filteredMenuItems.map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => handleNavigation(item.id)}
                className={`w-full text-left px-4 py-3 rounded transition-colors font-medium flex items-center gap-3 ${
                  currentPage === item.id 
                    ? "text-white" 
                    : "hover:bg-gray-100"
                }`}
                style={currentPage === item.id ? { backgroundColor: '#00224B', color: 'white' } : { color: '#00224B' }}
              >
                <Icon className="w-5 h-5" />
                <div>
                  <div>{item.label}</div>
                  <div className="text-xs opacity-75">{item.description}</div>
                </div>
              </button>
            );
          })}
        </nav>

        {/* Footer in sidebar */}
        <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-gray-200 bg-gray-50">
          <div className="text-center space-y-1">
            <p className="text-sm font-medium" style={{ color: '#00224B' }}>Need immediate help?</p>
            <p className="font-semibold" style={{ color: '#005FA3' }}>+36 96 503 400</p>
            <p className="text-xs text-gray-600">Available 24/7</p>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="pt-[152px] min-h-screen">
        {children}
      </main>

      {/* Footer */}
      <footer className="border-t border-gray-200 py-8" style={{ backgroundColor: '#00224B' }}>
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid md:grid-cols-3 gap-8 text-white">
            <div>
              <h3 className="font-semibold mb-3">Széchenyi István University</h3>
              <p className="text-sm text-gray-300">Győr, Hungary</p>
              <p className="text-sm text-gray-300">H-9026 Győr, Egyetem tér 1</p>
            </div>
            <div>
              <h3 className="font-semibold mb-3">Contact</h3>
              <p className="text-sm text-gray-300">Phone: +36 96 503 400</p>
              <p className="text-sm text-gray-300">Email: counseling@sze.hu</p>
            </div>
            <div>
              <h3 className="font-semibold mb-3">Emergency</h3>
              <p className="text-sm text-gray-300">Crisis Line: +36 96 503 400</p>
              <p className="text-sm text-gray-300">Available 24/7</p>
            </div>
          </div>
          <div className="mt-8 pt-6 border-t border-gray-700 text-center text-sm text-gray-400">
            <p>© 2025 Széchenyi István University. All rights reserved.</p>
          </div>
        </div>
      </footer>

      {/* Logout Confirmation Dialog */}
      <AlertDialog open={showLogoutDialog} onOpenChange={setShowLogoutDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirm Logout</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to log out? You will need to log in again to access your account.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={confirmLogout}
              className="bg-red-600 hover:bg-red-700"
            >
              Logout
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}