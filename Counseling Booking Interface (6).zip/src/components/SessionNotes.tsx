import { useState } from "react";
import { FileText, Save, Plus, Calendar, User } from "lucide-react";
import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { Textarea } from "./ui/textarea";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Badge } from "./ui/badge";
import { toast } from "sonner@2.0.3";

interface SessionNote {
  id: string;
  clientName: string;
  date: string;
  notes: string;
  category: string;
}

export function SessionNotes() {
  const [notes, setNotes] = useState<SessionNote[]>([
    {
      id: "1",
      clientName: "John Doe",
      date: "Nov 10, 2025",
      notes: "Client showing improvement in anxiety management. Continued cognitive behavioral therapy techniques. Discussed coping strategies for academic stress.",
      category: "Anxiety"
    },
    {
      id: "2",
      clientName: "Jane Smith",
      date: "Nov 10, 2025",
      notes: "Second session focused on relationship dynamics. Client expressing better communication skills. Homework: practice active listening techniques.",
      category: "Relationships"
    }
  ]);

  const [isAddingNote, setIsAddingNote] = useState(false);
  const [newNote, setNewNote] = useState({
    clientName: "",
    date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
    notes: "",
    category: ""
  });

  const handleSaveNote = () => {
    if (!newNote.clientName || !newNote.notes) {
      toast.error("Missing Information", {
        description: "Please fill in client name and session notes.",
        duration: 3000,
      });
      return;
    }

    const note: SessionNote = {
      id: Date.now().toString(),
      ...newNote
    };

    setNotes(prev => [note, ...prev]);
    setNewNote({
      clientName: "",
      date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
      notes: "",
      category: ""
    });
    setIsAddingNote(false);

    toast.success("Note Saved", {
      description: "Session note has been saved successfully.",
      duration: 3000,
    });
  };

  return (
    <div className="px-4 sm:px-6 lg:px-8 py-8 max-w-7xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <div className="p-3 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-xl">
            <FileText className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-blue-900">Post-Session Notes</h1>
            <p className="text-gray-600">
              Document and manage your session notes
            </p>
          </div>
        </div>
      </div>

      {/* Add Note Button */}
      {!isAddingNote && (
        <Card className="p-6 mb-6 bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
          <Button
            onClick={() => setIsAddingNote(true)}
            className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white"
          >
            <Plus className="w-5 h-5 mr-2" />
            Add New Session Note
          </Button>
        </Card>
      )}

      {/* Add Note Form */}
      {isAddingNote && (
        <Card className="p-6 md:p-8 mb-6 bg-white/90 backdrop-blur-sm border-blue-200 shadow-lg">
          <h3 className="text-gray-800 mb-6">New Session Note</h3>
          
          <div className="space-y-6">
            {/* Client Name */}
            <div>
              <Label htmlFor="clientName" className="text-gray-700 mb-2">
                Client Name
              </Label>
              <Input
                id="clientName"
                placeholder="Enter client name"
                value={newNote.clientName}
                onChange={(e) => setNewNote({ ...newNote, clientName: e.target.value })}
                className="border-gray-300"
              />
            </div>

            {/* Category */}
            <div>
              <Label htmlFor="category" className="text-gray-700 mb-2">
                Category (Optional)
              </Label>
              <Input
                id="category"
                placeholder="e.g., Anxiety, Depression, Relationships"
                value={newNote.category}
                onChange={(e) => setNewNote({ ...newNote, category: e.target.value })}
                className="border-gray-300"
              />
            </div>

            {/* Notes */}
            <div>
              <Label htmlFor="notes" className="text-gray-700 mb-2">
                Session Notes
              </Label>
              <Textarea
                id="notes"
                placeholder="Enter detailed session notes, observations, and recommendations..."
                value={newNote.notes}
                onChange={(e) => setNewNote({ ...newNote, notes: e.target.value })}
                className="min-h-[150px] border-gray-300"
              />
            </div>

            {/* Actions */}
            <div className="flex gap-3 justify-end">
              <Button
                variant="outline"
                onClick={() => {
                  setIsAddingNote(false);
                  setNewNote({
                    clientName: "",
                    date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
                    notes: "",
                    category: ""
                  });
                }}
              >
                Cancel
              </Button>
              <Button
                onClick={handleSaveNote}
                className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white"
              >
                <Save className="w-4 h-4 mr-2" />
                Save Note
              </Button>
            </div>
          </div>
        </Card>
      )}

      {/* Notes List */}
      <div className="space-y-4">
        {notes.map((note) => (
          <Card key={note.id} className="p-6 bg-white/90 backdrop-blur-sm border-gray-200 hover:shadow-lg transition-shadow">
            <div className="flex flex-col md:flex-row md:items-start gap-4">
              {/* Icon */}
              <div className="p-3 bg-blue-100 rounded-lg flex-shrink-0">
                <FileText className="w-6 h-6 text-blue-700" />
              </div>

              {/* Content */}
              <div className="flex-1">
                <div className="flex flex-wrap items-center gap-3 mb-3">
                  <h3 className="text-gray-800">{note.clientName}</h3>
                  {note.category && (
                    <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100">
                      {note.category}
                    </Badge>
                  )}
                </div>

                <div className="flex items-center gap-4 mb-3 text-sm text-gray-600">
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4" />
                    <span>{note.date}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <User className="w-4 h-4" />
                    <span>Session Notes</span>
                  </div>
                </div>

                <p className="text-gray-700 whitespace-pre-wrap">{note.notes}</p>
              </div>
            </div>
          </Card>
        ))}
      </div>

      {notes.length === 0 && !isAddingNote && (
        <Card className="p-12 text-center bg-white/90">
          <FileText className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-gray-800 mb-2">No Session Notes Yet</h3>
          <p className="text-gray-600 mb-6">
            Start documenting your sessions by adding your first note.
          </p>
        </Card>
      )}
    </div>
  );
}
