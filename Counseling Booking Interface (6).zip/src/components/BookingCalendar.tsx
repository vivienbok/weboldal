import { useState } from "react";
import { Calendar as CalendarIcon, Clock, User, MapPin, Check, X, ChevronLeft, ChevronRight } from "lucide-react";
import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";

interface Counselor {
  id: number;
  name: string;
  title: string;
  photo: string;
  office: string;
}

interface TimeSlot {
  time: string;
  counselor: Counselor;
  available: boolean;
}

interface BookedAppointment {
  id: string;
  date: Date;
  time: string;
  counselor: Counselor;
}

interface BookingCalendarProps {
  counselors: Counselor[];
  onBookingComplete?: (appointment: BookedAppointment) => void;
}

export function BookingCalendar({ counselors, onBookingComplete }: BookingCalendarProps) {
  const [currentWeekStart, setCurrentWeekStart] = useState<Date>(() => {
    const today = new Date();
    const dayOfWeek = today.getDay();
    const monday = new Date(today);
    monday.setDate(today.getDate() - dayOfWeek + (dayOfWeek === 0 ? -6 : 1));
    monday.setHours(0, 0, 0, 0);
    return monday;
  });
  
  const [selectedSlot, setSelectedSlot] = useState<{ date: Date; slot: TimeSlot } | null>(null);
  const [bookedAppointments, setBookedAppointments] = useState<BookedAppointment[]>([]);
  const [showConfirmation, setShowConfirmation] = useState(false);

  // Time slots for the day
  const timeSlots = [
    "9:00 AM",
    "10:00 AM",
    "11:00 AM",
    "12:00 PM",
    "1:00 PM",
    "2:00 PM",
    "3:00 PM",
    "4:00 PM"
  ];

  // Get the current week days (Monday to Friday)
  const getWeekDays = () => {
    const days = [];
    for (let i = 0; i < 5; i++) {
      const day = new Date(currentWeekStart);
      day.setDate(currentWeekStart.getDate() + i);
      days.push(day);
    }
    return days;
  };

  const weekDays = getWeekDays();

  // Mock available appointments for each day/time
  const getAppointmentForSlot = (date: Date, time: string): TimeSlot | null => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    // Don't show slots for past dates
    if (date < today) {
      return null;
    }

    // Check if already booked
    const isBooked = bookedAppointments.some(
      apt => apt.date.toDateString() === date.toDateString() && apt.time === time
    );

    if (isBooked) {
      return null;
    }

    const dayOfWeek = date.getDay();
    
    // Generate mock appointments based on day and time
    // Monday and Wednesday - Counselor 0
    if ((dayOfWeek === 1 || dayOfWeek === 3) && (time === "9:00 AM" || time === "10:00 AM" || time === "2:00 PM")) {
      return {
        time,
        counselor: counselors[0],
        available: true
      };
    }
    // Tuesday and Thursday - Counselor 1
    if ((dayOfWeek === 2 || dayOfWeek === 4) && (time === "10:00 AM" || time === "11:00 AM" || time === "3:00 PM")) {
      return {
        time,
        counselor: counselors[1],
        available: true
      };
    }
    // Friday - Both counselors
    if (dayOfWeek === 5) {
      if (time === "9:00 AM" || time === "1:00 PM") {
        return {
          time,
          counselor: counselors[0],
          available: true
        };
      }
      if (time === "11:00 AM" || time === "3:00 PM") {
        return {
          time,
          counselor: counselors[1],
          available: true
        };
      }
    }

    return null;
  };

  const handleSlotClick = (date: Date, slot: TimeSlot) => {
    setSelectedSlot({ date, slot });
  };

  const handleConfirmBooking = () => {
    if (!selectedSlot) return;

    const newAppointment: BookedAppointment = {
      id: Date.now().toString(),
      date: selectedSlot.date,
      time: selectedSlot.slot.time,
      counselor: selectedSlot.slot.counselor
    };

    setBookedAppointments([...bookedAppointments, newAppointment]);
    setShowConfirmation(true);
    
    if (onBookingComplete) {
      onBookingComplete(newAppointment);
    }

    // Reset selection after a delay
    setTimeout(() => {
      setShowConfirmation(false);
      setSelectedSlot(null);
    }, 3000);
  };

  const handleCancelAppointment = (id: string) => {
    setBookedAppointments(bookedAppointments.filter(apt => apt.id !== id));
  };

  const goToPreviousWeek = () => {
    const newWeekStart = new Date(currentWeekStart);
    newWeekStart.setDate(currentWeekStart.getDate() - 7);
    setCurrentWeekStart(newWeekStart);
    setSelectedSlot(null);
  };

  const goToNextWeek = () => {
    const newWeekStart = new Date(currentWeekStart);
    newWeekStart.setDate(currentWeekStart.getDate() + 7);
    setCurrentWeekStart(newWeekStart);
    setSelectedSlot(null);
  };

  const goToCurrentWeek = () => {
    const today = new Date();
    const dayOfWeek = today.getDay();
    const monday = new Date(today);
    monday.setDate(today.getDate() - dayOfWeek + (dayOfWeek === 0 ? -6 : 1));
    monday.setHours(0, 0, 0, 0);
    setCurrentWeekStart(monday);
    setSelectedSlot(null);
  };

  const getInitials = (name: string) => {
    return name.split(" ").map(n => n[0]).join("").toUpperCase();
  };

  const monthYear = currentWeekStart.toLocaleDateString('default', { month: 'long', year: 'numeric' });
  const weekRange = `${weekDays[0].toLocaleDateString('default', { month: 'short', day: 'numeric' })} - ${weekDays[4].toLocaleDateString('default', { month: 'short', day: 'numeric' })}`;

  return (
    <div className="grid lg:grid-cols-3 gap-8">
      {/* Weekly Calendar Section */}
      <div className="lg:col-span-2 space-y-6">
        {/* Success Message */}
        {showConfirmation && (
          <Card className="p-6 text-white shadow-xl animate-in fade-in slide-in-from-bottom-4 duration-300" style={{ backgroundColor: '#005FA3' }}>
            <div className="flex items-center gap-4">
              <div className="p-3 bg-white/20 rounded-full">
                <Check className="w-6 h-6" />
              </div>
              <div>
                <h3>Appointment Confirmed!</h3>
                <p className="text-blue-100">Your appointment has been successfully booked.</p>
              </div>
            </div>
          </Card>
        )}

        <Card className="bg-white border-2 border-gray-200 overflow-hidden">
          {/* Calendar Header - Dark Navy */}
          <div className="p-4" style={{ backgroundColor: '#00224B' }}>
            <div className="flex items-center justify-between mb-4">
              <Button
                onClick={goToPreviousWeek}
                variant="ghost"
                size="sm"
                className="text-white hover:bg-white/10"
              >
                <ChevronLeft className="w-5 h-5" />
                <ChevronLeft className="w-5 h-5 -ml-3" />
              </Button>
              
              <div className="text-center">
                <h2 className="text-white font-semibold text-lg">{monthYear}</h2>
                <p className="text-blue-200 text-sm">{weekRange}</p>
              </div>

              <Button
                onClick={goToNextWeek}
                variant="ghost"
                size="sm"
                className="text-white hover:bg-white/10"
              >
                <ChevronRight className="w-5 h-5" />
                <ChevronRight className="w-5 h-5 -ml-3" />
              </Button>
            </div>

            <div className="flex justify-center">
              <Button
                onClick={goToCurrentWeek}
                size="sm"
                className="text-white border border-white/30 hover:bg-white/10"
                variant="outline"
              >
                Today
              </Button>
            </div>
          </div>

          {/* Days Header */}
          <div className="grid grid-cols-6 border-b-2 border-gray-200" style={{ backgroundColor: '#00224B' }}>
            <div className="p-3 text-center border-r border-white/10">
              <span className="text-white text-sm">TIME</span>
            </div>
            {weekDays.map((day, index) => (
              <div 
                key={index} 
                className={`p-3 text-center ${index < 4 ? 'border-r border-white/10' : ''}`}
              >
                <div className="text-white font-semibold text-sm">
                  {day.toLocaleDateString('default', { weekday: 'short' }).toUpperCase()}
                </div>
                <div className="text-blue-200 text-lg mt-1">
                  {day.getDate()}
                </div>
              </div>
            ))}
          </div>

          {/* Time Slots Grid */}
          <div className="overflow-x-auto">
            {timeSlots.map((time, timeIndex) => (
              <div 
                key={timeIndex} 
                className="grid grid-cols-6 border-b border-gray-200 min-h-[80px]"
              >
                {/* Time Label */}
                <div className="p-3 border-r border-gray-200 flex items-center justify-center bg-gray-50">
                  <span className="text-sm text-gray-600">{time}</span>
                </div>

                {/* Day Cells */}
                {weekDays.map((day, dayIndex) => {
                  const appointment = getAppointmentForSlot(day, time);
                  const isSelected = selectedSlot?.date.toDateString() === day.toDateString() && 
                                    selectedSlot?.slot.time === time;
                  const isPast = day < new Date(new Date().setHours(0, 0, 0, 0));

                  return (
                    <div 
                      key={dayIndex}
                      className={`p-2 ${dayIndex < 4 ? 'border-r border-gray-200' : ''} ${
                        isPast ? 'bg-gray-50' : ''
                      }`}
                    >
                      {appointment ? (
                        <button
                          onClick={() => handleSlotClick(day, appointment)}
                          disabled={isPast}
                          className={`w-full h-full p-2 rounded-lg text-left transition-all duration-200 ${
                            isPast
                              ? 'opacity-50 cursor-not-allowed bg-gray-100'
                              : isSelected
                              ? 'shadow-lg scale-105'
                              : 'hover:shadow-md'
                          }`}
                          style={{
                            backgroundColor: isSelected 
                              ? '#005FA3' 
                              : appointment.counselor.id === 1 
                                ? '#60A5FA' 
                                : '#3B82F6',
                            color: 'white'
                          }}
                        >
                          <div className="flex items-center gap-2">
                            <Avatar className="w-6 h-6 border border-white">
                              <AvatarImage src={appointment.counselor.photo} />
                              <AvatarFallback className="bg-white/20 text-white text-[10px]">
                                {getInitials(appointment.counselor.name)}
                              </AvatarFallback>
                            </Avatar>
                            <div className="flex-1 min-w-0">
                              <p className="text-xs truncate">{appointment.counselor.name}</p>
                            </div>
                          </div>
                          {isSelected && (
                            <div className="mt-1">
                              <Check className="w-4 h-4" />
                            </div>
                          )}
                        </button>
                      ) : null}
                    </div>
                  );
                })}
              </div>
            ))}
          </div>

          {/* Legend */}
          <div className="p-4 bg-gray-50 border-t-2 border-gray-200">
            <div className="flex flex-wrap gap-4 justify-center">
              {counselors.map((counselor, index) => (
                <div key={counselor.id} className="flex items-center gap-2">
                  <div 
                    className="w-4 h-4 rounded"
                    style={{ backgroundColor: counselor.id === 1 ? '#60A5FA' : '#3B82F6' }}
                  />
                  <span className="text-sm text-gray-700">{counselor.name}</span>
                </div>
              ))}
            </div>
          </div>
        </Card>

        {/* Booking Confirmation */}
        {selectedSlot && (
          <Card className="p-6 bg-white border-2 border-gray-200 animate-in fade-in slide-in-from-bottom-4 duration-300">
            <div className="mb-4 p-4 bg-blue-50 rounded-lg border-2" style={{ borderColor: '#005FA3' }}>
              <p className="text-sm font-semibold mb-2" style={{ color: '#00224B' }}>📅 Selected Appointment:</p>
              <p className="text-gray-700">
                <strong>{selectedSlot.date.toLocaleDateString('default', { 
                  weekday: 'long', 
                  month: 'long', 
                  day: 'numeric',
                  year: 'numeric'
                })}</strong> at <strong>{selectedSlot.slot.time}</strong>
              </p>
              <div className="flex items-center gap-2 mt-2">
                <Avatar className="w-8 h-8 border-2 border-blue-300">
                  <AvatarImage src={selectedSlot.slot.counselor.photo} />
                  <AvatarFallback className="bg-blue-200 text-blue-900 text-xs">
                    {getInitials(selectedSlot.slot.counselor.name)}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <p className="text-sm text-gray-700">{selectedSlot.slot.counselor.name}</p>
                  <p className="text-xs text-gray-600">{selectedSlot.slot.counselor.title}</p>
                </div>
              </div>
            </div>
            <Button
              onClick={handleConfirmBooking}
              className="w-full text-white shadow-lg py-6"
              style={{ backgroundColor: '#005FA3' }}
            >
              <Check className="w-5 h-5 mr-2" />
              Confirm Booking
            </Button>
          </Card>
        )}
      </div>

      {/* Booked Appointments Sidebar */}
      <div className="lg:col-span-1">
        <Card className="p-6 bg-white border-2 border-gray-200 sticky top-20">
          <h3 className="mb-4" style={{ color: '#00224B' }}>Your Appointments</h3>
          
          {bookedAppointments.length > 0 ? (
            <div className="space-y-4">
              {bookedAppointments.map((appointment) => (
                <Card
                  key={appointment.id}
                  className="p-4 bg-gradient-to-br from-green-50 to-emerald-50 border-2 border-green-200"
                >
                  <div className="flex items-start gap-3 mb-3">
                    <Avatar className="w-12 h-12 border-2 border-green-300">
                      <AvatarImage src={appointment.counselor.photo} />
                      <AvatarFallback className="bg-green-200 text-green-900 text-sm">
                        {getInitials(appointment.counselor.name)}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm text-green-900 truncate">
                        {appointment.counselor.name}
                      </p>
                      <p className="text-xs text-green-700">
                        {appointment.counselor.title}
                      </p>
                    </div>
                  </div>
                  
                  <div className="space-y-2 mb-3">
                    <div className="flex items-center gap-2 text-sm text-gray-700">
                      <CalendarIcon className="w-4 h-4 text-green-600" />
                      <span>{appointment.date.toLocaleDateString('default', { 
                        month: 'short', 
                        day: 'numeric',
                        year: 'numeric'
                      })}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-700">
                      <Clock className="w-4 h-4 text-green-600" />
                      <span>{appointment.time}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-700">
                      <MapPin className="w-4 h-4 text-green-600" />
                      <span className="text-xs">{appointment.counselor.office}</span>
                    </div>
                  </div>

                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleCancelAppointment(appointment.id)}
                    className="w-full border-red-300 text-red-700 hover:bg-red-50"
                  >
                    <X className="w-4 h-4 mr-1" />
                    Cancel
                  </Button>
                </Card>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <CalendarIcon className="w-12 h-12 mx-auto mb-3 text-gray-400" />
              <p className="text-sm text-gray-500">No appointments booked yet</p>
              <p className="text-xs text-gray-400 mt-1">Select a time slot to get started</p>
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}
