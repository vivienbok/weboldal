import { Counselor, TimeSlot } from '../App';
import { Button } from './ui/button';
import { Calendar, Clock } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface CounselorCardProps {
  counselor: Counselor;
  onSlotSelect: (counselor: Counselor, slot: TimeSlot) => void;
}

export function CounselorCard({ counselor, onSlotSelect }: CounselorCardProps) {
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      weekday: 'short', 
      month: 'short', 
      day: 'numeric' 
    });
  };

  return (
    <div className="bg-white rounded-2xl shadow-md overflow-hidden hover:shadow-lg transition-shadow">
      {/* Counselor Header */}
      <div className="bg-gradient-to-r from-purple-500 to-pink-500 p-6">
        <div className="flex items-center gap-4">
          <div className="relative">
            <ImageWithFallback
              src={counselor.photo}
              alt={counselor.name}
              className="w-20 h-20 rounded-full object-cover border-4 border-white shadow-lg"
            />
            <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-green-400 rounded-full border-2 border-white"></div>
          </div>
          <div className="flex-1">
            <h2 className="text-white">{counselor.name}</h2>
            <p className="text-purple-100">{counselor.title}</p>
          </div>
        </div>
      </div>

      {/* Time Slots */}
      <div className="p-6">
        <div className="flex items-center gap-2 mb-4 text-gray-600">
          <Clock className="w-4 h-4" />
          <h3 className="text-gray-900">Available Time Slots</h3>
        </div>
        
        <div className="space-y-2">
          {counselor.timeSlots.map((slot) => (
            <div
              key={slot.id}
              className="flex items-center justify-between p-3 bg-purple-50/50 rounded-xl border border-purple-100 hover:bg-purple-50 transition-colors"
            >
              <div className="flex items-center gap-3">
                <Calendar className="w-4 h-4 text-purple-600" />
                <div>
                  <p className="text-gray-900">{formatDate(slot.date)}</p>
                  <p className="text-gray-600">{slot.time}</p>
                </div>
              </div>
              <Button
                onClick={() => onSlotSelect(counselor, slot)}
                disabled={!slot.available}
                className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white shadow-md"
              >
                Book
              </Button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
