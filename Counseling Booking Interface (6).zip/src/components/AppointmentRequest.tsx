import { useState } from "react";
import { Calendar, Clock, User, MessageSquare, Send, MapPin, FileText } from "lucide-react";
import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { Label } from "./ui/label";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { toast } from "sonner@2.0.3";

export interface AppointmentRequestData {
  id: string;
  counselorId: number;
  counselorName: string;
  patientName: string;
  patientEmail: string;
  preferredDate: Date;
  preferredTime: string;
  location?: string;
  topic?: string;
  comment: string;
  status: 'pending' | 'accepted' | 'rejected';
  createdAt: Date;
}

interface AppointmentRequestProps {
  onSubmitRequest: (request: Omit<AppointmentRequestData, 'id' | 'status' | 'createdAt'>) => void;
  userInfo: {
    name: string;
    email: string;
  };
}

export function AppointmentRequest({ onSubmitRequest, userInfo }: AppointmentRequestProps) {
  const [formData, setFormData] = useState({
    counselorId: "",
    preferredDate: "",
    preferredTime: "",
    location: "",
    topic: "",
    comment: ""
  });

  const counselors = [
    {
      id: 1,
      name: "Bognár Tamás",
      title: "Clinical Psychologist",
      photo: "https://static.wixstatic.com/media/dd55ab_702efa8d1aff4f458f7b00c1ca18fd45~mv2.jpg/v1/fill/w_187,h_250,al_c,q_80,usm_0.66_1.00_0.01,enc_avif,quality_auto/Dr_%20Bogn%C3%A1r%20Tam%C3%A1s.jpg",
      specialties: ["Anxiety Management", "Stress Reduction"]
    },
    {
      id: 2,
      name: "Mária Bogdányi",
      title: "Mental Health Specialist",
      photo: "https://images.unsplash.com/photo-1551836022-deb4988cc6c0?w=400&h=400&fit=crop",
      specialties: ["Depression Support", "Relationship Counseling"]
    }
  ];

  const selectedCounselor = counselors.find(c => c.id.toString() === formData.counselorId);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.counselorId || !formData.preferredDate || !formData.preferredTime) {
      toast.error("Missing Information", {
        description: "Please fill in all required fields",
      });
      return;
    }

    const counselor = counselors.find(c => c.id.toString() === formData.counselorId);
    if (!counselor) return;

    onSubmitRequest({
      counselorId: parseInt(formData.counselorId),
      counselorName: counselor.name,
      patientName: userInfo.name,
      patientEmail: userInfo.email,
      preferredDate: new Date(formData.preferredDate),
      preferredTime: formData.preferredTime,
      location: formData.location,
      topic: formData.topic,
      comment: formData.comment
    });

    // Reset form
    setFormData({
      counselorId: "",
      preferredDate: "",
      preferredTime: "",
      location: "",
      topic: "",
      comment: ""
    });

    toast.success("Request Submitted", {
      description: "Your appointment request has been sent to the counselor",
      duration: 5000,
    });
  };

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase();
  };

  return (
    <div className="px-4 sm:px-6 lg:px-8 py-12">
      <div className="max-w-3xl mx-auto">
        {/* Page Header */}
        <div className="mb-8 text-center">
          <h1 className="text-3xl mb-3" style={{ color: '#00224B' }}>Request an Appointment</h1>
          <p className="text-gray-600 text-lg">
            Can't find a suitable time slot? Request a specific appointment and the counselor will review your request.
          </p>
        </div>

        <Card className="p-6 md:p-8 bg-white/90 shadow-lg">
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Counselor Selection */}
            <div className="space-y-2">
              <Label htmlFor="counselor" className="flex items-center gap-2 text-gray-900">
                <User className="w-4 h-4" />
                Select Counselor *
              </Label>
              <Select
                value={formData.counselorId}
                onValueChange={(value) => setFormData({ ...formData, counselorId: value })}
              >
                <SelectTrigger id="counselor" className="h-auto">
                  <SelectValue placeholder="Choose a counselor" />
                </SelectTrigger>
                <SelectContent>
                  {counselors.map((counselor) => (
                    <SelectItem key={counselor.id} value={counselor.id.toString()}>
                      <div className="flex items-center gap-3 py-2">
                        <Avatar className="w-10 h-10 border-2 border-blue-100">
                          <AvatarImage src={counselor.photo} alt={counselor.name} />
                          <AvatarFallback className="bg-gradient-to-br from-blue-200 to-purple-200 text-blue-900">
                            {getInitials(counselor.name)}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <div className="font-medium">{counselor.name}</div>
                          <div className="text-sm text-gray-600">{counselor.title}</div>
                        </div>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              
              {/* Show selected counselor details */}
              {selectedCounselor && (
                <Card className="p-4 bg-gradient-to-r from-blue-50 to-purple-50 border-blue-200 mt-2">
                  <div className="flex items-center gap-4">
                    <Avatar className="w-16 h-16 border-4 border-blue-100">
                      <AvatarImage src={selectedCounselor.photo} alt={selectedCounselor.name} />
                      <AvatarFallback className="bg-gradient-to-br from-blue-200 to-purple-200 text-blue-900">
                        {getInitials(selectedCounselor.name)}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <h3 className="text-gray-900 mb-1">{selectedCounselor.name}</h3>
                      <p className="text-sm text-purple-600 mb-2">{selectedCounselor.title}</p>
                      <div className="flex flex-wrap gap-1">
                        {selectedCounselor.specialties.map((specialty, index) => (
                          <span 
                            key={index}
                            className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded"
                          >
                            {specialty}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </Card>
              )}
            </div>

            {/* Preferred Date */}
            <div className="space-y-2">
              <Label htmlFor="date" className="flex items-center gap-2 text-gray-900">
                <Calendar className="w-4 h-4" />
                Preferred Date *
              </Label>
              <Input
                id="date"
                type="date"
                value={formData.preferredDate}
                onChange={(e) => setFormData({ ...formData, preferredDate: e.target.value })}
                min={new Date().toISOString().split('T')[0]}
                className="text-gray-900"
              />
            </div>

            {/* Preferred Time */}
            <div className="space-y-2">
              <Label htmlFor="time" className="flex items-center gap-2 text-gray-900">
                <Clock className="w-4 h-4" />
                Preferred Time *
              </Label>
              <Input
                id="time"
                type="time"
                value={formData.preferredTime}
                onChange={(e) => setFormData({ ...formData, preferredTime: e.target.value })}
                className="text-gray-900"
              />
            </div>

            {/* Location */}
            <div className="space-y-2">
              <Label htmlFor="location" className="flex items-center gap-2 text-gray-900">
                <MapPin className="w-4 h-4" />
                Location (Optional)
              </Label>
              <Input
                id="location"
                type="text"
                value={formData.location}
                onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                className="text-gray-900"
              />
            </div>

            {/* Topic */}
            <div className="space-y-2">
              <Label htmlFor="topic" className="flex items-center gap-2 text-gray-900">
                <FileText className="w-4 h-4" />
                Topic (Optional)
              </Label>
              <Input
                id="topic"
                type="text"
                value={formData.topic}
                onChange={(e) => setFormData({ ...formData, topic: e.target.value })}
                className="text-gray-900"
              />
            </div>

            {/* Comment/Note */}
            <div className="space-y-2">
              <Label htmlFor="comment" className="flex items-center gap-2 text-gray-900">
                <MessageSquare className="w-4 h-4" />
                Additional Comments (Optional)
              </Label>
              <Textarea
                id="comment"
                value={formData.comment}
                onChange={(e) => setFormData({ ...formData, comment: e.target.value })}
                placeholder="Let the counselor know any specific concerns or topics you'd like to discuss..."
                rows={4}
                className="resize-none text-gray-900"
              />
              <p className="text-sm text-gray-500">
                This helps the counselor prepare for your session and determine availability.
              </p>
            </div>

            {/* Submit Button */}
            <div className="pt-4">
              <Button 
                type="submit"
                className="w-full bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 text-white"
              >
                <Send className="w-4 h-4 mr-2" />
                Submit Request
              </Button>
            </div>
          </form>
        </Card>

        {/* Info Section */}
        <Card className="mt-6 p-6 bg-gradient-to-r from-blue-50 to-purple-50 border-blue-200">
          <h3 className="text-gray-800 mb-2">What happens next?</h3>
          <ul className="space-y-2 text-sm text-gray-700">
            <li className="flex items-start gap-2">
              <span className="text-blue-600 mt-1">•</span>
              <span>Your request will be sent to the selected counselor</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-blue-600 mt-1">•</span>
              <span>The counselor will review your request and preferred time</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-blue-600 mt-1">•</span>
              <span>If approved, the appointment will appear in your "Booked Appointments"</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-blue-600 mt-1">•</span>
              <span>You'll receive a notification once the counselor responds</span>
            </li>
          </ul>
        </Card>
      </div>
    </div>
  );
}