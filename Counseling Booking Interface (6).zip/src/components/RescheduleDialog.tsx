import { useState } from "react";
import { X, Calendar, Clock, Check } from "lucide-react";
import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";

interface Counselor {
  name: string;
  title: string;
  photo: string;
}

interface Appointment {
  id: string;
  counselor: Counselor;
  date: string;
  day: string;
  time: string;
  location: string;
  status: "confirmed" | "pending";
}

interface RescheduleDialogProps {
  appointment: Appointment;
  onReschedule: (appointmentId: string, newDate: string, newTime: string) => void;
  onClose: () => void;
}

export function RescheduleDialog({ appointment, onReschedule, onClose }: RescheduleDialogProps) {
  // Mock available dates and times
  const availableDates = [
    { date: "November 20, 2025", day: "Wednesday" },
    { date: "November 21, 2025", day: "Thursday" },
    { date: "November 24, 2025", day: "Sunday" },
    { date: "November 27, 2025", day: "Wednesday" },
    { date: "November 28, 2025", day: "Thursday" }
  ];

  const availableTimes = [
    "9:00 AM",
    "10:30 AM",
    "1:00 PM",
    "2:00 PM",
    "3:30 PM",
    "4:00 PM"
  ];

  const [selectedDate, setSelectedDate] = useState<string>("");
  const [selectedTime, setSelectedTime] = useState<string>("");

  const handleConfirm = () => {
    if (selectedDate && selectedTime) {
      onReschedule(appointment.id, selectedDate, selectedTime);
    }
  };

  const getInitials = (name: string) => {
    return name.split(" ").map(n => n[0]).join("").toUpperCase();
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-in fade-in duration-200">
      <Card className="max-w-2xl w-full max-h-[90vh] overflow-y-auto bg-white shadow-2xl animate-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="sticky top-0 bg-gradient-to-r from-blue-500 to-purple-500 text-white p-6 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="p-2 bg-white/20 rounded-lg">
              <Calendar className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl">Reschedule Appointment</h2>
              <p className="text-blue-100 text-sm">Select a new date and time</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-white/20 rounded-lg transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          {/* Current Appointment Info */}
          <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-xl p-4 border-2 border-blue-200">
            <p className="text-sm text-gray-600 mb-3">Current Appointment</p>
            <div className="flex items-center gap-4">
              <Avatar className="w-16 h-16 border-2 border-white">
                <AvatarImage src={appointment.counselor.photo} />
                <AvatarFallback className="bg-blue-200 text-blue-900">
                  {getInitials(appointment.counselor.name)}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <p className="text-gray-900">{appointment.counselor.name}</p>
                <p className="text-sm text-gray-600">{appointment.counselor.title}</p>
              </div>
              <div className="text-right">
                <p className="text-gray-900">{appointment.date}</p>
                <p className="text-sm text-gray-600">{appointment.time}</p>
              </div>
            </div>
          </div>

          {/* Select New Date */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <Calendar className="w-5 h-5 text-blue-600" />
              <h3 className="text-gray-800">Select New Date</h3>
            </div>
            <div className="grid sm:grid-cols-2 gap-3">
              {availableDates.map((dateOption, index) => {
                const isSelected = selectedDate === dateOption.date;
                return (
                  <button
                    key={index}
                    onClick={() => setSelectedDate(dateOption.date)}
                    className={`p-4 rounded-xl text-left transition-all duration-200 ${
                      isSelected
                        ? 'bg-gradient-to-br from-blue-500 to-purple-500 text-white shadow-lg scale-105 ring-4 ring-blue-200'
                        : 'bg-gradient-to-br from-blue-50 to-purple-50 border-2 border-blue-200 hover:shadow-md hover:border-blue-300'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <p className={`font-medium ${isSelected ? 'text-white' : 'text-gray-900'}`}>
                          {dateOption.date}
                        </p>
                        <p className={`text-sm ${isSelected ? 'text-blue-100' : 'text-gray-600'}`}>
                          {dateOption.day}
                        </p>
                      </div>
                      {isSelected && (
                        <Check className="w-5 h-5" />
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Select New Time */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <Clock className="w-5 h-5 text-purple-600" />
              <h3 className="text-gray-800">Select New Time</h3>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {availableTimes.map((timeOption, index) => {
                const isSelected = selectedTime === timeOption;
                return (
                  <button
                    key={index}
                    onClick={() => setSelectedTime(timeOption)}
                    disabled={!selectedDate}
                    className={`p-4 rounded-xl text-center transition-all duration-200 ${
                      !selectedDate
                        ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                        : isSelected
                        ? 'bg-gradient-to-br from-purple-500 to-pink-500 text-white shadow-lg scale-105 ring-4 ring-purple-200'
                        : 'bg-gradient-to-br from-purple-50 to-pink-50 border-2 border-purple-200 hover:shadow-md hover:border-purple-300'
                    }`}
                  >
                    <div className="flex items-center justify-center gap-2">
                      <Clock className="w-4 h-4" />
                      <span className="font-medium">{timeOption}</span>
                    </div>
                    {isSelected && (
                      <Check className="w-4 h-4 mx-auto mt-2" />
                    )}
                  </button>
                );
              })}
            </div>
            {!selectedDate && (
              <p className="text-sm text-gray-500 mt-3 text-center italic">
                Please select a date first to view available times
              </p>
            )}
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3 pt-4 border-t border-gray-200">
            <Button
              variant="outline"
              onClick={onClose}
              className="flex-1 border-gray-300 hover:bg-gray-100"
            >
              <X className="w-4 h-4 mr-2" />
              Cancel
            </Button>
            <Button
              onClick={handleConfirm}
              disabled={!selectedDate || !selectedTime}
              className="flex-1 bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600 text-white disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Check className="w-4 h-4 mr-2" />
              Confirm Reschedule
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
}
