import { projectId, publicAnonKey } from './supabase/info';

const API_BASE_URL = `https://${projectId}.supabase.co/functions/v1/make-server-aea76cd4`;

const headers = {
  'Content-Type': 'application/json',
  'Authorization': `Bearer ${publicAnonKey}`
};

// Check if Supabase is properly configured
const isSupabaseConfigured = () => {
  return projectId && publicAnonKey && projectId !== 'YOUR_PROJECT_ID';
};

// Helper function to handle fetch with better error messages
async function fetchWithErrorHandling(url: string, options?: RequestInit) {
  if (!isSupabaseConfigured()) {
    throw new Error('Supabase is not configured. Please connect your Supabase project.');
  }
  
  try {
    const response = await fetch(url, options);
    
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    
    const result = await response.json();
    return result;
  } catch (error) {
    if (error instanceof TypeError && error.message === 'Failed to fetch') {
      throw new Error('Unable to connect to the server. Please ensure the Supabase Edge Function is deployed.');
    }
    throw error;
  }
}

// ==================== COUNSELORS ====================

export async function getCounselor(id: number) {
  try {
    const result = await fetchWithErrorHandling(`${API_BASE_URL}/counselors/${id}`, { headers });
    if (!result.success) {
      throw new Error(result.error || 'Failed to fetch counselor');
    }
    return result.data;
  } catch (error) {
    console.error('Error fetching counselor:', error);
    throw error;
  }
}

export async function saveCounselor(counselor: any) {
  try {
    const result = await fetchWithErrorHandling(`${API_BASE_URL}/counselors`, {
      method: 'POST',
      headers,
      body: JSON.stringify(counselor)
    });
    if (!result.success) {
      throw new Error(result.error || 'Failed to save counselor');
    }
    return result.data;
  } catch (error) {
    console.error('Error saving counselor:', error);
    throw error;
  }
}

export async function updateCounselorAvatar(id: number, avatar: string) {
  try {
    const result = await fetchWithErrorHandling(`${API_BASE_URL}/counselors/${id}/avatar`, {
      method: 'PUT',
      headers,
      body: JSON.stringify({ avatar })
    });
    if (!result.success) {
      throw new Error(result.error || 'Failed to update counselor avatar');
    }
    return result.data;
  } catch (error) {
    console.error('Error updating counselor avatar:', error);
    throw error;
  }
}

// ==================== AUTH ====================

export async function login(email: string, password: string, userType: string) {
  try {
    const result = await fetchWithErrorHandling(`${API_BASE_URL}/auth/login`, {
      method: 'POST',
      headers,
      body: JSON.stringify({ email, password, userType })
    });
    if (!result.success) {
      throw new Error(result.error || 'Login failed');
    }
    return result.data;
  } catch (error) {
    console.error('Error during login:', error);
    throw error;
  }
}

export async function register(userData: any) {
  try {
    const result = await fetchWithErrorHandling(`${API_BASE_URL}/auth/register`, {
      method: 'POST',
      headers,
      body: JSON.stringify(userData)
    });
    if (!result.success) {
      throw new Error(result.error || 'Registration failed');
    }
    return result.data;
  } catch (error) {
    console.error('Error during registration:', error);
    throw error;
  }
}

export async function updateUser(email: string, updates: any) {
  try {
    const result = await fetchWithErrorHandling(`${API_BASE_URL}/users/${email}`, {
      method: 'PUT',
      headers,
      body: JSON.stringify(updates)
    });
    if (!result.success) {
      throw new Error(result.error || 'Failed to update user');
    }
    return result.data;
  } catch (error) {
    console.error('Error updating user:', error);
    throw error;
  }
}