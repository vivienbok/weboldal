# CareConnect Backend & Database Integration

## 🎯 Overview

A teljes backend és adatbázis integráció sikeresen implementálva lett a Supabase használatával. Az alkalmazás most valós adatbázissal működik persistent adattárolással.

## 🏗️ Architecture

```
Frontend (React) → Backend (Supabase Edge Functions) → Database (Key-Value Store)
```

### Technology Stack
- **Frontend**: React + TypeScript
- **Backend**: Deno + Hono (Edge Functions)
- **Database**: Supabase Key-Value Store
- **API**: RESTful endpoints

## 📁 File Structure

```
/supabase/functions/server/
  ├── index.tsx          # Main server with all API endpoints
  └── kv_store.tsx       # Protected KV database utilities

/utils/
  └── api.ts             # Frontend API service layer

/App.tsx                 # Main app with backend integration
```

## 🔐 Demo Accounts

Az alkalmazás automatikusan inicializálja az alábbi demo fiókokat:

### Counselor (Tanácsadó)
- **Email**: counselor@demo.com
- **Password**: demo123
- **Name**: Bognár Tamás

### Client (Páciens)
- **Email**: client@demo.com
- **Password**: demo123
- **Name**: Demo Client

### Admin
- **Email**: admin@demo.com
- **Password**: admin123
- **Name**: Admin User

## 📡 API Endpoints

### Authentication
- `POST /make-server-aea76cd4/auth/login` - Bejelentkezés
- `POST /make-server-aea76cd4/auth/register` - Regisztráció

### Counselors
- `GET /make-server-aea76cd4/counselors` - Összes tanácsadó lekérése
- `GET /make-server-aea76cd4/counselors/:id` - Egy tanácsadó lekérése
- `POST /make-server-aea76cd4/counselors` - Tanácsadó létrehozása/frissítése
- `PUT /make-server-aea76cd4/counselors/:id/avatar` - Avatar frissítése

### Appointments (Időpontok)
- `GET /make-server-aea76cd4/appointments` - Időpontok lekérése (filterekkel)
- `POST /make-server-aea76cd4/appointments` - Új időpont létrehozása
- `PUT /make-server-aea76cd4/appointments/:id` - Időpont frissítése
- `DELETE /make-server-aea76cd4/appointments/:id` - Időpont törlése

### Time Slots (Időrések)
- `GET /make-server-aea76cd4/timeslots` - Időrések lekérése
- `POST /make-server-aea76cd4/timeslots` - Új időrés létrehozása
- `PUT /make-server-aea76cd4/timeslots/:id` - Időrés frissítése
- `DELETE /make-server-aea76cd4/timeslots/:id` - Időrés törlése

### Appointment Requests (Időpont kérések)
- `GET /make-server-aea76cd4/appointment-requests` - Kérések lekérése
- `POST /make-server-aea76cd4/appointment-requests` - Új kérés létrehozása
- `PUT /make-server-aea76cd4/appointment-requests/:id` - Kérés frissítése (elfogadás/elutasítás)
- `DELETE /make-server-aea76cd4/appointment-requests/:id` - Kérés törlése

### Initialization
- `POST /make-server-aea76cd4/initialize` - Alapértelmezett adatok inicializálása

## 🗄️ Database Schema

### Key Prefixes
- `counselor:` - Tanácsadók adatai
- `user:` - Felhasználói fiókok (email alapján)
- `appointment:` - Lefoglalt időpontok
- `timeslot:` - Tanácsadók által publikált időrések
- `appointmentrequest:` - Páciensek által küldött időpont kérések

## 🔄 Data Flow Examples

### 1. User Login
```
User → Frontend → API (login) → Database → Backend validates → Frontend receives user data
```

### 2. Book Appointment
```
Client → Frontend → API (createAppointment) → Database stores → All users see update
```

### 3. Update Profile Avatar (Counselor)
```
Counselor → Profile → API (updateUser) → Updates user
                   → API (updateCounselorAvatar) → Updates counselor
                   → API (updateAppointment) → Updates all existing appointments
```

## 🚀 Features Implemented

✅ **User Authentication**
- Secure login with email/password
- Role-based access (counselor/client/admin)
- Session management

✅ **Persistent Data Storage**
- All data stored in Supabase database
- Automatic data loading on app initialization
- Real-time updates across the application

✅ **Centralized Counselor Management**
- Single source of truth for counselor data
- Avatar updates propagate everywhere
- Consistent data across all views

✅ **Appointment Management**
- Create, update, cancel appointments
- Filter by client, counselor, status
- Automatic date parsing and formatting

✅ **Time Slot Management**
- Counselors can publish available slots
- Track booked vs. available slots
- Automatic generation of default slots

✅ **Appointment Requests**
- Patients can request specific times
- Counselors can approve/reject requests
- Approved requests become confirmed appointments

✅ **Error Handling & User Feedback**
- Toast notifications for all actions
- Detailed error messages
- Loading states during data operations

## 🛠️ Frontend Integration

Az `App.tsx` komponens most teljesen integrálva van a backenddel:

```typescript
// Automatikus inicializálás
useEffect(() => {
  initializeApp();  // Loads all data from backend
}, []);

// Minden handler async és használja az API-t
const handleBookAppointment = async (appointment) => {
  await api.createAppointment(appointment);
  // State frissítése sikeres backend művelet után
};
```

## 📝 Usage

### Backend API használata a frontendből

```typescript
import * as api from './utils/api';

// Tanácsadók lekérése
const counselors = await api.getCounselors();

// Időpont foglalása
const appointment = await api.createAppointment({
  date: new Date().toISOString(),
  time: "10:00",
  counselor: counselorData,
  client: clientData,
  status: "confirmed"
});

// Időrés létrehozása
const timeSlot = await api.createTimeSlot({
  date: date.toISOString(),
  time: "14:00",
  duration: 50,
  isBooked: false,
  counselorName: "Bognár Tamás"
});
```

## ⚠️ Important Notes

1. **Date Handling**: Minden dátum ISO string formátumban tárolódik a backend-en, és Date objektumként használatos a frontenden.

2. **Error Handling**: Minden API hívás try-catch blokkban van, toast értesítésekkel.

3. **Loading States**: Az alkalmazás loading képernyőt mutat az inicializálás alatt.

4. **Data Consistency**: A centralizált counselor kezelés biztosítja, hogy az avatar frissítések mindenhol megjelenjenek.

## 🔮 Future Enhancements

Potenciális fejlesztések:
- Real-time notifications (Supabase Realtime)
- File upload for documents (Supabase Storage)
- Advanced search and filtering
- Calendar export (iCal format)
- Email notifications
- SMS reminders
- Video call integration

## 🐛 Troubleshooting

### Ha az app nem tölt be:
1. Ellenőrizd a konzolt hibákért
2. Nézd meg a network tabot az API hívásokért
3. Győződj meg róla, hogy a Supabase kapcsolat él

### Ha a login nem működik:
- Használd a fenti demo fiókokat
- Ellenőrizd, hogy az `/initialize` endpoint lefutott-e

## 📞 Support

Az alkalmazás most teljes mértékben működőképes valós backend integrációval. Minden adat perzisztensen tárolódik és minden felhasználó ugyanazt az adatbázist használja.
